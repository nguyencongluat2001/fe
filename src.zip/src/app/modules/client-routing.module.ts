import { NgModule } from '@angular/core';
import { LayoutsComponent } from './layouts/layouts.component';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: LayoutsComponent,
    children: [
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      },
      {
        path: 'system/evaluation',
        loadChildren: () => import('./evaluation/evaluation.module').then(m => m.EvaluationModule)
      },
      {
        path: 'system/notification',
        loadChildren: () => import('./notification/notification.module').then(m => m.NotificationModule)
      },
      {
        path: 'system/execute',
        loadChildren: () => import('./execute/execute.module').then(m => m.ExecuteModule)
      },
      {
        path: 'system/markpoint',
        loadChildren: () => import('./mark-point/mark-point.module').then(m => m.MarkPointModule)
      },
      {
        path: 'system/track',
        loadChildren: () => import('./track/track.module').then(m => m.TrackModule)
      },
      {
        path: 'system/multiple_choice',
        loadChildren: () => import('./multiple_choice/multiple-choice.module').then(m => m.MultipleChoiseModule)
      },
      {
        path: 'system/result_district',
        loadChildren: () => import('./result_district/result-district.module').then(m => m.ResultDistrictModule)
      },
      {
        path: 'system/search',
        loadChildren: () => import('./search/search.module').then(m => m.SearchModule)
      },
      {
        path: 'system/searchtotal',
        loadChildren: () => import('./search_total/search-total.module').then(m => m.SearchTotalModule)
      },
      {
        path: 'system/sendrequest',
        loadChildren: () => import('./send_request/send-request.module').then(m => m.SendRequestModule)
      },
      {
        path: 'system/total',
        loadChildren: () => import('./report_total/report.module').then(m => m.ReportModule)
      },
      {
        path: 'system/compare',
        loadChildren: () => import('./report_compare/report-compare.module').then(m => m.ReportCompareModule)
      },
      {
        path: 'system/listrequest',
        loadChildren: () => import('./support_technology/support-technology.module').then(m => m.SupportTechnologyModule)
      },
      {
        path: 'system/reportdetail',
        loadChildren: () => import('./report_detail/report.module').then(m => m.ReportModule)
      },

      //sipas
      {
        path: 'system/manage_question_sipas',
        loadChildren: () => import('./manage_question_sipas/manage-question-sipas.module').then(m => m.ManageQuestionSipasModule)
      },
      {
        path: 'system/vote_sipas',
        loadChildren: () => import('./vote_sipas/vote-sipas.module').then(m => m.VoteSipasModule)
      },
      {
        path: 'system/report_sipas',
        loadChildren: () => import('./report_sipas/report-sipas.module').then(m => m.ReportSipasModule)
      },
      //điều tra xã hội học
      {
        path: 'system/manage_question',
        loadChildren: () => import('./manage_question/manage-question.module').then(m => m.ManageQuestionModule)
      },
      {
        path: 'system/vote_province',
        loadChildren: () => import('./vote_province/vote-province.module').then(m => m.VoteProvinceModule)
      },
      {
        path: 'system/vote_district',
        loadChildren: () => import('./vote_district/vote-district.module').then(m => m.VoteDistrictModule)
      },
      {
        path: 'system/subject',
        loadChildren: () => import('./subject/subject.module').then(m => m.SubjectModule)
      },
      {
        path: 'system/manage_pointSociology',
        loadChildren: () => import('./manage_pointSociology/manage-pointSociology.module').then(m => m.ManagePointSociologyModule)
      },
      // Quản trị hệ thống
       {
         path: 'system/users',
         loadChildren: () => import('./users/users.module').then(m => m.UsersModule)
       },
       {
        path: 'system/permission_xhh',
        loadChildren: () => import('./permission_xhh/permission.module').then(m => m.PermissionModule)
       },
       {
        path: 'system/menu',
        loadChildren: () => import('./menu/menu.module').then(m => m.MenuModule)
      },
      {
        path: 'system/listtype',
        loadChildren: () => import('./listtype/listtype.module').then(m => m.ListtypeModule)
      },
      {
        path: 'system/list',
        loadChildren: () => import('./list/list.module').then(m => m.ListModule)
      },
      {
        path: 'system/logs',
        loadChildren: () => import('./logs/logs.module').then(m => m.LogsModule)
      },
      {
        path: 'system/support',
        loadChildren: () => import('./support/support.module').then(m => m.SupportModule)
      },
      {
        path: 'system/evaluation_war',
        loadChildren: () => import('./evaluation_war/evaluation.module').then(m => m.EvaluationModule)
      },
      {
        path: 'system/track_ward',
        loadChildren: () => import('./track_ward/track.module').then(m => m.TrackModule)
      },
      {
        path: 'system/execute_ward',
        loadChildren: () => import('./execute_ward/executeward.module').then(m => m.ExecuteWardModule)
      },
      {
        path: 'system/markpoint_ward',
        loadChildren: () => import('./markpoint_ward/mark-point.module').then(m => m.MarkPointModule)
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClientRoutingModule { }
