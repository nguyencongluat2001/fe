import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { RouterLink } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { MarkpointModel, Excute } from '../../../mark-point/models/MarkpointModel';
import { MarkpointService } from '../../../mark-point/services/markpoint.service';
import { Library } from 'src/app/shared/library/main';
import { BsModalRef } from 'node_modules/ngx-bootstrap/modal';


@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  listEvalution: Excute[];
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  txt_search = '';
  listsGroup: any;
  years: any;
  defaultVisible: false;

  constructor(
    private modalService: BsModalService,
    public markpointmodel: MarkpointModel,
    private route: Router,
    private router: ActivatedRoute,
    public markpointservice: MarkpointService,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      txtSearch: this.txt_search,
      user_infor:JSON.parse(localStorage.getItem('user_infor'))['id']
    };
    Library.showloading();
    this.listEvalution = await this.markpointmodel.getAll(params);
    Library.hideloading();
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
  }


  getlist() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.markpointmodel.objEvalution = this.selectedItems[0];
      let newrouter = "/system/markpoint/list";
      this.route.navigate([newrouter]);
    }
  }
}
