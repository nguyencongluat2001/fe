import { Component, OnInit } from '@angular/core';
import { MarkpointModel,Listexpertise } from '../../models/MarkpointModel';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { GivebackComponent } from '../giveback/giveback.component';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-listexpertise',
  templateUrl: './listexpertise.component.html',
  styleUrls: ['./listexpertise.component.scss']
})
export class ListexpertiseComponent implements OnInit {
  listdata: Listexpertise[];
  selectedItems: Listexpertise[]=[];
  name: string;
  status=true;
  statustrack=true;

  constructor(private markpointmodel: MarkpointModel, private route: Router, private modalService: BsModalService, ) { }

  ngOnInit() {
    this.name ='Danh sách đợt '+ this.markpointmodel.objEvalution['name'];
    this.loadlistexpertise()
  }
  async loadlistexpertise() {
    var params = {
      id: this.markpointmodel.objEvalution['id'],
      ownercode: this.markpointmodel.objEvalution['ownercode'],
      user_infor:JSON.parse(localStorage.getItem('user_infor'))['id']
    };
    Library.showloading();
    this.listdata = await this.markpointmodel.getListexpertise(params);
    this.listdata = this.listdata;
  
   
    for (let i = 0; i<this.listdata.length;i++) {
      this.listdata[i]['sum_point_councill'] = Math.round(this.listdata[i]['sum_point_councill']*100)/100;
      this.listdata[i]['sum_point_self'] = Math.round(this.listdata[i]['sum_point_self']*100)/100
    }
    Library.hideloading();
  }
  onRowPrepared(e) {
    if (e.rowType == "data") {
      if (e.rowIndex % 2 == 0) {
        $(e.rowElement).addClass("dx-column-lines-color");
      }
    }
  }
  convertFromdate(data) {
    if (data == '' || data == null)
      return '';
    return Library.formatDate(data.date_send);
  }
  goBack() {
    let newrouter = "/system/markpoint";
    this.route.navigate([newrouter]);
  }
  selectExcution(e) {
    this.selectedItems = e.selectedRowsData;
    var check:any;
     check=this.selectedItems.map(element=>element.status);
    
    if(check=='DA_CHAM'){
      this.status=false;
    }
   
  
    


  }
  markpoint() {

    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để chấm điểm", 'error');
      return;
    } else {
      this.markpointmodel.objExcute = this.selectedItems[0];
      if(this.markpointmodel.objExcute.ispublic == '1'){
        Library.notify("Đợt đánh giá này đã công bố kết quả", 'error');
        return;
      }
      if(this.markpointmodel.objExcute.statustrack == '1'){
        Library.notify("Đợt đánh giá này đã được gửi lên chủ tịch hội đồng thẩm định", 'error');
        return;
      }
      else{
     
        this.markpointmodel.objExcute.selectbutton='';
        let newrouter = "/system/markpoint/mark";
        this.route.navigate([newrouter]);
      }
     
    }
  }
  // sendtrack() {
  //   if (this.selectedItems.length > 1) {
  //     Library.notify("Chỉ được chọn một đối tượng để chuyển kết quả", 'error');
  //   } else {
  //     var MyClass = this;
  //     var result = Library.confirm("Bạn có chắc chắn muốn chuyển kết chấm điểm của đợt đánh giá đã chọn lên hội đồng thẩm định?", "Thông báo");
  //     result.done(function (r) {
  //       if (r) {
  //         MyClass.route.routeReuseStrategy.shouldReuseRoute = function () {
  //           return false;
  //         }
  //         var params = {
  //           execute_group_id: MyClass.selectedItems[0]['execute_group_id'],
  //           id_excute_unit: MyClass.selectedItems[0]['id'],
  //           ownercode: MyClass.selectedItems[0]['ownercode'],
  //           user_id: JSON.parse(localStorage.getItem('user_infor'))['id']
  //         }
  //         MyClass.markpointmodel.sendtrack(params,MyClass);
       
       
  //       }
  //     });
  //   }
  // }
  sendtrack(){
    if (this.selectedItems.length > 1) {
          Library.notify("Chỉ được chọn một đối tượng để chuyển kết quả", 'error');
        } else {
          this.markpointmodel.objExcute = this.selectedItems[0];
       
          if (this.markpointmodel.objExcute['status'] == 'DA_CHAM') {
            Library.notify("Đợt đánh giá này đã được gửi lên chủ tịch hội đồng thẩm định", 'error');
            return;
            
          }
          else if(this.markpointmodel.objExcute['statustrack'] == '1'){
            Library.notify("Đợt đánh giá này đã được gửi lên chủ tịch hội đồng thẩm định", 'error');
            return;
          } else {
            this.modalService.show(GivebackComponent);
          }
          
        }

  }
  setStatus(data) {
   
    // if (data.status == 'DA_CHAM') {
    //   data.group = 'DA_CHAM';
    //   return 'Đã gửi';
    // } 
    // if(data.status == 'CHAM_DIEM') {
    //   data.group = 'CHAM_DIEM';
    //   return 'Đang chấm điểm';
    // } 
    // if(data.status == 'TRA_LAI_DANH_GIA') {
    //   data.group = 'TRA_LAI_DANH_GIA';
    //   return 'Trả lại đánh giá';
    // } 
  }
  progress(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem tiến độ", 'error');
    } else {
      this.markpointmodel.objExcute = this.selectedItems[0];
      let newrouter = "/system/markpoint/progress";
      this.route.navigate([newrouter]);
    }
  }
  printmaxpoint(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để in", 'error');
      return;
    } else {
    
      var param={
        ownercode:this.selectedItems[0].ownercode,
        excute_id:this.selectedItems[0].execute_group_id,
        user_id:JSON.parse(localStorage.getItem('user_infor'))['id'],
        nameeval:this.markpointmodel.objEvalution['name'],
        tendonvi:this.selectedItems[0].tendonvi
      }
      this.markpointmodel.printmaxpoint(param);
    }
  }
  seedetail(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.markpointmodel.objExcute = this.selectedItems[0];
      this.markpointmodel.objExcute.selectbutton='XEM_CHI_TIET';
      let newrouter = "/system/markpoint/mark";
      this.route.navigate([newrouter]);
    }
  }
}

