import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentSendComponent } from './content-send.component';

describe('ContentSendComponent', () => {
  let component: ContentSendComponent;
  let fixture: ComponentFixture<ContentSendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentSendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentSendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
