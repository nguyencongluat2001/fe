import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarkpointComponent } from './markpoint.component';

describe('MarkpointComponent', () => {
  let component: MarkpointComponent;
  let fixture: ComponentFixture<MarkpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarkpointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkpointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
