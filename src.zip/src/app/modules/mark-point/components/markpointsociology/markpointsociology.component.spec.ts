import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarkpointsociologyComponent } from './markpointsociology.component';

describe('MarkpointsociologyComponent', () => {
  let component: MarkpointsociologyComponent;
  let fixture: ComponentFixture<MarkpointsociologyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarkpointsociologyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkpointsociologyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
