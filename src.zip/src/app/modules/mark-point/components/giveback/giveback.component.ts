import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
// import { Headers, RequestOptions } from '@angular/http';
import { MarkpointModel } from '../../models/MarkpointModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-giveback',
  templateUrl: './giveback.component.html',
  styleUrls: ['./giveback.component.scss']
})
export class GivebackComponent implements OnInit {

  baseUrl: string;
  headers: any;
  content: string;
  listfile: string;
  value: any[] = [];
  index: number;
  fileselected: File[] = [];
  arrfile: any = [];
  namework;
  work;
  selectedItem: any;
  name;
  constructor(
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private excuteModel: MarkpointModel,
    private route: Router,
  ) {
    this.baseUrl = environment.API_URL + 'markpoint/';
    let token = localStorage.getItem('token');
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Headers', 'Content-Type, X-XSRF-TOKEN');
    headers.append('Authorization', `Bearer ${token}`);
    this.headers = headers;
    this.route.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
  }
  ngOnInit() {
    this.loadlistwork();
  }
  async loadlistwork() {
   
    this.namework = await this.excuteModel.getlistwork();
    var code1 = this.namework.filter(a => a.code == 'CHUYEN_THAM_DINH');
    var name1 = code1.map(d => d.name);
    this.content = name1;
  }
  handleFileInput(event) {
    if (event.target.files[0].name != '') {
      this.fileselected.push(<File>event.target.files[0]);
    }
  }
  remove(filename) {
    let index = this.fileselected.findIndex(file => file.name == filename);
    this.fileselected.splice(index, 1);
  }

  change(e) {
    this.selectedItem = e.value;

    var code1 = this.namework.filter(a => a.code == 'CHUYEN_THAM_DINH');
    var name1 = code1.map(d => d.name);
    var code2 = this.namework.filter(a => a.code == 'TRA_LAI_DOT_DANH_GIA');
    var name2 = code2.map(d => d.name);

    if (this.selectedItem == 'CHUYEN_THAM_DINH') {
      this.content = name1;
    }
    if (this.selectedItem == 'TRA_LAI_DOT_DANH_GIA') {
      this.content = name2;
    }
  }

  process() {

    if (this.selectedItem == "TRA_LAI_DOT_DANH_GIA") {
      this.giveback();
    }
    if (this.selectedItem == "CHUYEN_THAM_DINH") {
      this.sendtrack();
    }

  }
  giveback() {
    var date = new Date();

    var datetoday = date.toLocaleDateString("en-US");
    // var fromdates=this.excuteModel.objExcute['todate'];
    var todate = new Date(this.excuteModel.objExcute['todate']);

    var dateselect = todate.toLocaleDateString("en-US");

    if (Date.parse(datetoday) > Date.parse(dateselect)) {
      Library.notify("Đã hết thời gian đánh giá", 'error');
    }
    else {
      let myclass = this;
      const fd = new FormData();
      var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
      var user_infor = JSON.parse(localStorage.getItem('user_infor'))['id'];
      for (let i in this.fileselected) {
        fd.append('file' + i, this.fileselected[i], this.fileselected[i].name)
      }
      fd.append('id_excute_unit', this.excuteModel.objExcute['id']);
      fd.append('ownercode', this.excuteModel.objExcute['ownercode']);
      fd.append('content', this.content);
      fd.append('user_id', user_infor);
      fd.append('execute_group_id', this.excuteModel.objExcute['execute_group_id']);
      let token = localStorage.getItem('token');
      let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
      Library.showloading();
      this.http.post(this.baseUrl + 'giveback', fd,{ headers: header, }).subscribe((res: any) => {
        if (res['success']) {
          myclass.route.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
          }
          this.bsModalRef.hide();
          myclass.route.navigated = false;
          myclass.route.navigate([myclass.route.url]);

        } else {
          Library.notify(res.message, 'error');
        }
      });
      Library.hideloading();
    }

  }
  sendtrack() {
    let myclass = this;
    const fd = new FormData();
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    var user_infor = JSON.parse(localStorage.getItem('user_infor'))['id'];
    for (let i in this.fileselected) {
      fd.append('file' + i, this.fileselected[i], this.fileselected[i].name)
    }

    fd.append('id_excute_unit', this.excuteModel.objExcute['id']);
    fd.append('ownercode', this.excuteModel.objExcute['ownercode']);
    fd.append('content', this.content);
    fd.append('user_id', user_infor);
    fd.append('execute_group_id', this.excuteModel.objExcute['execute_group_id']);
    let token = localStorage.getItem('token');
    let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    Library.showloading();
    this.http.post(this.baseUrl + 'sendtrack', fd,{ headers: header, }).subscribe((res: any) => {
      if (res['success']) {
        Library.notify(res.message, 'success');
        myclass.route.routeReuseStrategy.shouldReuseRoute = function () {
          return false;
        }
        this.bsModalRef.hide();
        myclass.route.navigated = false;
        myclass.route.navigate([myclass.route.url]);


      } else {
        Library.notify(res.message, 'error');
      }
    });
    Library.hideloading();
  }
  goback() {
    let newrouter = "/system/markpoint/list";
    this.route.navigate([newrouter]);
    this.bsModalRef.hide();
  }

}


