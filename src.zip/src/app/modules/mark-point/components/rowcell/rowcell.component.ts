import { Component, OnInit, Input } from '@angular/core';
import { MarkpointsociologyComponent } from '../markpointsociology/markpointsociology.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { MarkpointModel } from '../../models/MarkpointModel';
@Component({
  selector: 'app-rowcell',
  templateUrl: './rowcell.component.html',
  styleUrls: ['./rowcell.component.scss']
})
export class RowcellComponent implements OnInit {
  @Input() data: any;
  datas:any;
  selectbutton='';
  constructor(
    public modalService: BsModalService,
    public markpointmodel: MarkpointModel

  ) { 
 
  }

  ngOnInit() {
    this.datas=this.data.data;
    this.selectbutton=this.data.selectbutton;
  }
  showModal(data) {
    
    this.markpointmodel._list = data;
    this.modalService.show(MarkpointsociologyComponent);
  }
}
