import { Injectable } from '@angular/core';
import { MarkpointService } from '../services/markpoint.service';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';


export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: number = 0;
    ownercode: string = localStorage.getItem('unit_infor')['code'];
    selectbutton:string;
    is_return:string;

}

export class List {
    id: string;
    parrent_id: string;
    name: string;
    max_point: number;
    point_self: number;
    explanation: string;
    listfile: string;
    poor_votes: number;
    average_votes: number;
    pretty_votes: number;
    good_votes: number;
    poor_percent: number;
    average_percent: number;
    pretty_percent: number;
    good_percent: number;
    question_content: string;
    sociology_point: number;
    note:string;
  
}
export class Listexpertise {
    content_send:string;
    date_send: string;
    execute_group_id: string;
    filedanhgia: null
    id: string;
    name: string;
    namestatus: string;
    ownercode: string;
    status: string;
    sum_point_councill: number;
    sum_point_self: number;
    tendonvi: string;
    todate:string;
}
@Injectable()

export class MarkpointModel {

    _excute: Excute;
    objEvalution: any;
    objExcute: any;
    loadList:any;
    public _note:List;
    public _list: List;
    public listData: any;
    private _dataview: any;
    listdataexcute: any;
    public _evaluationList: any;
    work:any;
    constructor(private markpointservice: MarkpointService, private route: Router) {

    }
    setLoadList(Myclass) {
        return this.loadList = Myclass;
    }
    async getAll(parram,async: boolean = false): Promise<Excute[]> {
        let response = await this.markpointservice.callGet('getEvaluation', parram);
        return response;
    }

    async getAllList(params, async: boolean = false) {
        let response = await this.markpointservice.callGet('getallList', params);
        this.listData = response;
        return this.listData;
    }

    async getListexpertise(params, async: boolean = false): Promise<Listexpertise[]> {
        let response = await this.markpointservice.callGet('getallexcute', params);
        return response.data;

    }
    async getTotalPoint(parram, async: boolean = false): Promise<Excute[]> {
        let response = await this.markpointservice.callGet('getTotalPoint', parram);
        return response.data;
    }

    set Excute(value: any) {
        this._excute = value;
    }

    get Excute() {
        return this._excute;
    }
    set setlist(value: any) {
        this._list = value;
    }

    get getlist() {
        return this._list;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }
    set getwork(value: any) {
        this.work = value;
    }
    set setNote(value: any) {
        this._note = value;
    }

    get getNote() {
        return this._note;
    }
    get setwork() {
        return this.work;
    }
    set setEvalist(value: any) {
        this._evaluationList = value;
    }

    get getEvalist() {
        return this._evaluationList;
    }
    updateresultexpertise(params) {
     
      if(params['deltapoint'] !==undefined){
        if (params['deltapoint'] != 0) {
            let id = params['id'];
            let index = this.listData.findIndex(data => data.id == id);
            this.listData[index]['index'] = Math.round((parseFloat(this.listData[index]['point_council']) / parseFloat(this.listData[index]['max_point'])) * 100);
            
            let listidparent = params['listidparent'];
          
            let arrIdParent = listidparent.split('!~!');
            for (let j = 0; j < arrIdParent.length - 1; j++) {
                let arrParentsingle = arrIdParent[j].split(',');
                this.listData[arrParentsingle[1]]['index'] = Math.round((parseFloat(this.listData[arrParentsingle[1]]['point_council']) / parseFloat(this.listData[arrParentsingle[1]]['max_point'])) * 100);
         
        }
    }
        }
        this.markpointservice.callPost('updateresultexpertise', params).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            }
        });
    }
    sendtrack(params,Myclass) {
        let myclass = this;
        this.markpointservice.callPost('sendtrack', params).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Myclass.loadlistexpertise();
            }
            if (!response.success) {
                Library.notify(response.message, 'error');
                myclass.route.navigated = false;
                myclass.route.navigate([myclass.route.url]);
            }
        });
    }

    updatesociologypoint(params) {
        if (params['deltapoint'] != 0) {
            let id = params['id'];
            let index = this.listData.findIndex(data => data.id == id);
            this.listData[index]['index'] = Math.round((parseFloat(this.listData[index]['point_council']) / parseFloat(this.listData[index]['max_point'])) * 100);
            let listidparent = params['list_parrent_id'];
            let arrIdParent = listidparent.split('!~!');
            for (let j = 0; j < arrIdParent.length - 1; j++) {
                let arrParentsingle = arrIdParent[j].split(',');
                this.listData[arrParentsingle[1]]['index'] = Math.round((parseFloat(this.listData[arrParentsingle[1]]['point_council']) / parseFloat(this.listData[arrParentsingle[1]]['max_point'])) * 100);
            }
        }
        this.markpointservice.callPost('updatesociologypoint', params).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            }
        });
    }
    async explanation_detail(params, async: boolean = false): Promise<Excute[]> {
        let response = await this.markpointservice.callGet('explanation_detail', params);
        return response;
    }

    async getlistwork(async: boolean = false) { 
        let parram = '';
        let response = await this.markpointservice.callGet('getlistwork', parram);
        return response;
    }
    async getprogress(params, async: boolean = false): Promise<List[]> {
        let response = await this.markpointservice.callGet('getprogress', params);
        return response;

    }
    printmaxpoint(params) {
       
        this.markpointservice.callPost('printmaxpoint', params).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            } else {
                window.location.href = response.urlfile;
            }
        });
    }
    async updateexternalexcute(data, bsModalRef, myclass) {
        Library.showloading();
        let params = {
            data: data,
            evaluation_list_id: this._evaluationList.evaluation_list_id,
            excutelist: this._evaluationList.id,
            ownercode: this._evaluationList.ownercode,
            parrent_id: this._evaluationList.parrent_id,

        }
        await this.markpointservice.callPost('updateexternalexcute', params).subscribe(async (response: any) => {
            if (!response.success) {
                Library.notify(response.message, 'error');
            } else {
                // var execute_group_id = this.objExcute.execute_group_id;
                // let params = {
                //     excute_id: execute_group_id,
                //     ownercode: this.objExcute['ownercode'],
                //     user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
                //     selectbutton:''
                // };
                // await this.getAllList(params);
                var arrdata = response.arrdata;
                for (let j = 0; j < arrdata.length; j++) {
                    let index = this.listData.findIndex(data => data.id == arrdata[j].execute_list);
                    // console.log(index);
                    this.listData[index]['index'] = arrdata[j].index;
                    this.listData[index]['point_council'] = arrdata[j].point_council;
                    this.listData[index]['ket_qua_tc_tham_dinh'] = arrdata[j].ket_qua_tc_tham_dinh;
                    this.listData[index]['tc_tham_dinh_1'] = arrdata[j].tc_tham_dinh_1;
                    this.listData[index]['tc_tham_dinh_2'] = arrdata[j].tc_tham_dinh_2;
                    this.listData[index]['tc_tham_dinh_3'] = arrdata[j].tc_tham_dinh_3;
                    this.listData[index]['ket_qua_tn_tham_dinh'] = arrdata[j].ket_qua_tn_tham_dinh;

                }
                bsModalRef.hide();
                Library.hideloading();
                let index1 = this.listData.findIndex(data => data.name ==  'TONG_DIEM');
                var param = {
                    'execute_group_id': this._evaluationList.execute_group_id,
                    'ownercode': this._evaluationList.ownercode,
                };
                myclass.getTotalPoint(param,index1);

            }
        });
    }
}
