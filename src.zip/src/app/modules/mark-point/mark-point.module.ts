import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { MarkpointModel, Excute } from '../mark-point/models/MarkpointModel';
import { MarkpointService } from '../mark-point/services/markpoint.service';
import { MarkPointRoutingModule } from './mark-point-routing.module';
import { IndexComponent } from './components/index/index.component';
import { MarkpointComponent } from './components/markpoint/markpoint.component';
import { ListexpertiseComponent } from './components/listexpertise/listexpertise.component';
import { ExplanationComponent } from './components/explanation/explanation.component';
import { RowcellComponent } from './components/rowcell/rowcell.component';
import { MarkpointsociologyComponent } from './components/markpointsociology/markpointsociology.component';
import { ContentSendComponent } from './components/content-send/content-send.component';
import { ListexplanationComponent } from './components/listexplanation/listexplanation.component';
import { GivebackComponent } from './components/giveback/giveback.component';
import { NoteComponent } from './components/note/note.component';
import { ProgressComponent } from './components/progress/progress.component';
import { EvaluateComponent } from './components/evaluate/evaluate.component';
import { ListfileprogressComponent } from './components/listfileprogress/listfileprogress.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    MarkPointRoutingModule,
  ],
  // entryComponents: [
  //   MarkpointsociologyComponent, NoteComponent,RowcellComponent,ListexplanationComponent,GivebackComponent,EvaluateComponent
  // ],
  providers: [MarkpointService, MarkpointModel,MarkpointsociologyComponent],
  declarations: [IndexComponent, MarkpointComponent, ListexpertiseComponent, ExplanationComponent, RowcellComponent, MarkpointsociologyComponent,EvaluateComponent,
     ContentSendComponent,ListexplanationComponent,GivebackComponent,ProgressComponent,ListfileprogressComponent,NoteComponent]

    })
export class MarkPointModule { }
