import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { MarkpointComponent } from './components/markpoint/markpoint.component';
import { ListexpertiseComponent } from './components/listexpertise/listexpertise.component';
import { ProgressComponent } from './components/progress/progress.component';

const routes: Routes = [
  {
    path: '',
    component: IndexComponent,
    data: {
      title: 'Chấm điểm các đợt đánh giá của đơn vị'
    }
  },
  {
    path: 'mark',
    component: MarkpointComponent,
    data: {
      title: 'Chấm điểm'
    }
  },
  {
    path: 'list',
    component: ListexpertiseComponent,
    data: {
      title: 'Danh sách đợt đánh giá của đơn vị'
    }
  },
  {
    path: 'progress',
    component: ProgressComponent,
    data: {
      title: 'Tiến độ '
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MarkPointRoutingModule { }
