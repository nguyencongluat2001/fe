import { TestBed, inject } from '@angular/core/testing';

import { MarkpointService } from './markpoint.service';

describe('MarkpointService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MarkpointService]
    });
  });

  it('should be created', inject([MarkpointService], (service: MarkpointService) => {
    expect(service).toBeTruthy();
  }));
});
