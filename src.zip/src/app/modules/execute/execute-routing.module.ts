import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExecuteComponent } from './components/execute/excute.component';
import { IndexComponent } from './components/index/index.component';
import { SeeComponent } from './components/see/see.component';
import { ResultComponent } from './components/result/result.component';
const routes: Routes = [
  {
    path: ''
    , component: IndexComponent
    , data: {
      title: 'Thực hiện đánh giá cải cách hành chính'
    }
  }, {
    path: 'execute', component: ExecuteComponent, data: {
      title: 'Đánh giá các tiêu chí'
    }
  },
  {
    path: 'execute/index', component: ExecuteComponent, data: {
      title: 'Đánh giá các tiêu chí'
    }
  },
  {
    path: 'see', component: SeeComponent, data: {
      title: 'Xem chi tiết các tiêu chí'
    }
  },
  {
    path: 'result', component: ResultComponent, data: {
      title: 'Xem kết quả'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExcuteRoutingModule { }
