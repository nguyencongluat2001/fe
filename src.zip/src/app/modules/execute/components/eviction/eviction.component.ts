import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
// import { Headers, RequestOptions } from '@angular/http';
import { ExcuteModel } from '../../models/ExcuteModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-eviction',
  templateUrl: './eviction.component.html',
  styleUrls: ['./eviction.component.scss']
})
export class EvictionComponent implements OnInit {

  baseUrl: string;
  headers: any;
  content: string;
  listfile: string;
  value: any[] = [];
  index: number;
  fileselected: File[] = [];
  arrfile: any = [];
  namework;
  work;
  constructor(
    private HttpService: HttpService,
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private excuteModel: ExcuteModel,
    private route: Router,
  ) {
    this.baseUrl = environment.API_URL + 'excute/';
    let token = localStorage.getItem('token');
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Headers', 'Content-Type, X-XSRF-TOKEN');
    headers.append('Authorization', `Bearer ${token}`);
    this.headers = headers;
    this.route.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
  }
  ngOnInit() {
   this.loadlistwork();
  }
  async loadlistwork(){
    this.getlistwork();
    // this.namework=await this.excuteModel.getlistwork();
    // this.namework.forEach(element => {
    //   if(element.code==this.excuteModel.work){
    //     this.content=element.name;
    //   }
    // });
   
}
getlistwork() {
  let parram = '';
  this.HttpService.getMethods("excute/getlistwork", parram).subscribe(
      result => {
          this.namework = result.data;
          this.namework.forEach(element => {
            if(element.code==this.excuteModel.work){
              this.content=element.name;
            }
          });
      },
      (error) => {
        Library.hideloading();
      }
    );
}
  handleFileInput(event) {
    if (event.target.files[0].name != '') {
      this.fileselected.push(<File>event.target.files[0]);
    }
  }
  remove(filename) {
    let index = this.fileselected.findIndex(file => file.name == filename);
    this.fileselected.splice(index, 1);
  }
  eviction() {
    let myclass = this;
    const fd = new FormData();
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    var user_infor=JSON.parse(localStorage.getItem('user_infor'))['id'];
    for (let i in this.fileselected) {
      fd.append('file' + i, this.fileselected[i], this.fileselected[i].name)
    }
    fd.append('idexcuteunit', this.excuteModel.objExcute['id']);
    fd.append('ownercode', unit_infor['code']);
    fd.append('content', this.content);
    fd.append('user_perform',user_infor);
    fd.append('execute_group_id', this.excuteModel.objExcute['execute_group_id']);
    let token = localStorage.getItem('token');
    let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    Library.showloading();
    this.http.post(this.baseUrl + 'eviction', fd,{ headers: header, }).subscribe((res: any)=> {
      if (res['success']) {
        myclass.route.routeReuseStrategy.shouldReuseRoute = function () {
          return false;
        }
        myclass.route.navigated = false;
        myclass.route.navigate([myclass.route.url]);
        this.bsModalRef.hide();
      } else {
        Library.notify(res.message, 'error');
      }
    });
    Library.hideloading();
  }
  goback() {
    let newrouter = "/system/execute";
    this.route.navigate([newrouter]);
    this.bsModalRef.hide();
  }
}


