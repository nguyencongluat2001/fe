import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Excute, ExcuteModel } from '../../models/ExcuteModel';
import { ApiService } from '../../services/api.service';
import { SendmarkpointComponent } from '../sendmarkpoint/sendmarkpoint.component';
import { EvictionComponent } from '../eviction/eviction.component';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Excutes: Excute[];
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  datetoday;
  toda;
  check: any;
  check1: any;
  check2 = 0;
  constructor(
    private HttpService: HttpService,
    public ExcuteModel: ExcuteModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    public apiService: ApiService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {

    };
    var date = new Date();
    this.datetoday = date.toLocaleDateString("en-US");
    Library.showloading();
    this.getAll();
    // this.Excutes = await this.ExcuteModel.getAll();
    // this.Excutes.forEach(element => {
    //   var fromdate = new Date(element.fromdate);
    //   var dateselect = fromdate.toLocaleDateString("en-US");
    //   var todate = new Date(element.todate);
    //   var todates = todate.toLocaleDateString("en-US");
    //   var status: any = element.status;
    //   if ((Date.parse(this.datetoday) < Date.parse(dateselect))) {
    //     element.name = element.name + "<i style='color:red'>" + " (Chưa đến thời gian đánh giá)" + "</i>";
    //   }
    //   if ((Date.parse(this.datetoday) > Date.parse(todates))) {
    //     element.name = element.name + "<i style='color:red'> (Đã hết thời gian đánh giá)</i>";
    //   }
    // });
    // this.Excutes.forEach(element => {
    //   var c_check = element.c_check;
    //   var c_check_fromdate = element.c_check_fromdate;
    //   // console.log(c_check);
    //   if (c_check_fromdate > 0) {
    //     element.name = element.name + "<i style='color:red'>" + " (Chưa đến thời gian đánh giá)" + "</i>";
    //   }
    //   if (c_check < 0) {
    //     element.name = element.name + "<i style='color:red'> (Đã hết thời gian đánh giá)</i>";
    //   }
    // });
    Library.hideloading();
  }
  getAll() {
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    let parram = { ownercode: unit_infor['code'] };
    this.HttpService.getMethods("excute/getall", parram).subscribe(
        result => {
          this.Excutes = result.data;
          this.Excutes.forEach(element => {
            var c_check = element.c_check;
            var c_check_fromdate = element.c_check_fromdate;
            // console.log(c_check);
            if (c_check_fromdate > 0) {
              element.name = element.name + "<i style='color:red'>" + " (Chưa đến thời gian đánh giá)" + "</i>";
            }
            if (c_check < 0) {
              element.name = element.name + "<i style='color:red'> (Đã hết thời gian đánh giá)</i>";
            }
          });
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
    var status = e.selectedRowsData.map(data => data.status);
    if (status == 'CHAM_DIEM') {
      this.check = true;
    }
    if (status == 'DANG_DANH_GIA' || status == 'TRA_LAI_DANH_GIA') {
      this.check1 = true;
    }

    this.selectedItems.forEach(element => {
      var c_check_todate = element.c_check;
      var c_check_fromdate = element.c_check_fromdate;
      // if (status != 'TRA_LAI_DANH_GIA') {
        if (c_check_todate < 0) {
          e.component.deselectRows(this.selectedItems);
        }
        if (c_check_fromdate > 0) {
          e.component.deselectRows(this.selectedItems);
        }
      // }
      // if (status == 'CHAM_DIEM' || status == 'DA_CHAM' || status == 'TRA_LAI_CHAM_DIEM') {
      //   if (Date.parse(this.datetoday) < Date.parse(dateselect)) {
      //     e.component.deselectRows(this.selectedItems);
      //   }
      //   if (Date.parse(this.datetoday) > Date.parse(todates)) {
      //     e.component.deselectRows(this.selectedItems);
      //   }
      // }
      // if(status == 'DANG_DANH_GIA' || status == 'TRA_LAI_DANH_GIA'){
      //   if (Date.parse(this.datetoday) < Date.parse(dateselect)) {
      //    this.check2=1;
      //   }
      //   if (Date.parse(this.datetoday) > Date.parse(todates)) {
      //     this.check2=1;
      //   }
      // }
    });




  }


  excution() {

    if (this.selectedItems.length > 1) {

      Library.notify("Chỉ được chọn một đối tượng để đánh giá", 'error');
      return;
    } else {
      this.ExcuteModel.Excute = this.selectedItems[0];
      if (this.ExcuteModel.Excute['status'] == 'DANG_DANH_GIA' || this.ExcuteModel.Excute['status'] == 'TRA_LAI_DANH_GIA') {
        let newrouter = "/system/execute/execute";
        this.route.navigate([newrouter]);
      } else {
        Library.notify("Đợt đánh giá này đã được gửi đi thẩm định", 'error');
        return;
      }

    }
  }
  see() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ExcuteModel.Excute = this.selectedItems[0];
      let newrouter = "/system/execute/see";
      this.route.navigate([newrouter]);
    }
  }
  showModal() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để gửi thẩm định", 'error');
      return;
    } else {
      this.ExcuteModel.objExcute = this.selectedItems[0];
      if (this.ExcuteModel.objExcute['status'] == 'DANG_DANH_GIA' || this.ExcuteModel.objExcute['status'] == 'TRA_LAI_DANH_GIA') {
        this.ExcuteModel.work = 'CHUYEN_HOI_DONG_CHAM_DIEM';
        this.modalService.show(SendmarkpointComponent, { backdrop: 'static', keyboard: false });
      } else {
        Library.notify("Đợt đánh giá đã được gửi chấm điểm", 'error');
        return;
      }

    }
  }

  result() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ExcuteModel.Excute = this.selectedItems[0];
      var a = this.ExcuteModel.Excute.name.search("<i style='color:red'>");
      if (a != -1) {
        var b = this.ExcuteModel.Excute.name.substr(0, a);
        this.ExcuteModel.Excute.name = b;
      }
      let newrouter = "/system/execute/result";
      this.route.navigate([newrouter]);
      //}

    }
  }
  printexecute() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để in", 'error');
      return;
    } else {
      this.ExcuteModel.objExcute = this.selectedItems[0];
      let a = this.ExcuteModel.printexcute();
    }
  }
  eviction() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để thu hồi", 'error');
      return;
    } else {
      this.ExcuteModel.objExcute = this.selectedItems[0];

      if (this.ExcuteModel.objExcute['status'] == 'CHAM_DIEM') {
        this.ExcuteModel.work = 'THU_HOI_DOT_DANH_GIA';
        this.modalService.show(EvictionComponent, { backdrop: 'static', keyboard: false });
      } else {
        Library.notify("Chỉ thu hồi được đợt đánh giá đang chấm điểm", 'error');
        return;
      }

    }
  }
  printFull() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để in", 'error');
      return;
    } else {
      this.ExcuteModel.objExcute = this.selectedItems[0];
      let a = this.ExcuteModel.printfull();
    }
  }

}
