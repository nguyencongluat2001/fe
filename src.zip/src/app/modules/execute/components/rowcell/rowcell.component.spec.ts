import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RowcellComponent } from './rowcell.component';

describe('RowcellComponent', () => {
  let component: RowcellComponent;
  let fixture: ComponentFixture<RowcellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RowcellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RowcellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
