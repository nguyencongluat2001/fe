import { Component, OnInit, Input } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ExcuteModel } from '../../models/ExcuteModel';

@Component({
  selector: 'app-rowcell',
  templateUrl: './rowcell.component.html',
  styleUrls: ['./rowcell.component.scss']
})
export class RowcellComponent implements OnInit {
  @Input() data: any;
  status: string = ''
  constructor() {

  }

  ngOnInit() {
    if (this.data['status'] == 'XEM_CHI_TIET') {
      this.data = this.data['data'];
      this.status = 'XEM_CHI_TIET';
    }
   
  }

}
