import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RouterLink } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { Excute, ExcuteModel } from '../../models/ExcuteModel';
import { ApiService } from '../../services/api.service';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';


@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {

  Excutes: Excute[];
  name: string = "";
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  constructor(
    private HttpService:HttpService,
    public ExcuteModel: ExcuteModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    public apiService: ApiService,
  ) {
  
   }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    this.name = "Kết quả của đợt đánh giá "+this.ExcuteModel._excute.name;
    var execute_group_id = this.ExcuteModel._excute.execute_group_id;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    };
    Library.showloading();
    this.seeresult(params);
    // this.Excutes = await this.ExcuteModel.seeresult(params);
    Library.hideloading();
  }
   //KẾT QUẢ CỦA ĐỢT ĐÁNH GIÁ
   seeresult(params) {
    this.HttpService.getMethods("excute/seeresult", params).subscribe(
        result => {
          this.Excutes = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  goBack() {
    let newrouter = "/system/execute";
    this.route.navigate([newrouter]);
  }
  
  
}

