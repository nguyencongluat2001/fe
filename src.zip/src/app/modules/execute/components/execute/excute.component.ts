import { Component, OnInit } from '@angular/core';
import { Excute, ExcuteModel } from '../../models/ExcuteModel';
import { ActivatedRoute, Router } from '@angular/router';
import list from 'devextreme/ui/list';
import { ReturnStatement } from '@angular/compiler';
import { BsModalService } from 'ngx-bootstrap/modal';
import { EvaluateComponent } from '../evaluate/evaluate.component';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-excute',
  templateUrl: './excute.component.html',
  styleUrls: ['./excute.component.scss']
})
export class ExecuteComponent implements OnInit {

  name: string = "";
  selectedItems: any;
  deltapoint: number;
  listidparent: string;
  widthexplanation: number = 250;
  onchangetree: any[] = [0];
  par;
  listData: any;
  is_return=true;
  old_point_self:any;
  constructor(
    private HttpService:HttpService,
    public ExcuteModel: ExcuteModel,
    private route: Router,
    private router: ActivatedRoute,
    private modalService: BsModalService,
  ) {

  }

  ngOnInit() {
    this.name = "";
    this.loadList();
  }


  async loadList() {
    let Myclass = this;
    var execute_group_id = this.ExcuteModel._excute.execute_group_id;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    };
    var status=this.ExcuteModel._excute.status;
    var is_return=this.ExcuteModel._excute.is_return;
   if(status=='TRA_LAI_DANH_GIA' && is_return =='1'){
      this.is_return=false;
   }
    Library.showloading();
    this.ExcuteModel.setLoadList(Myclass);

    this.ExcuteModel.getAllList(params);
    this.listData = this.ExcuteModel.listDataExcute;
    Library.hideloading();
  }
  onRowPrepared(e) {
    if (e.rowType == "data") {
      if (e.rowIndex % 2 == 0) {
        $(e.rowElement).addClass("dx-column-lines-color");
      }
    }
  }
  onEditingStart(e) {
    var item = e.data['islastitem'];
    if (item == 0) {
      e.cancel = true;
    }
    if (e.data.enquire == 'SOCIOLOGY' || e.data.enquire == 'SIPAS' || e.data.enquire == 'MULTICHOICESCALE' || e.data.enquire == 'MULTICHOICE' || this.is_return==false) {
      e.cancel = true;
    }
  }

  goBack() {
    let newrouter = "/system/execute";
    this.route.navigate([newrouter]);
  }

  checkValidating(e) {
    var point_self = e.newData['point_self'];
    var max_point = e.oldData['max_point'];
    var parrent_id = e.oldData['parrent_id'];
    var oldpoint_self = e.oldData['point_self'];
    var enquire = e.oldData['enquire'];

    if (oldpoint_self == null || oldpoint_self == '') {
      oldpoint_self = 0;
    }
    this.old_point_self=oldpoint_self;
    if (this.checkchild(e.oldData['id']) >= 0) {
      e.isValid = false;
      Library.notify('Không được chấm lĩnh vực cha', 'error');
    } else {
      if ((point_self > max_point && enquire != 'MINUS') || (point_self < 0 && enquire != 'MINUS') || isNaN(parseFloat(point_self))) {
        e.isValid = false;
        Library.notify('Điểm tự đánh giá phải nhỏ hơn điểm tối đa và lớn hơn 0', 'error');
      } else {
        if ((point_self > 0 || point_self < max_point) && enquire == 'MINUS') {
          e.isValid = false;
          Library.notify('Đánh giá điểm trừ nhỏ hơn 0 và lớn hơn điểm trừ tối đa', 'error');
        } else {
          if (parrent_id != '0') {
            let index = this.ExcuteModel.listDataExcute.findIndex(data => data.id == parrent_id);
            let listidparent = this.getlistidparent(parrent_id);
            let arrIdParent = listidparent.split('!~!');
            this.listidparent = listidparent;
            this.deltapoint = point_self - oldpoint_self;
            for (let j = 0; j < arrIdParent.length - 1; j++) {
              let arrParentsingle = arrIdParent[j].split(',');
              if (this.ExcuteModel.listDataExcute[arrParentsingle[1]]['point_self'] == null)
                this.ExcuteModel.listDataExcute[arrParentsingle[1]]['point_self'] = 0;
              this.ExcuteModel.listDataExcute[arrParentsingle[1]]['point_self'] = Math.round((parseFloat(this.ExcuteModel.listDataExcute[arrParentsingle[1]]['point_self']) + parseFloat(point_self) - parseFloat(oldpoint_self)) * 1000) / 1000;
            }
            // this.ExcuteModel.listDataExcute[index]['point_self'] = this.ExcuteModel.listDataExcute[index]['point_self'] + point_self - oldpoint_self;
          }
        }

      }
    }
  }

  checkchild(id) {
    let index = this.ExcuteModel.listDataExcute.findIndex(data => data.parrent_id == id);
    return index;
  }

  getlistidparent(parrent_id) {
    let index: number = -1;
    if (parrent_id == 0) {
      return '';
    } else {
      index = this.ExcuteModel.listDataExcute.findIndex(data => data.id == parrent_id);
      var newparentid: number;
      if (index == -1) {
        newparentid = 0;
      } else {
        newparentid = this.ExcuteModel.listDataExcute[index]['parrent_id'];
      }
      return parrent_id + ',' + index + '!~!' + <string>this.getlistidparent(newparentid)
    }
  }

  updateRow(e) {
    for (let i in this.ExcuteModel.listDataExcute) {
      if (this.ExcuteModel.listDataExcute[i].id == e.key) {
        this.ExcuteModel.listDataExcute[i].new_max_point = e.data['new_point'];
        break;
      }
    }
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    let params = {
      id: e.key,
      point_self: e.data['point_self'],
      ownercode: unit_infor['code'],
      listidparent: this.listidparent,
      deltapoint: this.deltapoint
    };
    let index = this.ExcuteModel.listDataExcute.findIndex(data => data.name == 'TONG_DIEM');
    this.ExcuteModel.listDataExcute[index].point_self = this.ExcuteModel.listDataExcute[index].point_self + e.data['point_self'] - this.old_point_self;
    // this.ExcuteModel.updateList(params);
    this.updateList(params);
  }
  updateList(params) {
    Library.showloading();
    this.HttpService.postMethods('excute/updatelistexcute', params).subscribe((response: any) => {
      Library.hideloading();
      if (!response.success) {
          Library.notify(response.message, 'error');
      }
    });
}
  openlist() {
    this.widthexplanation = 232;
    this.onchangetree = this.ExcuteModel.listDataExcute.map(listdata => listdata.id);
  }
  closelist() {
    this.widthexplanation = 250;
    this.onchangetree = [0];
  }
  onCellPrepared(e) {
    if (e.rowType == "data" && e.data.islastitem == 0 && e.column.dataField == "max_point") {
      $(e.cellElement).addClass("parent");
    }
  }
  onCellClick(e) {
    var enquire = e.data.enquire;
    var dataField = e.column.dataField;
    var islastitem = e.data.islastitem;
    if ((enquire == 'MULTICHOICE' || enquire == 'MULTICHOICESCALE') && dataField == 'point_self' && islastitem == 1 && this.is_return==true) {
      this.ExcuteModel.setEvalist = e.data;
      this.modalService.show(EvaluateComponent, { class: 'modal-hg', backdrop: 'static', keyboard: false });
    }
  }
}
