import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http'
// import { Headers, RequestOptions } from '@angular/http';
import { ExcuteModel } from '../../models/ExcuteModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-listexplanation',
  templateUrl: './listexplanation.component.html',
  styleUrls: ['./listexplanation.component.scss']
})
export class ListexplanationComponent implements OnInit {

  @Input() data: any;

  check = false;
  checkedit = false;
  baseUrl: string;
  headers: any;
  explanation: string;
  explanation_detail: any;
  listfile: string;
  listfile_detail: any;
  value: any[] = [];
  index: number;
  fileselected: File[] = [];
  arrfile: any = [];
  items: any = [];
  id;
  arritem;
  status: any;
  is_return:any;
  constructor(
    private HttpService:HttpService,
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private excuteModel: ExcuteModel,
    private route: Router,
  ) {
    this.baseUrl = environment.API_URL + 'excute/';
    let token = localStorage.getItem('token');
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Headers', 'Content-Type, X-XSRF-TOKEN');
    headers.append('Authorization', `Bearer ${token}`);
    this.headers = headers;
    this.explanation = this.excuteModel.getlist['explanation'];
    this.listfile = this.excuteModel.getlist['listfile'];
    this.is_return=this.excuteModel.Excute.is_return;
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    // this.arrfile = JSON.parse(this.listfile);
    let id = this.excuteModel.getlist['id'];
    this.index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == id);
    this.route.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
    this.loadlist();

  }

  ngOnInit() {
    this.excuteModel.dataview = '';
  }
  handleFileInput(event) {
    if (event.target.files[0].name != '') {
      this.fileselected.push(<File>event.target.files[0]);
    }
  }
  async loadlist() {
    let id = this.excuteModel.getlist['id'];
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    var execute_group_id = this.excuteModel.getlist['execute_group_id'];
    var param = {
      execute_id: id,
      ownercode: unit_infor['code'],
      execute_group_id: execute_group_id
    };
    Library.showloading();
    // this.items = await this.excuteModel.explanation_detail(param);
    this.explanation_detailsss(param)
    Library.hideloading();
  }
  explanation_detailsss(param) {
    this.HttpService.getMethods("excute/explanation_detail", param).subscribe(
        result => {
          this.items = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl = environment.API_BASE + 'file/openfile?namefile=' + namefile;
    window.open(baseurl);
  }
}
