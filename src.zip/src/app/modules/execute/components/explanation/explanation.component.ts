import { Component, OnInit, Input } from '@angular/core';
import { AddExplanationComponent } from '../add-explanation/add-explanation.component';
import { ListexplanationComponent } from '../listexplanation/listexplanation.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ExcuteModel } from '../../models/ExcuteModel';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-explanation',
  templateUrl: './explanation.component.html',
  styleUrls: ['./explanation.component.scss']
})
export class ExplanationComponent implements OnInit {

  @Input() data: any;
  arrfile: any = [];
  status: any;
  show: boolean;
  showexplan: boolean;
  index: number;
  fileview: any;
  is_return:any;
  name: string = '';
  constructor(
    private modalService: BsModalService,
    public excuteModel: ExcuteModel
  ) {
  }

  ngOnInit() {

    if (this.data['status'] == 'XEM_CHI_TIET') {
      this.status = this.data['status'];
      this.data = this.data.data;
    }
    this.show = false;
    this.showexplan = true;
    this.index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == this.data['id']);
    if (this.excuteModel.listDataExcute[this.index]['listfile'] != '') {
      this.show = true;
    }
    if (this.excuteModel.listDataExcute[this.index]['explanation'] == null || this.excuteModel.listDataExcute[this.index]['explanation'] == 'null') {
      this.excuteModel.listDataExcute[this.index]['explanation'] = [];
    }

    if (this.excuteModel.listDataExcute[this.index]['explanation'] != '' && this.excuteModel.listDataExcute[this.index]['explanation'] != null) {
      this.showexplan = true;
    }
    this.is_return=this.excuteModel.Excute.is_return;
    this.name = this.data.name;
  }
  showModal() {
    this.excuteModel.setlist = this.data;
    this.modalService.show(AddExplanationComponent, { backdrop: 'static', keyboard: false });
  }
  showexplandetail() {
    this.excuteModel.setlist = this.data;
    this.modalService.show(ListexplanationComponent, { backdrop: 'static', keyboard: false });
  }
   openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);
   

  }
}
