import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendmarkpointComponent } from './sendmarkpoint.component';

describe('SendmarkpointComponent', () => {
  let component: SendmarkpointComponent;
  let fixture: ComponentFixture<SendmarkpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendmarkpointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendmarkpointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
