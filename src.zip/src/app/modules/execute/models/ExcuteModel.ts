import { Injectable } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';


export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: any;
    ownercode: string = localStorage.getItem('unit_infor')['code'];
    is_return:string;
    c_check:any;
    c_check_fromdate:any;
}

export class List {
    id: string;
    parrent_id: string;
    name: string;
    max_point: number;
    new_point: number;
    explanation: string;
    listfile: string;
    enquire: string;
    explanation_id: string;
    ownercode: string;
}


@Injectable()

export class ExcuteModel {

    _excute: Excute;
    objExcute: any;
    loadList:any;
    private _list: List;
    private _dataview: any;
    public listDataExcute: any;
    public _evaluationList: any;
    work: any;
    public fileview: any;

    constructor(private HttpService:HttpService, private apiservice: ApiService, private route: Router) {

    }

    set Excute(value: any) {
        this._excute = value;
    }

    get Excute() {
        return this._excute;
    }
    set setlist(value: any) {
        this._list = value;
    }

    get getlist() {
        return this._list;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }
    set getwork(value: any) {
        this.work = value;
    }
    set setEvalist(value: any) {
        this._evaluationList = value;
    }

    get getEvalist() {
        return this._evaluationList;
    }

    get setwork() {
        return this.work;
    }
    setLoadList(Myclass) {
        return this.loadList = Myclass;
    }
    // async getAll(async: boolean = false): Promise<Excute[]> {
    //     var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    //     let parram = { ownercode: unit_infor['code'] };
    //     let response = await this.apiservice.callGet('getall', parram);
    //     return response.data;
    // }
    async getTotalPoint(parram, async: boolean = false): Promise<Excute[]> {
        let response = await this.apiservice.callGet('getTotalPoint', parram);
        return response;
    }
    getAllList(params) {
        this.HttpService.getMethods("excute/getallList", params).subscribe(
            result => {
                this.listDataExcute = result.data;
                    for (let i = 0; i < this.listDataExcute.length; i++) {
                        if (this.listDataExcute[i]['listfile'] == '') {
                            this.listDataExcute[i]['listfile'] = null;
                        }
                        else {
                            this.listDataExcute[i]['listfile'] = JSON.parse(this.listDataExcute[i]['listfile']);
                        }
                        if (this.listDataExcute[i]['explanation'] == '') {
                            this.listDataExcute[i]['explanation'] = null;
                        }
                        else {
                            this.listDataExcute[i]['explanation'] = JSON.parse(this.listDataExcute[i]['explanation']);
                        }
                    }
            },
            (error) => {
              Library.hideloading();
            }
          );
      }
    printexcute() {
        Library.showloading();
        let params = {
            excutegroupid: this.objExcute['execute_group_id'],
            ownercode: this.objExcute['ownercode'],
        }
        this.HttpService.postMethods('excute/printexcute', params).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            } else {
                window.location.href = response.urlfile;
            }
        });
    }
    printfull() {
        Library.showloading();
        let params = {
            excutegroupid: this.objExcute['execute_group_id'],
            ownercode: this.objExcute['ownercode'],
        }
        this.HttpService.postMethods('excute/printfull', params).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            } else {
                window.location.href = response.urlfile;
            }
        });
    }

    async updateexternalexcute(data, bsModalRef, myclass) {
        Library.showloading();
        let params = {
            data: data,
            evaluation_list_id: this._evaluationList.evaluation_list_id,
            excutelist: this._evaluationList.id,
            ownercode: this._evaluationList.ownercode,
            parrent_id: this._evaluationList.parrent_id,
        }
        await this.HttpService.postMethods('excute/updateexternalexcute', params).subscribe(async (response: any) => {
            if (!response.success) {
                Library.notify(response.message, 'error');
            } else {
                // var execute_group_id = this._excute.execute_group_id;
                // let params = {
                //     excute_id: execute_group_id,
                //     ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
                // };
                // await this.getAllList(params);
                var arrdata = response.arrdata;
                for (let j = 0; j < arrdata.length; j++) {
                    let index = this.listDataExcute.findIndex(data => data.id == arrdata[j].execute_list);
                    // console.log(index);
                    this.listDataExcute[index]['index'] = arrdata[j].index;
                    this.listDataExcute[index]['point_self'] = arrdata[j].point_self;
                    this.listDataExcute[index]['ket_qua_tc_danh_gia'] = Math.round(arrdata[j].ket_qua_tc_danh_gia * 100)/100;
                    this.listDataExcute[index]['tc_danh_gia_1'] = arrdata[j].tc_danh_gia_1;
                    this.listDataExcute[index]['tc_danh_gia_2'] = arrdata[j].tc_danh_gia_2;
                    this.listDataExcute[index]['tc_danh_gia_3'] = arrdata[j].tc_danh_gia_3;
                    this.listDataExcute[index]['ket_qua_tn_danh_gia'] = arrdata[j].ket_qua_tn_danh_gia;

                }
                bsModalRef.hide();
                Library.hideloading();
                let index1 = this.listDataExcute.findIndex(data => data.name ==  'TONG_DIEM');
                var param = {
                'execute_group_id': this._evaluationList.execute_group_id,
                'ownercode': this._evaluationList.ownercode,
                };
                myclass.getTotalPoint(param,index1);
                this.loadList.loadList();
            }
        });
    }
}
