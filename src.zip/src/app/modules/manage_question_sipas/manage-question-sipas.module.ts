import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule } from 'devextreme-angular';
import { DxListModule } from 'devextreme-angular';
import { DxCheckBoxModule,DxSelectBoxModule,DxTagBoxModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ManageQuestionRoutingModule } from './manage-question-sipas-routing.module';
import { DxChartModule } from 'devextreme-angular';
import { ManageQuestionModel } from '../manage_question_sipas/models/ManageQuestionModel';
import { ManageQuestionService } from '../manage_question_sipas/services/manage-question.service';
import { IndexComponent } from './components/index/index.component';
import { AddComponent } from './components/add/add.component';
import { AddSurveyComponent } from './components/add_survey/add_survey.component';
import { AddAnswerComponent } from './components/add_answer/add_answer.component';
import { ListquestionComponent } from './components/list_question/list_question.component';
import { ListAnswerComponent } from './components/list_answer/list_answer.component';
import { ListChildComponent } from './components/list_child/list_child.component';
import { AddChildComponent } from './components/add_child/add_child.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ManageQuestionRoutingModule,
    DxChartModule,
    DxCheckBoxModule,
    DxSelectBoxModule,
    DxTagBoxModule,
    DxListModule
  ],
  // entryComponents: [AddComponent,AddSurveyComponent,AddAnswerComponent,AddChildComponent
  // ],
  providers: [ ManageQuestionModel,ManageQuestionService],
  declarations: [IndexComponent,AddComponent,AddSurveyComponent,ListquestionComponent,AddAnswerComponent,
    ListAnswerComponent,ListChildComponent,AddChildComponent],
})
export class ManageQuestionSipasModule { }

