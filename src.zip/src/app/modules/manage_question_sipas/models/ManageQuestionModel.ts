import { Injectable } from '@angular/core';
import { ManageQuestionService } from '../services/manage-question.service';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';


export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: number = 0;
    max_point:number;
    ownercode: string = localStorage.getItem('unit_infor')['code']

}
export class Question {
    id : string = '';
    name : string = '';
    name_textarea : string = '';
    type_vote : string = '';
    type_question : string = '';
    pattern_question_code : string = '';
    group_question_code : string = '';
    plan_1 : string = '';
    plan_2 : string = '';
    plan_3 : string = '';
    plan_4 : string = '';
    plan_5 : string = '';
    plan_6 : string = '';
    plan_7 : string = '';
    other : string = '';
    other_check : string = '';
    order : string = '';
    status : string = '';
    status_check : string = '';
    statusOther : string = '';
    planAdd_5 : string = '';
    planAdd_6 : string = '';
    planAdd_7 : string = '';
    
}
export class Survey {
    id: string = '';
    code: string = '';
    name: string = '';
    year: number;
    statu: string = '';
    order: number;
    ownercode: string = localStorage.getItem('unit_infor')['code']

}
export class Answer {
    pk_dap_an_ks: string = '';
    fk_cau_hoi_ks: string = '';
    fk_dap_an_ks: string = '';
    ma_dap_an: number;
    ten_dap_an: string = '';
    check_mo_rong: string = '';
    ghi_chu_mo_rong: number;
    check_ghi_chu: string = '';
    check_tinh_tong: string = '';
    thu_tu: number;
}
@Injectable()

export class ManageQuestionModel {

    _excutelist: Excute;
    objExcute: any;
    _question:any;
    _dataview: any;
    _dot_khao_sat:Survey;
    _Answer:Answer;
    survey_sipas:any;
    type_unit:any;
    constructor(private HttpService:HttpService,private ManageQuestionService: ManageQuestionService, private route: Router) {

    }

    // async getAll(getAll,async: boolean = false): Promise<Survey[]> {
    //     var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    //     let response = await this.ManageQuestionService.callGet('getall', parram);
    //     return response;
    // }
    
    
  
    set ExcuteList(value: any) {
        this._excutelist = value;
    }

    get ExcuteList() {
        return this._excutelist;
    }
    set question(value: any) {
        this._question = value;
    }
    
    set survey(value: any) {
        this._dot_khao_sat = value;
    }

    get survey() {
        return this._dot_khao_sat;
    }
    set answer(value: any) {
        this._Answer = value;
    }

    get answer() {
        return this._Answer;
    }
    get question() {
        return this._question;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }
    getQuestion(){
        if(!this._dataview){
            this._dataview = new Question();
        }
        return this._dataview;
    }

    setQuestion(data){
        if(!data){
            data = new Question();
            if(this._dataview){
                data.order = this._dataview.length + 1;
            }
        }
        this._dataview = data;
    }
    set_survey_sipas(data){
        this.survey_sipas = data;
    }
    get_survey_sipas(){
        return this.survey_sipas;
    }
    SetTypeUnit(data){
        this.type_unit = data;
    }
    GetTypeUnit(){
        return this.type_unit;
    }


   
    update(data, activeModal) {
        Library.showloading();
        this.HttpService.postMethods('managesipas/managequestionsipas/update', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                activeModal.hide();
                Library.notify(response.message, 'success');
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                let newrouter = "";
                if (this.route.url == "/system/manage_question_sipas") {
                    newrouter = "/system/manage_question_sipas/index";
                } else {
                    newrouter = "/system/manage_question_sipas";
                }
                this.route.navigate([newrouter]);
                // }
              
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }
    updateQuestionSipas(data, activeModal) {
        // Library.showloading();
        let myClass = this;
        this.HttpService.postMethods('managesipas/managequestionsipas/updateQuestionSipas', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                activeModal.hide();
                Library.notify(response.message, 'success');
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                    myClass.route.routeReuseStrategy.shouldReuseRoute = function () {
                        return false;
                    }
                    myClass.route.navigated = false;
                    myClass.route.navigate([myClass.route.url]);
              
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }
    deleteEventtype(data, MyClass) {
        Library.showloading();
        this.HttpService.postMethods('managesipas/managequestionsipas/deletes', data).subscribe((response: any) => {
            if (response.success) {
                Library.notify(response.message, 'success');
                MyClass.loadList();
            } else {
                Library.notify(response.message, 'error');
            }
            Library.hideloading();
        }, error => {
            Library.hideloading();
            Library.notify(error, 'error');
        });
    }
    
    async getInfo(parram,async: boolean = false): Promise<Question[]> {
        let response = await this.ManageQuestionService.callGet('getInfo', parram);
        return response;
    }
    async getAnswer(parram,async: boolean = false): Promise<Answer[]> {
        let response = await this.ManageQuestionService.callGet('getAnswer', parram);
        return response;
    }
    async getListquestion(parram,async: boolean = false): Promise<Question[]> {
        let response = await this.ManageQuestionService.callGet('getListquestion', parram);
        return response;
    }
    async getYear(parram,async: boolean = false): Promise<Question[]> {
        let response = await this.ManageQuestionService.callGet('getyear', parram);
        return response;
    }
    deletesQuestion(data, MyClass) {
        Library.showloading();
        let myClass = this;
        this.HttpService.postMethods('managesipas/managequestionsipas/deletesQuestion', data).subscribe((response: any) => {
            if (response.success) {
                Library.notify(response.message, 'success');
                myClass.route.routeReuseStrategy.shouldReuseRoute = function () {
                    return false;
                }
                myClass.route.navigated = false;
                myClass.route.navigate([myClass.route.url]);
            } else {
                Library.notify(response.message, 'error');
            }
            Library.hideloading();
        }, error => {
            Library.hideloading();
            Library.notify(error, 'error');
        });
    }
    deletesAnswer(data, MyClass) {
        Library.showloading();
        let myClass = this;
        this.HttpService.postMethods('managesipas/managequestionsipas/deletesAnswer', data).subscribe((response: any) => {
            if (response.success) {
                Library.notify(response.message, 'success');
                myClass.route.routeReuseStrategy.shouldReuseRoute = function () {
                    return false;
                }
                myClass.route.navigated = false;
                myClass.route.navigate([myClass.route.url]);
            } else {
                Library.notify(response.message, 'error');
            }
            Library.hideloading();
        }, error => {
            Library.hideloading();
            Library.notify(error, 'error');
        });
    }
    updateAnswer(data, activeModal) {
        Library.showloading();
        let myClass = this;
        this.HttpService.postMethods('managesipas/managequestionsipas/updateAnswer', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                activeModal.hide();
                Library.notify(response.message, 'success');
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                    myClass.route.routeReuseStrategy.shouldReuseRoute = function () {
                        return false;
                    }
                    myClass.route.navigated = false;
                    myClass.route.navigate([myClass.route.url]);
              
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }
   
   
    updateAnswerChild(data, activeModal) {
        Library.showloading();
        let myClass = this;
        this.HttpService.postMethods('managesipas/managequestionsipas/updateAnswerChild', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                activeModal.hide();
                Library.notify(response.message, 'success');
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                    myClass.route.routeReuseStrategy.shouldReuseRoute = function () {
                        return false;
                    }
                    myClass.route.navigated = false;
                    myClass.route.navigate([myClass.route.url]);
              
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }
    async getListAnswerExtend(parram,async: boolean = false): Promise<Question[]> {
        let response = await this.ManageQuestionService.callGet('getListAnswerExtend', parram);
        return response;
    }
    async getLoaiCauHoi(parram,async: boolean = false): Promise<Question[]> {
        let response = await this.ManageQuestionService.callGet('getLoaiCauHoi', parram);
        return response;
    }






}
