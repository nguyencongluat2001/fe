import { Component, OnInit, ElementRef } from '@angular/core';
import { Answer, ManageQuestionModel } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-add-answer',
  templateUrl: './add_answer.component.html',
  styleUrls: ['./add_answer.component.scss']
})
export class AddAnswerComponent implements OnInit {

  answer: Answer;
  pk_dap_an_ks: string = '';
  fk_dap_an_ks:string='';
  ma_dap_an: string = '';
  ten_dap_an: string = '';
  check_mo_rong: string = '';
  ghi_chu_mo_rong: string = '';
  check_ghi_chu: string = '';
  check_tinh_tong: string = '';
  thu_tu: any;
  check = false;
  checkmorong = false;
  checktong = false;
  arrtype: any;
  checkchild = false;
  arrAnswer:any;
  a=0;
  constructor(
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private route: Router,
    public bsModalRef: BsModalRef,
    private elementRef: ElementRef
  ) {
    this.answer = this.ManageQuestionModel.answer;
    this.thu_tu = this.answer.thu_tu;
    // console.log(String.fromCharCode(65+this.thu_tu);
    this.ma_dap_an='DAP_AN_'+String.fromCharCode(64+this.thu_tu);
    if (this.ManageQuestionModel.answer.pk_dap_an_ks != '') {
      this.ma_dap_an = this.ManageQuestionModel.answer.ma_dap_an;
      // this.typeVote = this.ManageQuestionModel.answer.type_vote;
      this.ten_dap_an = this.ManageQuestionModel.answer.ten_dap_an;
      this.check_mo_rong = this.ManageQuestionModel.answer.check_mo_rong;
      this.ghi_chu_mo_rong = this.ManageQuestionModel.answer.ghi_chu_mo_rong;
      this.check_tinh_tong = this.ManageQuestionModel.answer.check_tinh_tong;
      this.check_ghi_chu = this.ManageQuestionModel.answer.check_ghi_chu;
      this.pk_dap_an_ks = this.ManageQuestionModel.answer.pk_dap_an_ks;
      this.fk_dap_an_ks = this.ManageQuestionModel.answer.fk_dap_an_ks;
      // console.log( this.fk_dap_an_ks);
      if (this.check_tinh_tong == '1') {
        this.checktong = true;
      }
      if (this.check_ghi_chu == '1') {
        this.check = true;
      }
      if (this.check_mo_rong == '1') {
        this.checkmorong = true;
      }
      if (this.fk_dap_an_ks != '' && this.fk_dap_an_ks !=null) {
        this.checkchild = true;
        this.a=1;
      }


    }

  }

  ngOnInit() {
    this.loadList();
    this.getListAnswerExtend();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {

  }

  onSubmit(e) {
    if (this.check == true) {
      this.check_ghi_chu = '1';

    }
    else {
      this.check_ghi_chu = '0';
    }
    if (this.checktong == true) {
      this.check_tinh_tong = '1';

    }
    else {
      this.check_tinh_tong = '0';
    }
    var param = {
      pk_dap_an_ks: this.answer.pk_dap_an_ks,
      ma_dap_an: this.ma_dap_an,
      ten_dap_an: this.ten_dap_an,
      check_mo_rong: this.check_mo_rong,
      ghi_chu_mo_rong: this.ghi_chu_mo_rong,
      check_ghi_chu: this.check_ghi_chu,
      check_tinh_tong: this.check_tinh_tong,
      thu_tu: this.thu_tu,
      fk_cau_hoi_ks: this.ManageQuestionModel.answer.fk_cau_hoi_ks,
      fk_dap_an_ks:this.fk_dap_an_ks,

    }
    this.ManageQuestionModel.updateAnswer(param, this.bsModalRef);

  }

  goback() {
    let newrouter = "/system/manage_question_sipas/getListAnswer";
    if (this.route.url == newrouter) {
      let newrouter1 = "/system/manage_question_sipas/getListAnswer";
      this.route.navigate([newrouter1]);
    }
    else {
      this.route.navigate([newrouter]);
    }

    this.bsModalRef.hide();
  }

  onValueChanged(e) {
    this.check = e.value;
    if (e.value == true) {
      this.check_ghi_chu = '1';

    }
    else {
      this.check_ghi_chu = '0';
    }
  }
  onValueChangedTotal(e) {
    this.checktong = e.value;
    if (e.value == true) {
      this.check_tinh_tong = '1';

    }
    else {
      this.check_tinh_tong = '0';
    }
  }
  onValueChangedExtend(e) {
    this.checkmorong = e.value;
    if (e.value == true) {
      this.check_mo_rong = '1';

    }
    else {
      this.check_mo_rong = '0';
    }
  }
  onValueChangedChild(e){
  this.checkchild=e.value;
  // console.log(this.checkchild);
  if (e.value == true) {
    this.getListAnswerExtend();
    this.a=1;
  }
  else{
    this.a=0;
    this.fk_dap_an_ks ='';
  }
  
  }
  async getListAnswerExtend() {
    let params = {
      pk_cau_hoi_ks: this.ManageQuestionModel.answer.fk_cau_hoi_ks
    };
    Library.showloading();
    this.arrAnswer = await this.ManageQuestionModel.getListAnswerExtend(params);
    Library.hideloading();
  }
  changeAnswer(e) {
    // console.log(e);
        this.fk_dap_an_ks =e.selectedItem.pk_dap_an_ks;
    
      }

}

