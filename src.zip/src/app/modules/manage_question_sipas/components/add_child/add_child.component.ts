import { Component, OnInit, enableProdMode, NgModule, ElementRef } from '@angular/core';
import { Answer, ManageQuestionModel } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-add-child',
  templateUrl: './add_child.component.html',
  styleUrls: ['./add_child.component.scss']
})
export class AddChildComponent implements OnInit {

  answer: Answer;
  pk_dap_an_ks: string = ';'
  ma_dap_an: string = '';
  ten_dap_an: string = '';
  cau_hoi_mo_rong: string = '';
  ghi_chu_mo_rong: string = '';
  ghi_chu: string = '';
  tinh_tong: string = '';
  thu_tu: any;
  check = false;
  checkmorong = false;
  checktong = false;
  arrtype: any;
  constructor(
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private route: Router,
    public bsModalRef: BsModalRef,
    private elementRef: ElementRef
  ) {
    this.answer = this.ManageQuestionModel.answer;
    this.thu_tu = this.answer.thu_tu;
    if (this.ManageQuestionModel.answer.pk_dap_an_ks != '') {
      this.ma_dap_an = this.ManageQuestionModel.answer.ma_dap_an;
      // this.typeVote = this.ManageQuestionModel.answer.type_vote;
      this.ten_dap_an = this.ManageQuestionModel.answer.ten_dap_an;
      this.cau_hoi_mo_rong = this.ManageQuestionModel.answer.cau_hoi_mo_rong;
      this.ghi_chu_mo_rong = this.ManageQuestionModel.answer.ghi_chu_mo_rong;
      this.tinh_tong = this.ManageQuestionModel.answer.tinh_tong;
      this.ghi_chu = this.ManageQuestionModel.answer.ghi_chu;
      this.pk_dap_an_ks = this.ManageQuestionModel.answer.pk_dap_an_ks;
      if (this.tinh_tong == '1') {
        this.checktong = true;
      }
      if (this.ghi_chu == '1') {
        this.check = true;
      }
      if (this.cau_hoi_mo_rong == '1') {
        this.checkmorong = true;
      }

    }

  }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {

  }

  onSubmit(e) {
    if (this.check == true) {
      this.ghi_chu = '1';

    }
    else {
      this.ghi_chu = '0';
    }
    if (this.checktong == true) {
      this.tinh_tong = '1';

    }
    else {
      this.tinh_tong = '0';
    }
    var param = {
      pk_dap_an_ks: this.answer.pk_dap_an_ks,
      ma_dap_an: this.ma_dap_an,
      ten_dap_an: this.ten_dap_an,
      cau_hoi_mo_rong: this.cau_hoi_mo_rong,
      ghi_chu_mo_rong: this.ghi_chu_mo_rong,
      ghi_chu: this.ghi_chu,
      tinh_tong: this.tinh_tong,
      thu_tu: this.thu_tu,
      fk_cau_hoi_ks: this.ManageQuestionModel.answer.fk_cau_hoi_ks

    }
    this.ManageQuestionModel.updateAnswer(param, this.bsModalRef);

  }

  goback() {
    let newrouter = "/system/manage_question_sipas/getListAnswer";
    if (this.route.url == newrouter) {
      let newrouter1 = "/system/manage_question_sipas/getListAnswer";
      this.route.navigate([newrouter1]);
    }
    else {
      this.route.navigate([newrouter]);
    }

    this.bsModalRef.hide();
  }

  onValueChanged(e) {
    this.check = e.value;
    if (e.value == true) {
      this.ghi_chu = '1';

    }
    else {
      this.ghi_chu = '0';
    }
  }
  onValueChangedTotal(e) {
    this.checktong = e.value;
    if (e.value == true) {
      this.tinh_tong = '1';

    }
    else {
      this.tinh_tong = '0';
    }
  }
  onValueChangedExtend(e) {
    this.checkmorong = e.value;
    if (e.value == true) {
      this.cau_hoi_mo_rong = '1';

    }
    else {
      this.cau_hoi_mo_rong = '0';
    }
  }

}

