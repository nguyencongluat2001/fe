import { Component, OnInit } from '@angular/core';
import { ManageQuestionModel,Question } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddComponent } from '../add/add.component';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
@Component({
  selector: 'app-list-question',
  templateUrl: './list_question.component.html',
  styleUrls: ['./list_question.component.scss']
})
export class ListquestionComponent implements OnInit {

  Question: any;
  bsModalRef: BsModalRef;
  selectedItems: Question[] = [];
  export_chart: any;
  txtsearch:any;
  txt_search:any;
  arrLoaiphieu:any;
  arrLoaiphieu_loc:any;
  type_vote:any;

  constructor(
    private HttpService:HttpService,
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private modalService: BsModalService,
    private route: Router,
  ) { }

  ngOnInit() {
    this.loadList();
    this.getInfo();
    // console.log(this.ManageSipasModel.Excute);
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      pk_dot_ks: this.ManageQuestionModel.survey.id,
      type_vote:this.type_vote,
      txt_search:this.txt_search,
    };
    Library.showloading();
    this.getListquestion(params);
    // this.Question = await this.ManageQuestionModel.getListquestion(params);
    // this.type_vote = this.type_vote;
    // this.ManageQuestionModel.SetTypeUnit(this.type_vote);
    Library.hideloading();
  }
  getListquestion(params) {
    this.HttpService.getMethods("managesipas/managequestionsipas/getListquestion", params).subscribe(
        result => {
          this.Question = result.data;
          this.type_vote = this.type_vote;
          this.ManageQuestionModel.SetTypeUnit(this.type_vote);
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  getInfo() {
    var param = {
      fk_dot_ks: this.ManageQuestionModel.survey.id
    };
    this.HttpService.getMethods("managesipas/managequestionsipas/getInfo", param).subscribe(
        result => {
          var arrinfo = result.data;
          this.arrLoaiphieu = arrinfo['arrLoaiphieu'];
          this.arrLoaiphieu_loc = arrinfo['arrLoaiphieu_loc'];
          this.type_vote = this.ManageQuestionModel.GetTypeUnit();
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  search(e){
    this.txt_search = this.txtsearch;
    this.loadList()
  }
  convertFromdate(data) {
    return Library.formatDate(data.date_update_sociology);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  add(){
 
    this.ManageQuestionModel.question = new Question;
    this.ManageQuestionModel.question.thu_tu=1;
    if(this.Question.length>0){
      this.ManageQuestionModel.question.thu_tu= this.Question.length+1;
    }
    
    this.ManageQuestionModel.question.fk_dot_ks= this.ManageQuestionModel.survey.pk_dot_ks;
    this.modalService.show(AddComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
    
  }
  edit() {
    
    let i = 0;
    let a;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để sửa", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để sửa", 'error');
      return;
    } else if (i == 1) {
      this.ManageQuestionModel.question = this.selectedItems[0];
      this.modalService.show(AddComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false  });
    }

    

  }

  delete() {
    let Myclass = this;
    let selectedItems = this.selectedItems;
    let ids = '';
    let data = {
      ids: ""
    };
    var result = Library.confirm("Bạn có chắc chắn muốn xóa đối tượng đã chọn?", "Thông báo");
    if (result) {
      result.then(function (dialogResult) {
        if (dialogResult) {
          selectedItems.forEach((item) => {
            ids += item['id'] + ',';
          });
          data.ids = ids;
          Myclass.ManageQuestionModel.deletesQuestion(data, Myclass);
        }
      });
    }
  }
  goback() {
    let newrouter = "/system/manage_question_sipas";
    this.route.navigate([newrouter]);
  }
  listAnswer(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ManageQuestionModel.question = this.selectedItems[0];
      let newrouter='/system/manage_question_sipas/getListAnswer';
      this.route.navigate([newrouter]);
    }
  }
  changeLoaiphieu(e){
    this.type_vote = e.selectedItem.code;
    this.loadList()

  }
}

