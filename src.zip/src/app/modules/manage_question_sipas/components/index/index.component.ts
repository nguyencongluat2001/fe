import { Component, OnInit } from '@angular/core';
import { Survey, ManageQuestionModel } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddSurveyComponent } from '../add_survey/add_survey.component';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Survey: Survey[];
  bsModalRef: BsModalRef;
  selectedItems: Survey[] = [];
  export_chart: any;
  constructor(
    public HttpService:HttpService,
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private modalService: BsModalService,
    private route: Router,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    };
    Library.showloading();
    this.getAll(params);
    // this.Survey = await this.ManageQuestionModel.getAll(params);
    Library.hideloading();
  }
  getAll(params) {
    this.HttpService.getMethods("managesipas/managequestionsipas/getall", params).subscribe(
        result => {
          this.Survey = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  
  add_survey(){
 
    this.ManageQuestionModel.survey = new Survey;
    this.ManageQuestionModel.survey.thu_tu= this.Survey.length+1;
    this.modalService.show(AddSurveyComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
    
  }
  edit() {
    
    let i = 0;
    let a;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để sửa", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để sửa", 'error');
      return;
    } else if (i == 1) {
      this.ManageQuestionModel.survey = this.selectedItems[0];
      this.modalService.show(AddSurveyComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false  });
    }

    

  }

  delete() {
    let Myclass = this;
    let selectedItems = this.selectedItems;
    let ids = '';
    let data = {
      ids: ""
    };
    var result = Library.confirm("Bạn có chắc chắn muốn xóa đối tượng đã chọn?", "Thông báo");
    if (result) {
      result.then(function (dialogResult) {
        if (dialogResult) {
          selectedItems.forEach((item) => {
            ids += item.id + ',';
          });
          data.ids = ids;
          Myclass.ManageQuestionModel.deleteEventtype(data, Myclass);
        }
      });
    }
  }
  getListQuestion(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ManageQuestionModel.survey = this.selectedItems[0];
      this.ManageQuestionModel.set_survey_sipas(this.selectedItems[0]);
      let newrouter='/system/manage_question_sipas/getListquestion';
      this.route.navigate([newrouter]);
    }
  }
 
}

