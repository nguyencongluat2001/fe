import { Component, OnInit, enableProdMode, NgModule,ElementRef } from '@angular/core';
import { Question, ManageQuestionModel } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {

  question: Question;
  // question:any;
  //luatnc
  survey_sipas:any;
  user_id:any;
  id:any;
  name: any;
  name_textarea:any;
  type_vote: any;
  type_question :any = 'RADIO';
  group_question_code: any;
  pattern_question_code: any;
  level_unit: any;
  plan_1: any;
  plan_2: any;
  plan_3: any;
  plan_4: any;
  plan_5: any;
  plan_6: any;
  plan_7: any;
  status: any;
  status_check: any;
  other_check = false;
  
  order: any; 
  check = true;
  arrLoaicauhoi:any;
  arrNhomcauhoi:any;
  arrLoaiphieu:any;
  arrCauhoi:any;
  arrDapan:any;
  arrtype:any;
  addPlanColum:any = '1';
  planAdd:any;
  planAdd_5:any;
  planAdd_6:any;
  planAdd_7:any;
  other:any;
  statusOther:any;
  dataChangeNhomCauHoi:any;
  c='A';
  constructor(
    private HttpService:HttpService,
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private route: Router,
    public bsModalRef: BsModalRef,
    private elementRef:ElementRef
  ) {
    this.survey_sipas = ManageQuestionModel.get_survey_sipas();

    this.question = this.ManageQuestionModel.question;
    if (this.ManageQuestionModel.question != '') {
      this.id = this.ManageQuestionModel.question.id;
      this.name = this.ManageQuestionModel.question.name;
      this.name_textarea = this.ManageQuestionModel.question.name_textarea;
      this.type_vote = this.ManageQuestionModel.question.type_vote;
      this.type_question = this.ManageQuestionModel.question.type_question;
      this.pattern_question_code = this.ManageQuestionModel.question.pattern_question_code;
      this.group_question_code =  this.ManageQuestionModel.question.group_question_code;
      this.plan_1 = this.ManageQuestionModel.question.plan_1;
      this.plan_2 = this.ManageQuestionModel.question.plan_2;
      this.plan_3 = this.ManageQuestionModel.question.plan_3;
      this.plan_4 = this.ManageQuestionModel.question.plan_4;
      this.plan_5 = this.ManageQuestionModel.question.plan_5;
      this.plan_6 = this.ManageQuestionModel.question.plan_6;
      this.plan_7 = this.ManageQuestionModel.question.plan_7;
      this.other = this.ManageQuestionModel.question.other;
      this.other_check = this.ManageQuestionModel.question.other;
      this.order = this.ManageQuestionModel.question.order;
      this.status = this.ManageQuestionModel.question.status;
      this.status_check = this.ManageQuestionModel.question.status;
      this.statusOther = this.ManageQuestionModel.question.statusOther;
      //hiển thị phương án 5,6,7 nếu có
      this.planAdd_5 = this.ManageQuestionModel.question.planAdd_5;
      this.planAdd_6 = this.ManageQuestionModel.question.planAdd_6;
      this.planAdd_7 = this.ManageQuestionModel.question.planAdd_7;

    }

  }

  ngOnInit() {
    if(this.ManageQuestionModel.question.status == 1 || this.ManageQuestionModel.question.status == ''){
      this.status_check = true;
    }else if(this.ManageQuestionModel.question.status == 2){
      this.status_check = false;
    }
    if(this.type_question == undefined || this.type_question == ''){
      this.type_question = 'RADIO';
    }
    // this.order = 1;
    this.loadList();
    this.getInfo();
    // this.getAnswer();
    this.gettype();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {


  }

  onSubmit(e) {
    var param = {
      id: this.id,
      survey_sipas_id: this.survey_sipas.id,
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      name: this.name,
      name_textarea:this.name_textarea,
      type_vote: this.type_vote,
      type_question: this.type_question,
      group_question_code: this.group_question_code,
      pattern_question_code: this.pattern_question_code,
      level_unit: this.level_unit,
      plan_1: this.plan_1,
      plan_2: this.plan_2,
      plan_3: this.plan_3,
      plan_4: this.plan_4,
      plan_5: this.plan_5,
      plan_6: this.plan_6,
      plan_7: this.plan_7,
      status: this.status,
      // statusOther:this.statusOther,
      other:  this.statusOther,
      order:  this.order

    }
    this.ManageQuestionModel.updateQuestionSipas(param, this.bsModalRef);

  }
  gettype() {
    this.arrtype = this.ManageQuestionService.gettype();
  }
  // async getInfo() {
  //   var param = {
  //     fk_dot_ks: this.ManageQuestionModel.question.fk_dot_ks
  //   };
  //   var arrinfo= await this.ManageQuestionModel.getInfo(param);
  //   this.arrCauhoi=arrinfo['arrQuestion'];
  //   this.arrLoaicauhoi=arrinfo['arrLoaicauhoi'];
  //   this.arrNhomcauhoi=arrinfo['arrNhomcauhoi'];
  //   this.arrLoaiphieu=arrinfo['arrLoaiphieu'];
    
  //   // console.log(this.arrCauhoi);

  // }
  getInfo() {
    var param = {
      fk_dot_ks: this.ManageQuestionModel.question.fk_dot_ks,
    };
    this.HttpService.getMethods("managesipas/managequestionsipas/getInfo", param).subscribe(
        result => {
          var arrinfo = result.data;
          this.arrCauhoi=arrinfo['arrQuestion'];
          this.arrLoaicauhoi=arrinfo['arrLoaicauhoi'];
          this.arrNhomcauhoi=arrinfo['arrNhomcauhoi'];
          this.arrLoaiphieu= arrinfo['arrLoaiphieu'];
          this.arrtype = arrinfo['arrtypequestion'];
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  goback() {
    let newrouter = "/system/manage_question_sipas/getListquestion";
    if (this.route.url == newrouter) {
      let newrouter1 = "/system/manage_question_sipas/getListquestion";
      this.route.navigate([newrouter1]);
    }
    else {
      this.route.navigate([newrouter]);
    }

    this.bsModalRef.hide();
  }
  changeLoaicauhoi(e) {
    this.pattern_question_code = e.selectedItem.code;
  }
  changeLoaiphieu(e){
    this.type_vote = e.selectedItem.code;
    this.getOrder();
  }
  getOrder() {
    var param = {
          id: this.id,
          survey_sipas_id: this.survey_sipas.id,
          type_vote: this.type_vote,
        }; 
    this.HttpService.getMethods("managesipas/managequestionsipas/getOrder", param).subscribe(
        result => {
          var order = result.data;
          this.order = order;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  onValueChanged(e) {
    this.check = e.value;
    if (e.value == true) {
      this.status = 1;
    }
    else if(e.value == false) {
      this.status = 2;
    }
  }

  changetype(e){
      this.type_question= e.selectedItem.code;
  }
  changeNhomcauhoi(e) {
    this.dataChangeNhomCauHoi = e.selectedItem.code;
    this.group_question_code = e.selectedItem.code;
    this.getLoaiCauHoi();
  }
  // async getLoaiCauHoi() {
  //   var param = {
  //     dataChangeNhomCauHoi: this.dataChangeNhomCauHoi
  //   }; 
  //   Library.showloading();
  //   let arrLoaicauhoi = await this.ManageQuestionModel.getLoaiCauHoi(param);
  //   this.arrLoaicauhoi = arrLoaicauhoi['arrLoaicauhoi'];
  //   Library.hideloading();
  // }
  getLoaiCauHoi() {
    var param = {
          dataChangeNhomCauHoi: this.dataChangeNhomCauHoi
        }; 
    this.HttpService.getMethods("managesipas/managequestionsipas/getLoaiCauHoi", param).subscribe(
        result => {
          var arrLoaicauhoi = result.data;
          this.arrLoaicauhoi = arrLoaicauhoi['arrLoaicauhoi'];
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  addPlan(){
    this.addPlanColum = this.addPlanColum+1;

    if(this.addPlanColum.length == 2){
      this.planAdd_5 = this.addPlanColum.length
    }else if(this.addPlanColum.length == 3){
      this.planAdd_6 = this.addPlanColum.length
    }else if (this.addPlanColum.length == 4){
      this.planAdd_7 = this.addPlanColum.length
    }
  }
  deletePlan(e){
    if(e == 'planDelete_5'){
      this.planAdd_5 = '';
    }else if(e == 'planDelete_6'){
      this.planAdd_6 = '';
    }else if (e == 'planDelete_7'){
      this.planAdd_7 = '';
    }

  }
  onOtherChanged(e){
    this.check = e.value;
    if (e.value == true) {
      this.statusOther = 1;
    }
    else if(e.value == false) {
      this.statusOther = '';
    }
  }
}

