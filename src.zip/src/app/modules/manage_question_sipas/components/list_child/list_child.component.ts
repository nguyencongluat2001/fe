import { Component, OnInit } from '@angular/core';
import { Survey, ManageQuestionModel,Answer } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddAnswerComponent } from '../add_answer/add_answer.component';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-list-child',
  templateUrl: './list_child.component.html',
  styleUrls: ['./list_child.component.scss']
})
export class ListChildComponent implements OnInit {

  Answer: any;
  bsModalRef: BsModalRef;
  selectedItems: Answer[] = [];
  export_chart: any;
  constructor(
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private modalService: BsModalService,
    private route: Router,
  ) { }

  ngOnInit() {
    this.loadList();
    // console.log(this.ManageSipasModel.Excute);
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      pk_dap_an_ks: this.ManageQuestionModel.answer.pk_dap_an_ks
    };
    Library.showloading();
    this.Answer = await this.ManageQuestionModel.getListAnswerExtend(params);
    Library.hideloading();
  }

  convertFromdate(data) {
    return Library.formatDate(data.date_update_sociology);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  add(){
 
    this.ManageQuestionModel.answer = new Answer;
    this.ManageQuestionModel.answer.thu_tu=1;
    if(this.Answer.length>0){
      this.ManageQuestionModel.answer.thu_tu= this.Answer.length+1;
    }
    
    this.ManageQuestionModel.answer.fk_cau_hoi_ks= this.ManageQuestionModel.question.pk_cau_hoi_ks;
    this.ManageQuestionModel.answer.fk_dap_an_ks= this.ManageQuestionModel.answer.pk_cau_hoi_ks;
    this.modalService.show(AddAnswerComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
    
  }
  edit() {
    
    let i = 0;
    let a;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.pk_dap_an_ks;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để sửa", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để sửa", 'error');
      return;
    } else if (i == 1) {
      this.ManageQuestionModel.answer = this.selectedItems[0];
      this.modalService.show(AddAnswerComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false  });
    }

    

  }

  delete() {
    let Myclass = this;
    let selectedItems = this.selectedItems;
    let ids = '';
    let data = {
      ids: ""
    };
    var result = Library.confirm("Bạn có chắc chắn muốn xóa đối tượng đã chọn?", "Thông báo");
    if (result) {
      result.then(function (dialogResult) {
        if (dialogResult) {
          selectedItems.forEach((item) => {
            ids += item.pk_dap_an_ks + ',';
          });
          data.ids = ids;
          Myclass.ManageQuestionModel.deletesAnswer(data, Myclass);
        }
      });
    }
  }
  goback() {
    let newrouter = "/system/manage_question_sipas/getListAnswer";
    this.route.navigate([newrouter]);
  }
  listAnswerExtend(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ManageQuestionModel.answer = this.selectedItems[0];
      let newrouter='/system/manage_question_sipas/getListAnswerExtend';
      this.route.navigate([newrouter]);
    }
  }
  
}

