import { Component, OnInit, ElementRef } from '@angular/core';
import { Survey, ManageQuestionModel } from '../../models/ManageQuestionModel';
import { ManageQuestionService } from '../../services/manage-question.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { HttpService } from 'src/app/core/http.service';
import { Library } from 'src/app/shared/library/main';

@Component({
  selector: 'app-add_survey',
  templateUrl: './add_survey.component.html',
  styleUrls: ['./add_survey.component.scss']
})
export class AddSurveyComponent implements OnInit {

  survey: Survey;
  id: string = '';
  code: string = '';
  name: string = '';
  year :number ;
  status: string = '';
  order: any;
  check = true;
  arryear: any;
  constructor(
    private HttpService:HttpService,
    public ManageQuestionModel: ManageQuestionModel,
    public ManageQuestionService: ManageQuestionService,
    private route: Router,
    public bsModalRef: BsModalRef,
    private elementRef: ElementRef
  ) {
    this.survey = this.ManageQuestionModel.survey;
    this.order = this.survey.order;
    this.year =new Date().getFullYear();
    if (this.ManageQuestionModel.survey.id != '') {
      this.name = this.ManageQuestionModel.survey.name;
      this.code = this.ManageQuestionModel.survey.code;
      // this.typeVote = this.ManageQuestionModel.survey.type_vote;
      this.year = parseInt(this.ManageQuestionModel.survey.year);
      this.status = this.ManageQuestionModel.survey.status;
      this.check = this.ManageQuestionModel.survey.status;
    }
  

  }

  ngOnInit() {
    this.loadList();
    this.getYear();

    // if(this.survey.fk_evaluation !==''){
    //   this.getExecute();
    // }

  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {


  }
  // async getYear() {
  //   var params = {};
  //   this.arryear = await this.ManageQuestionModel.getYear(params);
  // }
  getYear() {
    var params = {};
    this.HttpService.getMethods("managesipas/managequestionsipas/getyear", params).subscribe(
        result => {
          this.arryear = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  onSubmit(e) {
    if (this.check == true) {
      this.status = '1';

    }
    else {
      this.status = '2';
    }
    // console.log(this.eval_list_id);
    var param = {
      id: this.survey.id,
      code: this.code,
      name: this.name,
      year: this.year,
      status: this.status,
      order: this.order,

    }
    this.ManageQuestionModel.update(param, this.bsModalRef);

  }


  goback() {
    let newrouter = "/system/manage_question_sipas/index";
    if (this.route.url == newrouter) {
      let newrouter1 = "/system/manage_question_sipas";
      this.route.navigate([newrouter1]);
    }
    else {
      this.route.navigate([newrouter]);
    }

    this.bsModalRef.hide();
  }
  changeYear(e) {
    this.year = e.selectedItem.code;
  }
  onValueChanged(e) {
    this.check = e.value;
    if (e.value == true) {
      this.status = '1';

    }
    else {
      this.status = '2';
    }
  }
 
}

