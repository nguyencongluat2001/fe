import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { ListquestionComponent } from './components/list_question/list_question.component';
import { ListAnswerComponent } from './components/list_answer/list_answer.component';
import { ListChildComponent } from './components/list_child/list_child.component';
const routes: Routes = [
  {
    path: ''
    , component: IndexComponent
    , data: {
      title: 'Quản trị câu hỏi sipas'
    }
  },
  { path: 'index', component: IndexComponent },
  {
    path: 'getListquestion', component: ListquestionComponent, data: {
      title: 'Danh sách câu hỏi'
    }
  },
  {
    path: 'getListAnswer', component: ListAnswerComponent, data: {
      title: 'Danh sách đáp án'
    }
  },
  {
    path: 'getListAnswerExtend', component: ListChildComponent, data: {
      title: 'Danh sách đáp án mở rộng'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageQuestionRoutingModule { }
