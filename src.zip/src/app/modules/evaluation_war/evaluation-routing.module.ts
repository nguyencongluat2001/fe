import { NgModule } from '@angular/core';
import { IndexComponent } from './components/index/index.component';
import { TransferComponent } from './components/transfer/transfer.component';
import { PermissionComponent } from './components/permission/permission.component';
import { Routes, RouterModule } from '@angular/router';
import { EvaluationComponent } from './components/evaluation/evaluation.component';
const routes: Routes = [
  {
    path: ''
    , component: IndexComponent
    , data: {
      title: 'Quản trị các tiêu chí đánh giá'
    }
  },
  { path: 'index', component: IndexComponent },
  {
    path: 'transfer', component: TransferComponent, data: {
      title: 'Quản trị các tiêu chí đánh giá'
    }
  },
  {
    path: 'transfers', component: TransferComponent, data: {
      title: 'Quản trị các tiêu chí đánh giá'
    }
  },
  {
    path: 'permission', component: PermissionComponent, data: {
      title: 'Quản trị các tiêu chí đánh giá'
    }
  },
  {
    path: 'define', component: EvaluationComponent, data: {
      title: 'Xem chi tiết'
    }
  },
  {
    path: 'permission/index', component: PermissionComponent, data: {
      title: 'Quản trị các tiêu chí đánh giá'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecordtypeRoutingModule { }
