import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';



export class Evaluation {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    status: number = 0;
    user_id: string = '';
    deadline_ward: any;
}

export class List {
    id: string;
    parrent_id: string;
    name: string;
    max_point: number;
}
export class User {
    id: string;
    text: string;
    expanded?: boolean;
    selected?: boolean;
    items?: User[];
}
export class ListInPer {
    id: string;
    text: string;
    expanded?: boolean;
    selected?: boolean;
    items?: ListInPer[];
}
export class Unit {
    id: string = '';
    name: string = '';
    code: string = '';
}
export class exeUnit {
    evaluation_id: any;
    deadline_ward: any;
}
@Injectable()

export class EvaluationModel {

    _evaluation: Evaluation;
    _exeunit: exeUnit;
    objEvaluation: any;
    _unit: Unit;
    units: Unit[];
    Evaluations: Evaluation[];
    public listData: any;
    constructor(private HttpService:HttpService,private apiservice: ApiService, private route: Router, private datepipe: DatePipe) {

    }

    async getAll(async: boolean = false): Promise<Evaluation[]> {
        let parram = {
            user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
            unit_id: JSON.parse(localStorage.getItem('user_infor'))['unit_id'],
        };
        let response = await this.apiservice.callGet('getall', parram);
        return response.data;
    }

    set Evaluation(value: any) {
        this._evaluation = value;
    }

    get Evaluation() {
        return this._evaluation;
    }
    set exeUnit(value: any) {
        this._exeunit = value;
    }

    get exeUnit() {
        return this._exeunit;
    }

    update(data, activeModal) {
        Library.showloading();
        data['fromdate'] = this.datepipe.transform(data['fromdate'], 'yyy/MM/dd HH:mm:ss');
        data['todate'] = this.datepipe.transform(data['todate'], 'yyy/MM/dd HH:mm:ss');
        this.apiservice.callPost('update', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                activeModal.hide();
                Library.notify(response.message, 'success');
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                let newrouter = "";
                if (this.route.url == "/system/evaluation") {
                    newrouter = "/system/evaluation/index";
                } else {
                    newrouter = "/system/evaluation";
                }
                this.route.navigate([newrouter]);
                // }

            } else {
                Library.notify(response.message, 'error');
            }
        });
    }

    deleteEventtype(data, MyClass) {
        Library.showloading();
        this.apiservice.callPost('deletes', data).subscribe((response: any) => {
            if (response.success) {
                Library.notify(response.message, 'success');
                MyClass.loadList();
            } else {
                Library.notify(response.message, 'error');
            }
            Library.hideloading();
        }, error => {
            Library.hideloading();
            Library.notify(error, 'error');
        });
    }

    // async getAllList(params, async: boolean = false): Promise<List[]> {
    //     let response = await this.apiservice.callGet('getallList', params);
    //     this.listData = response;
    //     return response;
    // }
    getAllList(params) {
        this.HttpService.getMethods("evaluationwar/getallList", params).subscribe(
            result => {
             this.listData = result.data;
            },
            (error) => {
              Library.hideloading();
            }
          );
    }

    updateList(data, activeModal) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/insertList", data).subscribe(
            response => {
        // this.apiservice.callPost('insertList', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                let newrouter = "";
                if (this.route.url == "/system/evaluation/define") {
                    newrouter = "/system/evaluation/defines";
                } else {
                    newrouter = "/system/evaluation/define";
                }
                this.route.navigate([newrouter]);
                // }
                activeModal.hide();
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }

    updateCriteria(data) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/updateCriteria", data).subscribe(
            response => {
        // this.apiservice.callPost('updateCriteria', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }

    insertCriteria(data) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/insertCriteria", data).subscribe(
            response => {
        // this.apiservice.callPost('insertCriteria', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }

    deleteCriteria(data, MyClass) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/deleteCriteria", data).subscribe(
            response => {
        // this.apiservice.callPost('deleteCriteria', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
                let arrIddeleted = data.id.split(',');
                let index;
                arrIddeleted.forEach(element => {
                    index = this.listData.findIndex(data => data.id == element);
                    this.listData.splice(index, 1);
                });
                MyClass.loadList();
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }
    async getAllUnit(params, async: boolean = false): Promise<Unit[]> {
        let response = await this.apiservice.callGet('getallunit', params);
        return response;
    }
    transferUnit(data) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/transfer", data).subscribe(
            response => {
        // this.apiservice.callPost('transfer', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
                let newrouter = "";
                if (this.route.url == "/system/evaluation_war/transfer") {
                    newrouter = "/system/evaluation_war/index";
                } else {
                    newrouter = "/system/evaluation_war/transfer";
                }
                this.route.navigate([newrouter]);
                // Library.notify(response.message, 'success');
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }

    // getdatapermission(params,myClass) {
    //     params['id'] = this._evaluation.id;
    //     params['id'] = this._evaluation.id;
    //     this.apiservice.callPost('getdatapermission', params).subscribe((response: any) => {
    //         myClass.users = response.user;
    //         myClass.list = response.list;
    //         myClass.permission = response.permission;
    //         Library.hideloading();
    //     });
    //     // return this.apiservice.callGet('getdatapermission', params);
    // }

    updatepermission(params, myClass) {
        this.HttpService.postMethods("evaluationwar/updatepermission", params).subscribe(
            response => {
        // this.apiservice.callPost('updatepermission', params).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
                myClass.loaddata()
                myClass.list_evalution_list_id_single = 'xx';
                myClass.list_user_id_single = 'xx';
                myClass.checkedLists = [];
                myClass.checkedUsers = [];
            } else {
                
                Library.notify(response.message, 'error');
            }
        });
    }

    deletePermission(data, MyClass) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/deletepermission", data).subscribe(
            response => {
        // this.apiservice.callPost('deletepermission', data).subscribe((response: any) => {
            if (response.success) {
                Library.notify(response.message, 'success');
                MyClass.list_evalution_list_id_single = 'xx'
                MyClass.list_user_id_single = 'xx'
                MyClass.loaddata();
            } else {
                Library.notify(response.message, 'error');
            }
            Library.hideloading();
        }, error => {
            Library.hideloading();
            Library.notify(error, 'error');
        });
    }
    copyCriteria(data) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/copyCriteria", data).subscribe(
            response => {
        // this.apiservice.callPost('copyCriteria', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
                Library.notify(response.message, 'success');
                let newrouter = "";
                if (this.route.url == "/system/evaluation/define") {
                    newrouter = "/system/evaluation/defines";
                } else {
                    newrouter = "/system/evaluation/define";
                }
                this.route.navigate([newrouter]);
            }
            else {
                Library.hideloading();
                Library.notify(response.message, 'error');
            }
        });
    }
    // async getGroupEval(params, async: boolean = false): Promise<Evaluation[]> {
    //     let response = await this.apiservice.callGet('getGroupEvaluation', params);
    //     return response;
    // }
    // getGroupEval(params) {
    //     let parram = {};
    //     this.HttpService.getMethods("evaluationwar/getGroupEvaluation", params).subscribe(
    //         result => {
    //           this.Evaluations = result.data;
    //         },
    //         (error) => {
    //           Library.hideloading();
    //         }
    //       );
    //   }
    async getduplicateUnit(params, async: boolean = false): Promise<Unit[]> {
        let response = await this.apiservice.callGet('duplicateUnit', params);
        return response;
    }
    async getevaluationexe(async: boolean = false): Promise<exeUnit[]> {
        let parram = {};
        let response = await this.apiservice.callGet('evaluationexe', parram);
        return response;
    }
    async getGroup(async: boolean = false) {
        let parram = {};
        let response = await this.apiservice.callGet('getGroup', parram);
        return response;
    }
    updateDeadline(data) {
        Library.showloading();
        this.HttpService.postMethods("evaluationwar/updateDeadline", data).subscribe(
            response => {
        // this.apiservice.callPost('updateDeadline', data).subscribe((response: any) => {
            if (response.success) {
                Library.hideloading();
                Library.notify(response.message, 'success');
                let newrouter = "";
                newrouter = "/system/evaluation_war/index";
                this.route.navigate([newrouter]);
            }
            else {
                Library.notify(response.message, 'error');
                Library.hideloading();
            }
        });
    }
}
