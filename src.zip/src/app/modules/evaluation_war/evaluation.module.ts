import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { EvaluationModel } from './models/EvaluationModel';
import { ApiService } from './services/api.service';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ListModel } from '../list/models/list.model';
import { ListApi } from '../list/services/list-api.service';
import { RecordtypeRoutingModule } from './evaluation-routing.module';
import { IndexComponent } from './components/index/index.component';
import { DxTooltipModule, DxTemplateModule,DxDateBoxModule, DxValidatorModule,DxValidationSummaryModule} from 'devextreme-angular';
import { DxTreeViewModule, DxListModule } from 'devextreme-angular';
import { DxTreeListModule, DxCheckBoxModule,DxSelectBoxModule } from 'devextreme-angular';
import { EvaluationService } from './services/evaluation.service';
import { TransferComponent } from './components/transfer/transfer.component';
import { PermissionComponent } from './components/permission/permission.component';
import { UserTemplateComponent } from './components/user-template/user-template.component';
import { EvaluationComponent } from './components/evaluation/evaluation.component';
import { AdjournComponent } from './components/adjourn/adjourn.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    RecordtypeRoutingModule,
    ModalModule.forRoot(),
    FormsModule,
    DxTooltipModule,
    DxTemplateModule,DxDateBoxModule, DxTreeViewModule, DxValidatorModule,DxValidationSummaryModule,DxListModule, DxTreeListModule, DxCheckBoxModule,DxSelectBoxModule
  ],
  providers: [ApiService, EvaluationModel, ListModel, ListApi, EvaluationService, DatePipe],
  declarations: [IndexComponent, TransferComponent, PermissionComponent, UserTemplateComponent,EvaluationComponent,AdjournComponent]
})
export class EvaluationModule { }
