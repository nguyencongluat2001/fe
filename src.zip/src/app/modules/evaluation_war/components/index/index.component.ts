import { Component, OnInit } from '@angular/core';
import { EvaluationModel, Evaluation, exeUnit } from '../../models/EvaluationModel';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { ListModel } from '../../../list/models/list.model';
import { AdjournComponent } from '../adjourn/adjourn.component';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Evaluations: Evaluation[];
  bsModalRef: BsModalRef;
  selectedItems: Evaluation[] = [];
  selectedItem: Evaluation[] = [];
  txt_search = '';
  listsGroup: any;
  years: any;
  defaultVisible: false;
  users: any;
  exeunit: exeUnit[];
  c: any;
  constructor(
    private HttpService:HttpService,
    public EvaluationModel: EvaluationModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    private ListModel: ListModel,
    public apiService: ApiService,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      txtSearch: this.txt_search
    };
    Library.showloading();
    this.getAll();
    // this.Evaluations = await this.EvaluationModel.getAll();
    Library.hideloading();
    Library.showloading();
    // this.exeunit = await this.EvaluationModel.getevaluationexe();
    this.getevaluationexe();
    Library.hideloading();

    // this.users = await this.EvaluationModel.getAllUnit();
  }
  getAll() {
    // let parram = {};
    let parram = {
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      unit_id: JSON.parse(localStorage.getItem('user_infor'))['unit_id'],
  };
    this.HttpService.getMethods("evaluationwar/getall", parram).subscribe(
        result => {
          this.Evaluations = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  getevaluationexe() {
    let parram = {};
    this.HttpService.getMethods("evaluationwar/evaluationexe", parram).subscribe(
        result => {
          this.exeunit = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  setStatus(data) {
    if (data.status == 'MOI_TAO') {
      return 'Mới tạo';
    } else if (data.status == 'DA_CHUYEN') {
      return 'Đã gửi đơn vị';
    } else if (data.status == 'DANG_CHAM') {
      return 'Đang chấm điểm';
    } else {
      return 'Kết thúc';
    }
  }

  setGroup(data) {
    if (data.group == 'SO_NGANH') {
      data.group = 'SO_NGANH';
      return 'Sở,nghành';
    } else if (data.group == 'QUAN_HUYEN') {
      data.group = 'QUAN_HUYEN';
      return 'Quận huyện';
    } else if (data.group == 'PHUONG_XA') {
      data.group = 'PHUONG_XA';
      return 'Phường xã';
    }
    return true;
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
    this.selectedItem = e.selectedRowsData;
   var b=this.selectedItems.map(select=>select.id);
   this.exeunit.forEach(item => {
      this.selectedItem.forEach(element => {
        if(element.id==item.evaluation_id){
          this.selectedItem=[];
        }
      });
  });
    this.EvaluationModel.Evaluation = this.selectedItems;
  }
  /**
   * ---------------------- Các sự kiện thêm, sửa, xóa ----------------------------
   */


  transfer() {
    let i = 0;
    let iditem;
    var todate = new Date(this.selectedItems[0].todate);
    var todates = todate.toLocaleDateString("en-US");
    var date = new Date();
    var datetoday = date.toLocaleDateString("en-US");
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để chuyển", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để chuyển", 'error');
      return;
    } 
    if (Date.parse(datetoday) > Date.parse(todates)) {
      Library.notify("Đợt đánh giá đã hết hạn", 'error');
      return;
    } 
    else if (i == 1) {
      this.EvaluationModel.Evaluation = this.selectedItems[0];
      let newrouter = "/system/evaluation_war/transfer";
      this.route.navigate([newrouter]);
    }
  }
  permission() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đợt đánh giá để phân quyền", 'error');
      return;
    } else {
      this.EvaluationModel.Evaluation = this.selectedItems[0];
      let newrouter = "/system/evaluation_war/permission";
      this.route.navigate([newrouter]);
    }
  }
  seedetail() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.EvaluationModel.Evaluation = this.selectedItems[0];
      let newrouter = "/system/evaluation_war/define";
      this.route.navigate([newrouter]);
    }
  }
  adjourn(){
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để gia hạn", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để gia hạn", 'error');
      return;
    } else if (i == 1) {
      this.EvaluationModel.Evaluation = this.selectedItems[0];
      this.exeunit.forEach(item => {
          if( this.selectedItems[0].id==item.evaluation_id){
            this.EvaluationModel.Evaluation.deadline_ward=item.deadline_ward;
          }
    });
      this.modalService.show(AdjournComponent, { backdrop: 'static', keyboard: false });
    }
  }
}
