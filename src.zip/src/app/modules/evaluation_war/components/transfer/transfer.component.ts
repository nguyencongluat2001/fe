import { Component, OnInit } from '@angular/core';
import { EvaluationModel, Unit, exeUnit } from '../../models/EvaluationModel';
import { ApiService } from '../../services/api.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
// import { ConsoleReporter } from 'jasmine';
@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.scss']
})
export class TransferComponent implements OnInit {
  Units: Unit[];
  exeUnit: exeUnit;
  txt_search = '';
  selectedItems: Unit[] = [];
  itemevaluation: any;
  duplicateUnit: any;
  selectedrows: any;
  deadline_ward: Date;
  maxdate: Date;
  mindate:Date;
  constructor(
    public EvaluationModel: EvaluationModel,
    private modalService: BsModalService,
    public apiService: ApiService,
    private route: Router,
    private router: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.getallunit();
    this.itemevaluation = this.EvaluationModel.Evaluation.id;
    this.exeUnit = this.EvaluationModel.exeUnit;
    this.deadline_ward = this.EvaluationModel.Evaluation.todate;
    this.maxdate = this.EvaluationModel.Evaluation.todate;
    this.mindate = this.EvaluationModel.Evaluation.fromdate;
  }

  async getallunit() {
    let params = {
      txtSearch: this.txt_search
    };
    var evalution = '';
    var group = 'QUAN_HUYEN';
    if (this.EvaluationModel.Evaluation) {
      group = this.EvaluationModel.Evaluation.group;
      evalution = this.EvaluationModel.Evaluation.id;
    }
    let param = {
      unit: group,
      evalution_id: evalution,
      parrent_id: JSON.parse(localStorage.getItem('unit_infor'))['id']
    };
    Library.showloading();
    this.duplicateUnit = await this.EvaluationModel.getduplicateUnit(param);
    this.Units = await this.EvaluationModel.getAllUnit(param);
    this.selectedrows = this.duplicateUnit.map(unit => unit.code);
    if(this.duplicateUnit.length>0){
      this.deadline_ward=this.duplicateUnit[0].deadline_ward;
    }
    Library.hideloading();
  }
  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
    // var disabledKeys = e.currentSelectedRowKeys.filter(this.selectedrows > -1);
    // if (this.selectedrows.length > 0){
    //   e.component.deselectRows(this.selectedrows);
    // }
  }
  async transfer() {
    var a = new Date(this.deadline_ward);
    var date = a.toLocaleDateString("en-US");
    if (this.deadline_ward == undefined) {
      date = '';
    }
    else {
      date = date;
    }
    let Myclass = this;
    let selectedItems = this.selectedItems;
    let codeunit = '';
    let data = {
      code: "",
      id_evaluation: "",
      user_perform: JSON.parse(localStorage.getItem('user_infor'))['id'],
      owner_code: JSON.parse(localStorage.getItem('user_infor'))['owner_code'],
      deadline_ward: date
    };
    selectedItems.forEach((item) => {
      codeunit += item.code + ',';
    });
    data.code = codeunit;
    data.id_evaluation = this.itemevaluation;
    Myclass.EvaluationModel.transferUnit(data);

  }
  goBack() {
    let newrouter = "/system/evaluation_war";
    this.route.navigate([newrouter]);
  }
}
