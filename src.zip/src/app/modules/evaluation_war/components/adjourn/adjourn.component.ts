import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { EvaluationModel } from '../../models/EvaluationModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-adjourn',
  templateUrl: './adjourn.component.html',
  styleUrls: ['./adjourn.component.scss']
})
export class AdjournComponent implements OnInit {

  @Input() data: any;
  deadline_ward: Date;
  maxdate: Date;
  baseUrl: string;
  headers: any;
  mindate:Date;
  constructor(
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private EvaluationModel: EvaluationModel,
    private route: Router,
  ) {
    this.deadline_ward = this.EvaluationModel.Evaluation.todate;
    this.mindate = this.EvaluationModel.Evaluation.fromdate;
  }

  ngOnInit() {
  }
  onupload() {
    var a = new Date(this.deadline_ward);
    var date = a.toLocaleDateString("en-US");
    if (this.deadline_ward == undefined) {
      date = '';
    }
    else {
      date = date;
    }
    let param = {
      evalution_id: this.EvaluationModel.Evaluation.id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      deadline_ward:date
    };
    this.EvaluationModel.updateDeadline(param);
    this.bsModalRef.hide();
    this.goBack();
  }
  goBack() {
    this.bsModalRef.hide();
    let newrouter = "/system/evaluation_war";
    this.route.navigate([newrouter]);
   
  }
}
