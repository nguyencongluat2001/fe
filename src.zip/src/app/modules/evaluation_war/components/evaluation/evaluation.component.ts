import { Component, OnInit } from '@angular/core';
import { List, EvaluationService } from '../../services/evaluation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { EvaluationModel, Evaluation } from '../../models/EvaluationModel';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-evaluation',
  templateUrl: './evaluation.component.html',
  styleUrls: ['./evaluation.component.scss']
})
export class EvaluationComponent implements OnInit {

  listData: any;
  selectedItems: any;
  statusesData = [];
  name: string = "";
  idevaluation: any;
  tongsingle: number = 0;
  nameevaluation: any;
  Evaluations: Evaluation[];
  prefix: string = '';
  onchangetree: any[] = [0];

  constructor(
    private HttpService:HttpService,
    public EvaluationModel: EvaluationModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute
    , public service: EvaluationService) {
  }

  ngOnInit() {
    if (this.EvaluationModel.Evaluation) {
      this.name = this.EvaluationModel.Evaluation.name;
    }
    this.statusesData = this.service.getStatus();
    this.loadList();
  }

  async loadList() {
    let id = this.EvaluationModel.Evaluation.id;
    let params = {
      evaluation_id: id

    };
    this.tongsingle = 0;
    Library.showloading();
    await this.EvaluationModel.getAllList(params);
    this.listData = this.EvaluationModel.listData;

    this.listData.forEach(element => {
      if (element['parrent_id'] == 0) {
        this.tongsingle += element['max_point'];
      }
    });
    Library.hideloading();
    this.getGroupEval(params);
  }
  getGroupEval(params) {
    this.HttpService.getMethods("evaluationwar/getGroupEvaluation", params).subscribe(
        result => {
          this.Evaluations = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  initNewRow(e) {
    e.data.Task_Status = "Not Started";
    e.data.Task_Start_Date = new Date();
    e.data.Task_Due_Date = new Date();
  }

  goBack() {
    let newrouter = "/system/evaluation_war";
    this.route.navigate([newrouter]);
  }

  
  
 
  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
  }


  

  onRowPrepared(e) {
    if (e.rowType == "data") {
      if (e.rowIndex % 2 == 0) {
        $(e.rowElement).addClass("dx-column-lines-color");
      }
    }
  }
  filterSelected(e) {
    // this.prefix = e.value;
    // this.idevaluation = this.Evaluations.filter(evaluation => evaluation.name === this.prefix).map(evalua => evalua.id);
    // console.log(e);
    this.idevaluation = e.selectedItem.id;
  }
 
  openlist() {
    this.onchangetree = this.EvaluationModel.listData.map(listdata => listdata.id);
  }
  closelist() {
    this.onchangetree = [0];
  }
}
