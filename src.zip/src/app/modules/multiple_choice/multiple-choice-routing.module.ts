import { NgModule } from '@angular/core';
import { IndexComponent } from './components/index/index.component';
import { EvaluationComponent } from './components/evaluation/evaluation.component';
import { StandardComponent } from './components/standard/standard.component';
import { InputdataComponent } from './components/inputdata/inputdata.component';
import { GuideComponent } from './components/guide/guide.component';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: ''
    , component: IndexComponent
    , data: {
      title: 'Quản trị các tiêu chí đánh giá'
    }
  },
  { path: 'index', component: IndexComponent },
  {
    path: 'list_evaluation', component: EvaluationComponent, data: {
      title: 'Danh sách tiêu chí'
    }
  },
  {
    path: 'list_standard', component: StandardComponent, data: {
      title: 'Danh sách tiêu chuẩn '
    }
  },
  {
    path: 'list_standards', component: StandardComponent, data: {
      title: 'Danh sách tiêu chuẩn '
    }
  },
  {
    path: 'inputdata', component: InputdataComponent, data: {
      title: 'Danh sách dữ liệu đầu vào '
    }
  },
  {
    path: 'inputdatas', component: InputdataComponent, data: {
      title: 'Danh sách dữ liệu đầu vào '
    }
  },
  {
    path: 'guide', component: GuideComponent, data: {
      title: 'Danh sách hướng dẫn '
    }
  },
  {
    path: 'guides', component: GuideComponent, data: {
      title: 'Danh sách hướng dẫn  '
    }
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecordtypeRoutingModule { }
