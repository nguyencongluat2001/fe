import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { MultipleChoiceModel } from './models/MultipleChoiceModel';
import { ApiService } from './services/api.service';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { RecordtypeRoutingModule } from './multiple-choice-routing.module';
import { IndexComponent } from './components/index/index.component';
import { AddComponent } from './components/add/add.component';
import { DxTooltipModule, DxTemplateModule } from 'devextreme-angular';
import { DxTreeViewModule, DxListModule } from 'devextreme-angular';
import { DxTreeListModule, DxCheckBoxModule,DxSelectBoxModule,DxDateBoxModule } from 'devextreme-angular';
import { EvaluationComponent } from './components/evaluation/evaluation.component';
import { StandardComponent } from './components/standard/standard.component';
import { InputdataComponent } from './components/inputdata/inputdata.component';
import { AddInputComponent } from './components/add-input/add-input.component';
import { AddGuideComponent } from './components/add-guide/add-guide.component';
import { GuideComponent } from './components/guide/guide.component';
import { CKEditorModule } from 'ng2-ckeditor';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    RecordtypeRoutingModule,
    HttpClientModule,
    // HttpModule,
    ModalModule.forRoot(),
    FormsModule,
    DxTooltipModule,
    DxDateBoxModule,
    DxTemplateModule, DxTreeViewModule, DxListModule, DxTreeListModule, DxCheckBoxModule,DxSelectBoxModule,CKEditorModule
  ],
  // entryComponents: [
  //   AddComponent,
  //   AddInputComponent,
  //   AddGuideComponent
  
  // ],
  providers: [ApiService, MultipleChoiceModel, ApiService, DatePipe],
  declarations: [IndexComponent, AddComponent,EvaluationComponent,StandardComponent,
    InputdataComponent,AddInputComponent,GuideComponent,AddGuideComponent]
})
export class MultipleChoiseModule { }
