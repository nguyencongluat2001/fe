import { Component, OnInit } from '@angular/core';
import { MultipleChoiceModel, Multiplechoice, Evaluationlist } from '../../models/MultipleChoiceModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { HttpService } from 'src/app/core/http.service';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {

  MultipleChoice: Multiplechoice;
  Evaluationlist: Evaluationlist;
  selectUnit: any;
  ids = '';
  fromdate: any;
  todate: any;
  numberPattern: any = /^[0-9]+$/;
  user_id: any;
  check_full_point = false;
  arrCondition:any;
  constructor(private HttpService:HttpService,private MultipleChoiceModel: MultipleChoiceModel,
    public bsModalRef: BsModalRef,
    // private ListModel: ListModel,
    private route: Router) {
    this.MultipleChoice = MultipleChoiceModel.MultipleChoice;
    //  this.check_full_point=this.MultipleChoice.check_full_point;
    if (this.MultipleChoice.check_full_point == '1') {
      this.check_full_point = true;
    }
  }

  ngOnInit() {
    this.getDanhmuc();
  }

  onSubmit(e) {
    this.MultipleChoiceModel.update(this.MultipleChoice, this.bsModalRef);
  }

  getDanhmuc() {
    let param = {code:'DM_DIEU_KIEN'};
    this.HttpService.getMethods("multiplechoice/getDanhmuc", param).subscribe(
        result => {
             this.arrCondition = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  goback() {

    let newrouter = this.route.url;
    this.route.navigate([newrouter]);
    this.bsModalRef.hide();
  }
}
