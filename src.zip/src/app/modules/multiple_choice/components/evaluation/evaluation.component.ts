import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Evaluation, MultipleChoiceModel } from '../../models/MultipleChoiceModel';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
// import { AddListComponent } from '../add-list/add-list.component';

@Component({
  selector: 'app-evaluation',
  templateUrl: './evaluation.component.html',
  styleUrls: ['./evaluation.component.scss']
})
export class EvaluationComponent implements OnInit {

  listData: any;
  selectedItems: any;
  statusesData = [];
  name: string = "";
  idevaluation: any;
  tongsingle: number = 0;
  nameevaluation: any;
  Evaluations: Evaluation[];
  prefix: string = '';
  onchangetree: any[] = [0];
  numberselect: number;
  constructor(
    private HttpService:HttpService,
    public MultipleChoiceModel: MultipleChoiceModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute
    , public service: ApiService) {
  }

  ngOnInit() {
    if (this.MultipleChoiceModel.Evaluation) {
      this.name = this.MultipleChoiceModel.Evaluation.name;
    }
    // this.statusesData = this.service.getStatus();
    this.loadList();
  }

  async loadList() {
    let id = this.MultipleChoiceModel.Evaluation.id;
    let params = {
      evaluation_id: id

    };
    Library.showloading();
    // this.listData = await this.MultipleChoiceModel.getAllList(params);
    this.getAllList(params);
    Library.hideloading();
  }
  getAllList(params) {
    this.HttpService.getMethods("multiplechoice/getallList", params).subscribe(
        result => {
          this.listData = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  goBack() {
    let newrouter = "/system/multiple_choice";
    this.route.navigate([newrouter]);
  }
  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
    this.numberselect = this.selectedItems.length;
  }
  listStandard() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.MultipleChoiceModel.Evaluationlist = this.selectedItems[0];
      let newrouter = "/system/multiple_choice/list_standard";
      this.route.navigate([newrouter]);
    }
  }
  inputdata() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.MultipleChoiceModel.Evaluationlist = this.selectedItems[0];
      let newrouter = "/system/multiple_choice/inputdata";
      this.route.navigate([newrouter]);
    }
  }
  listGuide(){
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.MultipleChoiceModel.Evaluationlist = this.selectedItems[0];
      let newrouter = "/system/multiple_choice/guide";
      this.route.navigate([newrouter]);
    }
  }
  setEnquire(data) {
    if (data.enquire == 'MULTICHOICE') {
      return 'Trắc nghiệm';
    } else if (data.enquire == 'MULTICHOICESCALE') {
      return 'Trắc nghiệm tỉ lệ';
    }
    return true;
  }
}
