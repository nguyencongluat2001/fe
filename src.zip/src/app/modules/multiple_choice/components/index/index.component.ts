import { Component, OnInit, enableProdMode, NgModule } from '@angular/core';
import { MultipleChoiceModel, Evaluation } from '../../models/MultipleChoiceModel';
// import { AddComponent } from '../../components/add/add.component';
import { RouterLink } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ApiService } from '../../services/api.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
// import { EvaluationComponent } from '../evaluation/evaluation.component';


@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Evaluations: Evaluation[];
  bsModalRef: BsModalRef;
  selectedItems: Evaluation[] = [];
  selectedItem: Evaluation[] = [];
  txt_search = '';
  listsGroup: any;
  years: any;
  defaultVisible: false;
  users: any;
  c: any;
  constructor(
    private HttpService:HttpService,
    public MultipleChoiceModel: MultipleChoiceModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    // private ListModel: ListModel,
    public apiService: ApiService,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      txtSearch: this.txt_search
    };
    Library.showloading();
    this.getAll();
    Library.hideloading();
    

    // this.users = await this.MultipleChoiceModel.getAllUnit();
  }
  getAll() {
    let parram = {};
    this.HttpService.getMethods("multiplechoice/getall", parram).subscribe(
        result => {
          this.Evaluations = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  setStatus(data) {
    if (data.status == 'MOI_TAO') {
      return 'Mới tạo';
    } else if (data.status == 'DA_CHUYEN') {
      return 'Đã gửi đơn vị';
    } else if (data.status == 'DANG_CHAM') {
      return 'Đang chấm điểm';
    } else {
      return 'Kết thúc';
    }
  }

  setGroup(data) {
    if (data.group == 'SO_NGANH') {
      data.group = 'SO_NGANH';
      return 'Sở,nghành';
    } else if (data.group == 'QUAN_HUYEN') {
      data.group = 'QUAN_HUYEN';
      return 'Quận huyện';
    } else if (data.group == 'PHUONG_XA') {
      data.group = 'PHUONG_XA';
      return 'Phường xã';
    }
    return true;
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
    this.MultipleChoiceModel.Evaluation = this.selectedItems;
  }
  

  
  evaluation() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.MultipleChoiceModel.Evaluation = this.selectedItems[0];
      let newrouter = "/system/multiple_choice/list_evaluation";
      this.route.navigate([newrouter]);
    }
  }
  
}
