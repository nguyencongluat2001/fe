import { Component, OnInit } from '@angular/core';
import { MultipleChoiceModel,Guide,Evaluationlist } from '../../models/MultipleChoiceModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
@Component({
  selector: 'app-add-guide',
  templateUrl: './add-guide.component.html',
  styleUrls: ['./add-guide.component.scss']
})
export class AddGuideComponent implements OnInit {

  Guide: Guide;
  Evaluationlist:Evaluationlist;
  selectUnit: any;
  ids = '';
  fromdate :any;
  todate: any;
  numberPattern: any = /^[0-9]+$/;
  user_id:any;
  listdanhmuc:any;
  stt:number;
  myCkeditorConfig:any;
  name:string='';
  recipe:string='';
  id='';
  evaluation_list_id:string='';
  loai_trac_nghiem:string;
  constructor(private HttpService:HttpService,private MultipleChoiceModel: MultipleChoiceModel,
    public bsModalRef: BsModalRef,
    // private ListModel: ListModel,
    private route: Router) {  
      this.Guide = MultipleChoiceModel.Guide;
      if(this.Guide.name){
        this.name=this.Guide.name;
      }
      if(this.Guide.recipe){
        this.recipe=this.Guide.recipe;
      }
      if(this.Guide.id){
        this.id=this.Guide.id;
      }
      if(this.Guide.evaluation_list_id){
        this.evaluation_list_id=this.Guide.evaluation_list_id;
      }
      if(this.Guide.loai_trac_nghiem){
        this.loai_trac_nghiem=this.Guide.loai_trac_nghiem;
      }
    }

  ngOnInit() {
    this.getDanhmuc();
  }

  onSubmit(e){
    this.MultipleChoiceModel.updateGuide(this.Guide,this.bsModalRef);
  }

  getDanhmuc() {
    let param = {code:'DM_LOAI_TRAC_NGHIEM'};
    this.HttpService.getMethods("multiplechoice/getDanhmuc", param).subscribe(
        result => {
             this.listdanhmuc = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  goback() {
    
    let newrouter =this.route.url;
    this.route.navigate([newrouter]);
    this.bsModalRef.hide();
  }
  onupload(){
    if(this.name.trim()==''){
      Library.notify('Nội dung không được để trống', 'error');
      return;
    }
    var param={
      id:this.id,
      evaluation_list_id:this.evaluation_list_id,
      name:this.name,
      recipe:this.recipe,
      loai_trac_nghiem:this.loai_trac_nghiem
    }
    this.MultipleChoiceModel.updateGuide(param,this.bsModalRef);
  }
  onSelectionChanged(e){
    this.loai_trac_nghiem=e.selectedItem.code;
  }
}
