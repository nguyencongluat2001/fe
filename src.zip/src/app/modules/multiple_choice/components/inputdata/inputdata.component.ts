import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Evaluation, MultipleChoiceModel, Multiplechoice } from '../../models/MultipleChoiceModel';
import { AddInputComponent } from '../add-input/add-input.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-inputdata',
  templateUrl: './inputdata.component.html',
  styleUrls: ['./inputdata.component.scss']
})
export class InputdataComponent implements OnInit {

  listData: any;
  selectedItems: any;
  statusesData = [];
  name: string = "";
  idevaluation: any;
  tongsingle: number = 0;
  nameevaluation: any;
  Evaluations: Evaluation[];
  prefix: string = '';
  onchangetree: any[] = [0];
  numberselect: number;
  constructor(
    private HttpService:HttpService,
    public MultipleChoiceModel: MultipleChoiceModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute
    , public service: ApiService) {
  }

  ngOnInit() {
    if (this.MultipleChoiceModel.Evaluationlist) {
      this.name = this.MultipleChoiceModel.Evaluationlist.name;
    }
    // this.statusesData = this.service.getStatus();
    this.loadList();
  }

  async loadList() {
    let id = this.MultipleChoiceModel.Evaluationlist.id;
    let params = {
      evaluation_list_id: id,
      c_type:'TINH_TOAN'

    };
    Library.showloading();
    this.getStandard(params);
    Library.hideloading();
  }
  getStandard(params) {
    this.HttpService.getMethods("multiplechoice/getStandard", params).subscribe(
        result => {
          this.listData = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  goBack() {
    let newrouter = "/system/multiple_choice/list_evaluation";
    this.route.navigate([newrouter]);
  }
  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
    this.numberselect = this.selectedItems.length;
  }
  edit() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.MultipleChoiceModel.MultipleChoice = this.selectedItems[0];
      this.modalService.show(AddInputComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
    }
  }
  add() {
    this.MultipleChoiceModel.MultipleChoice = new Multiplechoice;
    var stt =this.listData.length+1; 
    this.MultipleChoiceModel.MultipleChoice.c_order= stt;
    this.MultipleChoiceModel.MultipleChoice.c_type = 'TINH_TOAN';
    this.MultipleChoiceModel.MultipleChoice.evaluation_list_id = this.MultipleChoiceModel.Evaluationlist.id;
    this.modalService.show(AddInputComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
  }
  delete() {
    let Myclass = this;
    let selectedItems = this.selectedItems;
    let ids = '';
    let data = {
      ids: ""
    };
    var result = Library.confirm("Bạn có chắc chắn muốn xóa đối tượng đã chọn?", "Thông báo");
    if (result) {
      result.then(function (dialogResult) {
        if (dialogResult) {
          selectedItems.forEach((item) => {
            ids += item.id + ',';
          });
          data.ids = ids;
          Myclass.MultipleChoiceModel.delete(data, Myclass);
        }
      });
    }
  }

}
