import { Component, OnInit } from '@angular/core';
import { MultipleChoiceModel,Multiplechoice,Evaluationlist } from '../../models/MultipleChoiceModel';
// import { ListModel } from '../../../list/models/list.model';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { HttpService } from 'src/app/core/http.service';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-add-input',
  templateUrl: './add-input.component.html',
  styleUrls: ['./add-input.component.scss']
})
export class AddInputComponent implements OnInit {

  MultipleChoice: Multiplechoice;
  Evaluationlist:Evaluationlist;
  selectUnit: any;
  ids = '';
  fromdate :any;
  todate: any;
  numberPattern: any = /^[0-9]+$/;
  user_id:any;
  listSohang:any;
  stt:number;

  constructor(private HttpService:HttpService,private MultipleChoiceModel: MultipleChoiceModel,
    public bsModalRef: BsModalRef,
    // private ListModel: ListModel,
    private route: Router) {  
      this.MultipleChoice = MultipleChoiceModel.MultipleChoice;

    }

  ngOnInit() {
    this.getDanhmuc();
  }

  onSubmit(e){
    this.MultipleChoiceModel.update_inputdata(this.MultipleChoice,this.bsModalRef);
  }
  getDanhmuc() {
    let param = {code:'DM_SO_HANG'};
    this.HttpService.getMethods("multiplechoice/getDanhmuc", param).subscribe(
        result => {
             this.listSohang = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }
  
  goback() {
    
    let newrouter =this.route.url;
    this.route.navigate([newrouter]);
    this.bsModalRef.hide();
  }
}
