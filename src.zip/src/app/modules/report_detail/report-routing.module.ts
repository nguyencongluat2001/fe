import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { FieldComponent } from './components/field/field.component';
import { ResultComponent } from './components/result/result.component';
import { ChartComponent } from './components/chart/chart.component';
const routes: Routes = [
  {
    path: ''
    , component: IndexComponent
    , data: {
      title: 'Báo cáo'
    }
  },
  {
    path: 'field', component: FieldComponent, data: {
      title: 'Danh sách các lĩnh vực'
    }
  },
  {
    path: 'result', component: ResultComponent, data: {
      title: 'Xem kết quả CCHC'
    }
  },
  {
    path: 'chart', component: ChartComponent, data: {
      title: 'Xem biểu đồ'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
