import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { ExcuteGroup, ReportModel } from '../../models/ReportModel';
import { ReportService } from '../../services/report.service';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Excutes: ExcuteGroup[];
  bsModalRef: BsModalRef;
  selectedItems: ExcuteGroup[] = [];
  exporttotal:any;
  constructor(
    private HttpService:HttpService,
    public ExcuteModel: ReportModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    public ReportService: ReportService,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      role:JSON.parse(localStorage.getItem('user_infor'))['role']
    };
    Library.showloading();
    // this.Excutes = await this.ExcuteModel.getAll(params);
    this.getAll(params);
    Library.hideloading();
  }
  getAll(parram) {
    this.HttpService.getMethods("report/detail/getall", parram).subscribe(
        result => {
            this.Excutes = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  seeresult() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ExcuteModel.Excute = this.selectedItems[0];
      let newrouter = "/system/reportdetail/field";
      this.route.navigate([newrouter]);
    }

  }
  setGroup(data) {
    if (data.group == 'SO_NGANH') {
      data.group = 'SO_NGANH';
      return 'Sở nghành';
    } else if (data.group == 'QUAN_HUYEN') {
      data.group = 'QUAN_HUYEN';
      return 'Quận huyện';
    } else if (data.group == 'PHUONG_XA') {
      data.group = 'PHUONG_XA';
      return 'Phường xã';
    }
    return true;
  }
  async export(){
    let Myclass = this;
    let selectedItems = this.selectedItems.map(execute=>execute.id);
    let name= this.selectedItems.map(execute=>execute.name);
    let group= this.selectedItems.map(execute=>execute.group);
  
    let data = {
      execute_group_id: selectedItems,
      names:name,
      groups:group,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    };
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để export", 'error');
      return;
    } else {
      this.exporttotal = await this.ExcuteModel.exporttotal(data);
      window.open(this.exporttotal);
    }
  }
}

