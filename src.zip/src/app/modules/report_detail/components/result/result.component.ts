import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Excute, ReportModel } from '../../models/ReportModel';
import { ReportService } from '../../services/report.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {

  Excutes: Excute[];
  export:any;
  maxpoint: any;
  bsModalRef: BsModalRef;
  nameunit: any;
  selectedItems: Excute[] = [];
  namecolumn3;
  namecolumn4;
  title;
  constructor(
    public ReportModel: ReportModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    public ReportService: ReportService,
  ) {

  }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    var execute_group_id = this.ReportModel.ExcuteList.execute_group_id;
    var name_unit = this.ReportModel.ExcuteList.group;
    if (name_unit == 'QUAN_HUYEN') {
      this.nameunit = 'Các huyện, thành phố, thị xã';
    }
    else {
      this.nameunit = 'Các sở, ban, ngành';
    }
    var field_id = this.ReportModel.ExcuteList.id;
    var nameList = this.ReportModel.ExcuteList.name;
    var name=(nameList.split("."));
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      field_id: field_id,
      nameLists:nameList,
      group:this.ReportModel.ExcuteList.group
    };
    Library.showloading();
    this.Excutes = await this.ReportModel.result(params);
    Library.hideloading();
    var arrmax_point = this.Excutes.map(maxpoint => maxpoint.max_point);
    var max_point;
    arrmax_point.forEach(element => {
      max_point = element;
    });
    this.maxpoint = max_point;
     this.namecolumn3= 'Điểm ' + (name[1].toLowerCase()) + ' (tối đa ' +  this.maxpoint + ' điểm)';
     this.namecolumn4='Chỉ số thành phần ' + (name[1].toLowerCase()) + '(%)';
     this.title='Kết quả điểm số và Chỉ số thành phần ' + (name[1].toLowerCase());


  }
  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;

  }
  goBack() {
    let newrouter = "/system/reportdetail/field";
    this.route.navigate([newrouter]);
  }
  async report() {
      var execute_group_id = this.ReportModel.ExcuteList.execute_group_id;
      var nameList = this.ReportModel.ExcuteList.name;
      var field_id = this.ReportModel.ExcuteList.id;
      var name_unit = this.ReportModel.ExcuteList.group;
      var maxpoint = this.ReportModel.ExcuteList.max_point;
      let codeunit = '';
      let data = {
        excute_id: execute_group_id,
        ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
        field_id: field_id,
        nameLists:nameList,
        unit:name_unit,
        max_point:maxpoint
      };
      this.export = await this.ReportModel.export(data);
    
     
    // console.log(this.export);
      window.open(this.export);
    }

  

}

