import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { Excute, ReportModel,ExcuteGroup } from '../../models/ReportModel';
import { ReportService } from '../../services/report.service';
import { Library } from 'src/app/shared/library/main';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {

  Excutes: Excute[];
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  rotate:any;
  thamdinh;
  index;
  a;
  constructor(
    public ReportModel: ReportModel,
    private route: Router,
    public ReportService: ReportService,
  ) {
  
  
   }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    var execute_group_id = this.ReportModel.ExcuteList.execute_group_id;
    var group = this.ReportModel.ExcuteList.group;
    var field_id = this.ReportModel.ExcuteList.id;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      field_id: field_id,
      group:this.ReportModel.ExcuteList.group
    };
    Library.showloading();
    this.Excutes = await this.ReportModel.chart(params);
    // this.Excutes[0]['index']=20;
    var nameList = this.ReportModel.ExcuteList.name;
    var name=(nameList.split("."));
    this.thamdinh= 'Điểm '+ (name[1].toLowerCase());
    this.index= 'Chỉ số thành phần '+ (name[1].toLowerCase());
    if(group=="SO_NGANH"){
      this.rotate=true;
      this.a="chart";
    }
    if(group=="QUAN_HUYEN") {
      this.rotate=false;
      this.a="cht";
    }
    if(group=="PHUONG_XA") {
      this.rotate=true;
      this.a="chart";
    }
    Library.hideloading();
   
    // this.aa=40;
    

  }
  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;

  }
  goBack() {
    let newrouter = "/system/reportdetail/field";
    this.route.navigate([newrouter]);
  }
  
 
}

