import { NgModule,enableProdMode,Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ReportRoutingModule } from './report-routing.module';
import { DxChartModule } from 'devextreme-angular';
import { ReportModel } from '../report_detail/models/ReportModel';
import { ReportService } from '../report_detail/services/report.service';
import { IndexComponent } from './components/index/index.component';
import { FieldComponent } from './components/field/field.component';
import { ResultComponent } from './components/result/result.component';
import { ChartComponent } from './components/chart/chart.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ReportRoutingModule,
    DxChartModule
  ],
  providers: [ ReportModel, ReportService],
  bootstrap: [ChartComponent],
  declarations: [IndexComponent,FieldComponent,ResultComponent,ChartComponent]
})
export class ReportModule { }

