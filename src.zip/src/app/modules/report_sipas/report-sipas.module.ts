import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HttpClientModule} from '@angular/common/http';
import { DxTooltipModule, DxTemplateModule, DxDataGridModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ReportSipasRoutingModule } from './report-sipas-routing.module';
import { ReportSipasModel } from '../report_sipas/models/ReportSipasModel';
import { ApiService } from '../report_sipas/services/api.service';
import { IndexComponent } from './components/index/index.component'
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    HttpClientModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ReportSipasRoutingModule,
    DxDataGridModule, DxTemplateModule
  ],
  // entryComponents: [

  // ],
  providers: [ApiService, ReportSipasModel],
  declarations: [IndexComponent,]
})
export class ReportSipasModule { }

