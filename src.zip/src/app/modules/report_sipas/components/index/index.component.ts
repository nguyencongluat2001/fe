import { DomSanitizer } from '@angular/platform-browser';
import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ReportSipasModel } from '../../models/ReportSipasModel';
import { ApiService } from '../../services/api.service';
import { environment } from 'src/environments/environment';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {


  bsModalRef: BsModalRef;
  arrLoaiBC: any;
  arrDotKS: any;
  arrQH: any;
  arrPX:any;
  role: any;
  loai_bao_cao: string = '';
  id: string = '';
  quan_huyen: string = '';
  nguoi_tao: string='';
  check = false;
  nam: string;
  year:string;
  parent_id:string;
  checkphuongxa=false;
  phuong_xa:string='';
  arrNguoiTao:any;
  arrDV:any;
  checknguoitao=false;
  link:any;
  baseUrrl:any;
  voice:any;
  geodetic_coordinate:any;
  fileAudioName:any;
  address_check:any;
  result:any = [];
  constructor(
    private HttpService:HttpService,
    public ReportSipasModel: ReportSipasModel,
    public apiService: ApiService,
    private sanitizer: DomSanitizer
  ) {
    this.role = JSON.parse(localStorage.getItem('user_infor'))['role'];
    let year = new Date().getFullYear();
    this.year = year.toString();
  }

  ngOnInit() {
    this.getInfo();
  }


  // async getInfo() {
  //   this.baseUrrl = environment.API_URL + 'mapReport?lat=1&lng=1';
  //   this.link = this.sanitizer.bypassSecurityTrustResourceUrl(this.baseUrrl)
  //   var param = {};
  //   var arrinfo;
  //   // var arrinfo = [];
  //   arrinfo = await this.ReportSipasModel.getInfo(param);
  //   this.arrLoaiBC = arrinfo['arrLoaiBC'];
  //   this.arrDotKS = arrinfo['arrDotKS'];
  //   this.arrQH = arrinfo['arrQH'];
  //   this.arrDV = arrinfo['arrDV'];

  // }
  getInfo() {
    let parram = {};
    this.baseUrrl = environment.API_URL + 'mapReport?lat=1&lng=1';
    this.link = this.sanitizer.bypassSecurityTrustResourceUrl(this.baseUrrl)
    var param = {};
    this.HttpService.getMethods("managesipas/reportsipas/getInfo", parram).subscribe(
        result => {
          this.arrLoaiBC = result.data['arrLoaiBC'];
          this.arrDotKS = result.data['arrDotKS'];
          this.arrQH = result.data['arrQH'];
          this.arrDV = result.data['arrDV'];
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  export() {
    let params = {
      loai_bao_cao: this.loai_bao_cao,
      id: this.id,
      year:this.year,
      // quan_huyen: this.quan_huyen,
      // phuong_xa:this.phuong_xa,
      // nguoi_tao:this.nguoi_tao
    }
    if(this.loai_bao_cao==''){
      Library.notify('Bạn phải chọn loại báo cáo', 'error');
      return;
    }
    else if(this.id==''){
      Library.notify('Bạn phải chọn đợt khảo sát', 'error');
      return;
    }
    else if (this.loai_bao_cao == 'BAO_CAO_TUNG_HUYEN_THEO_LINH_VUC' && this.quan_huyen == '') {
      Library.notify('Bạn phải chọn quận huyện', 'error');
      return;
    } else {
      Library.showloading();
      this.HttpService.postMethods('managesipas/reportsipas/export', params).subscribe(res => {
        Library.hideloading();
        if (res.success == false) {
          Library.notify(res.message, 'error');
        } else {
          window.location.href = res.urlfile;
          Library.hideloading();
        }
      });
    }
  }
  changeloaibc(e) {
    this.loai_bao_cao = e.selectedItem.code;
  }
  changedotks(e) {
    // this.trinh_do=e.value;
    this.id = e.selectedItem.id;
    this.year=e.selectedItem.year;
  }
}

