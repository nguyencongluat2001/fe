import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
// import { Headers, RequestOptions } from '@angular/http';
import { ResultDistrictModel } from '../../models/ResultDistrictModel';
import { Router } from '@angular/router';
// import { parse } from 'querystring';
// import { max } from 'rxjs/operators';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-evaluate',
  templateUrl: './evaluate.component.html',
  styleUrls: ['./evaluate.component.scss']
})
export class EvaluateComponent implements OnInit {

  @Input() data: any;
  arrStardand = [];
  arrInputdata = [];
  name: string;
  check: number = 0;
  listfile = [];
  explanation = [];
  note: string;
  recipe: string;
  max_point: any;
  point_self: any;
  typeinput: any;
  loai_trac_nghiem: any;
  is_return:any;
  constructor(
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private ExcuteModel: ResultDistrictModel,
    private route: Router,
  ) {
    if (this.ExcuteModel.getEvalist['arrStandard']) {
      this.arrStardand = this.ExcuteModel.getEvalist['arrStandard'];
    }
    if (this.ExcuteModel.getEvalist['arrInputData']) {
      this.arrInputdata = this.ExcuteModel.getEvalist['arrInputData'];
    }
    if (this.ExcuteModel.getEvalist['listfile']) {
      this.listfile = this.ExcuteModel.getEvalist['listfile'];
    }
    if (this.ExcuteModel.getEvalist['explanation']) {
      this.explanation = this.ExcuteModel.getEvalist['explanation'];
    }
    this.is_return = this.ExcuteModel.Excute.is_return;
    this.name = this.ExcuteModel.getEvalist['name'];
    this.note = this.ExcuteModel.getEvalist['note'];
    this.check = this.arrInputdata.length;
    this.max_point = this.ExcuteModel._evaluationList.max_point;
    this.loai_trac_nghiem = this.ExcuteModel._evaluationList.loai_trac_nghiem;
    for (let i = 0; i < this.check; i++) {
      let k = this.arrInputdata[i]['code_term'].replace('SH', '');
      let a = eval('this.ExcuteModel._evaluationList.tc_danh_gia_' + k);
      let b = eval('this.ExcuteModel._evaluationList.tc_tham_dinh_' + k);
      let c = eval('this.ExcuteModel._evaluationList.tc_chu_tich_' + k);

      this.arrInputdata[i]['value'] = a;
      this.arrInputdata[i]['value_tham_dinh'] = b;
      this.arrInputdata[i]['value_chu_tich'] = c;
    }
    let xxx: string, yyyy: string, zzzz: string;
    for (let i = 0; i < this.arrStardand.length; i++) {
      if (this.ExcuteModel._evaluationList.ket_qua_tn_danh_gia != null) {
        xxx = 'EFY.' + this.ExcuteModel._evaluationList.ket_qua_tn_danh_gia;
        if (xxx.indexOf(this.arrStardand[i]['code']) >= 0) {
          this.arrStardand[i]['checked'] = true;
        } else {
          this.arrStardand[i]['checked'] = false;
        }
      } else {
        this.arrStardand[i]['checked'] = false;
      }
      if (this.ExcuteModel._evaluationList.ket_qua_tn_tham_dinh != null) {
        yyyy = 'EFY.' + this.ExcuteModel._evaluationList.ket_qua_tn_tham_dinh;
        if (yyyy.indexOf(this.arrStardand[i]['code']) >= 0) {
          this.arrStardand[i]['checked_thamdinh'] = true;
        } else {
          this.arrStardand[i]['checked_thamdinh'] = false;
        }
      } else {
        this.arrStardand[i]['checked_thamdinh'] = false;
      }
      if (this.ExcuteModel._evaluationList.ket_qua_tn_chu_tich != null) {
        zzzz = 'EFY.' + this.ExcuteModel._evaluationList.ket_qua_tn_chu_tich;
        if (zzzz.indexOf(this.arrStardand[i]['code']) >= 0) {
          this.arrStardand[i]['checked_chutich'] = true;
        } else {
          this.arrStardand[i]['checked_chutich'] = false;
        }
      } else {
        this.arrStardand[i]['checked_chutich'] = false;
      }


    }
    if (this.ExcuteModel._evaluationList.loai_trac_nghiem == 'CHECKBOX') {
      this.typeinput = 'checkbox';
    } else {
      this.typeinput = 'radio';
    }

    this.recipe = this.ExcuteModel._evaluationList.recipe;
    this.point_self = this.ExcuteModel._evaluationList.point_self;
  }

  ngOnInit() {
    this.ExcuteModel.dataview = '';
  }
  thaydoitieuchuan(obj) {
    let target = obj.target;
    let total = 0;
    $('input[name=stardand]:checked').each(function () {
      total += parseFloat($(this).attr('point'));
    })
    if (this.loai_trac_nghiem != 'RADIO_AND_NOTHING') {
      $('input[name=tongdiem]').val(total);
    } else {
      this.thaydoidauvao();
    }
  }
  thaydoidauvao() {
    let congthuc = this.recipe;
    if (congthuc != '' && congthuc != null) {
      let result, sh1, sh2, sh3;
      sh1 = $('#SH1').val();
      sh2 = $('#SH2').val();
      sh3 = $('#SH3').val();
      if ($('#SH1').val() != '') {
        congthuc = congthuc.replace('#SH1#', sh1);
      }
      if ($('#SH2').val() != '') {
        congthuc = congthuc.replace('#SH2#', sh2);
      }
      if ($('#SH3').val() != '') {
        congthuc = congthuc.replace('#SH3#', sh3);
      }
      if (congthuc.indexOf("#") < 0) {
        result = eval(congthuc);
        $('#ketquadauvao').val(result);
        if (this.loai_trac_nghiem == 'RADIO_AND_NOTHING') {
          let maxpoint;
          $('input[name=stardand]:checked').each(function () {
            maxpoint = parseFloat($(this).attr('point'));
          })
          if (result / 100 > 1) {
            Library.notify('Không được quá điểm tối đa', 'warning')
            $('input[name=tongdiem]').val('');
          } else {
            if (maxpoint == '' || maxpoint == null) {
              Library.notify('Không được để trống đáp án', 'warning');
              $('input[name=tongdiem]').val('');
            } else {
              $('input[name=tongdiem]').val(result / 100 * maxpoint);
            }
          }
        }
      }
    }
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);

  }
  // cancel() {
  //   this.check = false;
  //   this.checkedit = false;
  // }
}
