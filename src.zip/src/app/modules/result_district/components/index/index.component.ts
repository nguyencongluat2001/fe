import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { RouterLink } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ResultDistrictModel, Excute } from '../../models/ResultDistrictModel';
import { ResultDistrictService } from '../../services/ResultDistrict.service';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  listEvalution: any;
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  txt_search = '';
  listsGroup: any;
  years: any;
  defaultVisible: false;

  constructor(
    private HttpService:HttpService,
    private modalService: BsModalService,
    public ResultDistrictModel: ResultDistrictModel,
    private route: Router,
    private router: ActivatedRoute,
    public ResultDistrictService: ResultDistrictService,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      txtSearch: this.txt_search,
      role:JSON.parse(localStorage.getItem('user_infor'))['role']
    };
    Library.showloading();
    this.getAll(params);
    // this.listEvalution = await this.ResultDistrictModel.getAll(params);
    Library.hideloading();
  }
  getAll(params) {
    this.HttpService.getMethods("resultdistrict/getEvaluation", params).subscribe(
        result => {
          this.listEvalution = result.data.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
  }

  convertDatesend(data) {
    return Library.formatDate(data.date_send);
  }

  selectEvaluation(e) {
    this.selectedItems = e.selectedRowsData;
  }


  getlist() {
    let i = 0;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để xem", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else if (i == 1) {
      this.ResultDistrictModel.objEvalution = this.selectedItems[0];
      let newrouter = "/system/result_district/list";
      this.route.navigate([newrouter]);
    }
  }
  
}
