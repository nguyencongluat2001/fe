import { Component, OnInit, Input } from '@angular/core';
// import { AddExplanationComponent } from '../add-explanation/add-explanation.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Excute, ResultDistrictModel } from '../../models/ResultDistrictModel';
import { ListexplanationComponent } from '../listexplanation/listexplanation.component';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-explanation',
  templateUrl: './explanation.component.html',
  styleUrls: ['./explanation.component.scss']
})
export class ExplanationComponent implements OnInit {

  @Input() data: any;
  arrfile: any = [];
  status: any;
  show: boolean;
  showexplan: boolean;
  index: number;
  constructor(
    private modalService: BsModalService,
    public excuteModel: ResultDistrictModel
  ) {
  }

  ngOnInit() {
    if (this.data['status'] == 'XEM_CHI_TIET') {
      this.status = this.data['status'];
      this.data = this.data.data;
    }
    this.show = false;
    this.showexplan = true;
    this.index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == this.data['id']);
    // if (this.excuteModel.listDataExcute[this.index]['listfile'] != []) {
    //   this.show = true;
    // }
    if (this.excuteModel.listDataExcute[this.index]['explanation'] == null||this.excuteModel.listDataExcute[this.index]['explanation'] == 'null') {
      this.excuteModel.listDataExcute[this.index]['explanation'] = '';
    }

    if (this.excuteModel.listDataExcute[this.index]['explanation'] != '' && this.excuteModel.listDataExcute[this.index]['explanation'] != null) {
      this.showexplan = true;
    }
  }
  showexplandetail(){
    this.excuteModel.Excute = this.data;
    this.modalService.show(ListexplanationComponent);
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);

  }
}
