import { Injectable } from '@angular/core';
import { Router } from '@angular/router';


export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: number = 0;
    max_point:number;
    ownercode: string = localStorage.getItem('unit_infor')['code']

}
export class Question {
    id                : string = '';
    evaluation_id     : string = '';
    evaluation_list_id: string = '';
    user_id           : string = '';
    user_name         : string = '';
    type_vote         : string = '';
    name              : string = '';
    type_unit         : string = '';
    option_A          : string = '';
    option_B          : string = '';
    option_C          : string = '';
    option_D          : string = '';
    option_E          : string = '';
    percent_A         : number = 100;
    percent_B         : number = 50;
    percent_C         : number = 25;
    percent_D         : number = 0;
    percent_E         : number = 0;
    status            : string = '';
    order             : string = '';
    created_at        : string = '';
    updated_at        : string = '';
}

export class Tab {
    id: string;
    name: string;
  }

const tabs: Tab[] = [
    {
      id: 'SO_NGANH',
      name: 'Phiếu tỉnh',
    },
    {
      id: 'QUAN_HUYEN',
      name: 'Phiếu huyện',
    },
];
@Injectable()

export class ManageQuestionModel {

    _excutelist: Excute;
    objExcute: any;
    _question:any;
    _dataview: any;
    _myClass: any;
    _test: any;

    constructor(private route: Router) {

    }

    set ExcuteList(value: any) {
        this._excutelist = value;
    }

    get ExcuteList() {
        return this._excutelist;
    }
    myClass(value: any) {
        this._myClass = value;
    }
    set question(value: any) {
        this._question = value;
    }
    get question() {
        return this._question;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }
    getTabs(): Tab[] {
        return tabs;
    }
    getQuestion(){
        if(!this._dataview){
            this._dataview = new Question();
        }
        return this._dataview;
    }

    setQuestion(data){
        if(!data){
            data = new Question();
            if(this._dataview){
                data.order = this._dataview.length + 1;
            }
        }
        this._dataview = data;
    }
}
