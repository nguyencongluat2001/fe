import { CopyComponent } from './../copy/copy.component';
import { Component, OnInit } from '@angular/core';
import { Question, ManageQuestionModel, Tab } from '../../models/ManageQuestionModel';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddComponent } from '../add/add.component';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
import { ConfirmDialogComponent, ConfirmDialogModel } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Question: Question[];
  bsModalRef: BsModalRef;
  selectedItems: Question[] = [];
  export_chart: any;
  tabs: any;
  dataTab: Tab[];
  selectedTabIndex: any;
  evaluation: any;
  evaluation_id: any;
  pageEnabled: boolean = false;
  tabIndex = 0;
  baseUrl = 'sociological/managequestion/';


  constructor(
    public ManageQuestionModel: ManageQuestionModel,
    private modalService: BsModalService,
    private HttpService: HttpService,
    public dialog: MatDialog
  ) {
    this.selectedTabIndex = 'SO_NGANH';
  }

  ngOnInit() {
    // this.loadList();
    this.getEvalua();
  }

  /**
   * Màn hình danh sách
   */
  async loadList() {
    let params = {
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      type_unit: this.selectedTabIndex,
      evaluation_id: this.evaluation_id
    };
    Library.showloading();

    this.HttpService.getMethods(this.baseUrl + "getall", params).subscribe(
      response => {
        this.Question = response.data;
        if (this.Question.length > 0) {
          this.pageEnabled = true;
        } else {
          this.pageEnabled = false;
        }
        Library.hideloading();
      });
  }
  async getEvalua() {
    var params = {
      group: this.selectedTabIndex
    };

    this.HttpService.getMethods(this.baseUrl + "getevaluation", params).subscribe(
      response => {
        this.evaluation = response.data;
        if (this.ManageQuestionModel.question && this.ManageQuestionModel.question != undefined && this.ManageQuestionModel.question.evaluation_id != '') {
          this.evaluation_id = this.ManageQuestionModel.question.evaluation_id;
        } else {
          this.evaluation_id = this.evaluation[0].id;
        }
      });
  }
  evaluationchange(e) {
    if (e.selectedItem) {
      this.evaluation_id = e.selectedItem.id;
      this.loadList();
    }
  }
  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }
  convertTodate(data) {
    return Library.formatDate(data.todate);
  }
  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  add() {
    let myClass = this;
    this.ManageQuestionModel.myClass(myClass);
    this.ManageQuestionModel.question = new Question;
    this.ManageQuestionModel.question.order = this.Question.length + 1;
    this.ManageQuestionModel.question.type_unit = this.selectedTabIndex;
    this.ManageQuestionModel.question.evaluation_id = this.evaluation_id;
    this.modalService.show(AddComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
  }
  edit() {
    let myClass = this;
    this.ManageQuestionModel.myClass(myClass);
    let i = 0;
    let a;
    let iditem;
    this.selectedItems.forEach((item) => {
      i++;
      iditem = item.id;
    });
    if (i == 0) {
      Library.notify("Vui lòng chọn đối tượng để sửa", 'error');
      return;
    }
    if (i > 1) {
      Library.notify("Chỉ được chọn một đối tượng để sửa", 'error');
      return;
    } else if (i == 1) {
      this.ManageQuestionModel.question = this.selectedItems[0];
      this.modalService.show(AddComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
    }
  }
  delete() {
    const dialogData = new ConfirmDialogModel('Xác nhận', 'Bạn có chắc chắn muốn xóa đối tượng đã chọn?');
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '30%',
      disableClose: true,
      data: dialogData,
    });

    let ids = '';
    this.selectedItems.forEach((item) => {
      ids += item.id + ',';
    });
    let params = {
      ids: ids
    }

    dialogRef.afterClosed().subscribe((dialogResult) => {
      if (dialogResult == true) {
        this.HttpService.postMethods(this.baseUrl + "deletes", params).subscribe(
          (response: any) => {
            Library.hideloading();
            if (response.data.success) {
              Library.notify(response.data.message, 'success');
              this.loadList();
            } else {
              Library.notify(response.data.message, 'error');
            }
          });
      }
    });
  }
  copy() {
    let myClass = this;
    this.ManageQuestionModel.myClass(myClass);
    this.ManageQuestionModel.question = new Question;
    this.ManageQuestionModel.question.type_unit = this.selectedTabIndex;
    this.modalService.show(CopyComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
  }
  handlePropertyChange(e) {
    this.pageEnabled = false;
    if (this.ManageQuestionModel.question != undefined) {
      this.ManageQuestionModel.question.evaluation_id = '';
    }
    this.evaluation = undefined;
    this.Question = [];
    if (e.index == 0) {
      this.selectedTabIndex = 'SO_NGANH';
      this.tabIndex = 0;
    } else if (e.index == 1) {
      this.selectedTabIndex = 'QUAN_HUYEN';
      this.tabIndex = 1;
    }
    this.getEvalua();
  }

}

