import { ManageQuestionModel, Question } from './../../models/ManageQuestionModel';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Component, EventEmitter, OnInit } from '@angular/core';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-copy',
  templateUrl: './copy.component.html',
  styleUrls: ['./copy.component.scss']
})
export class CopyComponent implements OnInit {

  onUpdated = new EventEmitter();
  question: Question;
  type_vote: any;
  typeVote: any;
  typeVoteNew: any;
  evaluation: any;
  evaluationNew: any;
  capdonvi: any;
  evaluation_id: any;
  evaluationNew_id: any;

  constructor(
    public bsModalRef: BsModalRef,
    public ManageQuestionModel: ManageQuestionModel,
    private HttpService: HttpService,
  ) {
    this.question = this.ManageQuestionModel.question;
    this.capdonvi = this.question.type_unit;
  }

  ngOnInit() {
    this.gettypevote();
    this.getevaluation();
    this.getevaluationNew();
  }
  async gettypevote() {
    var params = {
      type_unit: this.ManageQuestionModel.question.type_unit
    };
    this.HttpService.getMethods("sociological/managequestion/gettypevote", params).subscribe(
      response => {
        this.type_vote = response.data
      });

  }

  async getevaluation() {
    var params = {
      group: this.capdonvi
    };
    this.HttpService.getMethods("sociological/managequestion/getevaluation", params).subscribe(
      response => {
        this.evaluation = response.data
      });
  }

  async getevaluationNew() {
    var params = {
      group: this.capdonvi,
    };
    Library.showloading();
    this.HttpService.getMethods("sociological/managequestion/getevaluation", params).subscribe(
      response => {
        Library.hideloading();
        this.evaluationNew = response.data;
        this.evaluationNew_id = this.evaluationNew[0].id;
      });
  }
  changeTypevote(e) {
    this.typeVote = e.selectedItem.code;
  }
  changeTypevoteNew(e) {
    this.typeVoteNew = e.selectedItem.code;
  }
  evaluationchange(e) {
    this.evaluation_id = e.selectedItem.id;
  }
  evaluationchangeNew(e) {
    this.evaluationNew_id = e.selectedItem.id;
  }
  update() {
    let params = {
      type_vote: this.typeVote,
      type_vote_new: this.typeVoteNew,
      evaluation_id: this.evaluation_id,
      evaluationNew_id: this.evaluationNew_id,
    }

    Library.showloading();
    this.HttpService.postMethods("sociological/managequestion/copy", params).subscribe(
      (response: any) => {
        Library.hideloading();
        if (response.data.success) {
          this.ManageQuestionModel._myClass.loadList();
          this.bsModalRef.hide();
          Library.notify(response.data.message, 'success');
          this.onUpdated.emit();
        } else {
          Library.notify(response.data.message, 'error');
        }
      });
  }

}
