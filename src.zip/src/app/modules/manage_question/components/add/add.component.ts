import { Component, OnInit, enableProdMode, NgModule, EventEmitter } from '@angular/core';
import { Question, ManageQuestionModel } from '../../models/ManageQuestionModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {

  onUpdated = new EventEmitter();
  question: Question;
  evaluation;
  type_vote: any;
  group: any;
  evaluation_list: any;
  capdonvi = '';
  evaluation_id = '';
  eval_list_id=[];
  name = '';
  typeVote: string;
  // eval_list_id = '';
  option_A = '';
  option_B = '';
  option_C = '';
  option_D = '';
  option_E = '';
  percent_A: number;
  percent_B: number;
  percent_C: number;
  percent_D: number;
  percent_E: number;
  status: any;
  check = true;
  order;
  id = '';
  baseUrl = 'sociological/managequestion/';


  constructor(
    public ManageQuestionModel: ManageQuestionModel,
    private route: Router,
    public bsModalRef: BsModalRef,
    private HttpService: HttpService,
    public dialog: MatDialog,
  ) {
    this.question = this.ManageQuestionModel.question;
    this.order = this.question.order;
    this.capdonvi = this.question.type_unit;
    if (this.ManageQuestionModel.question) {
      this.name = this.ManageQuestionModel.question.name;
      this.typeVote = this.ManageQuestionModel.question.type_vote;
      this.evaluation_id = this.ManageQuestionModel.question.evaluation_id;
      this.eval_list_id = this.ManageQuestionModel.question.evaluation_list_id;
      this.option_A = this.ManageQuestionModel.question.option_A;
      this.option_B = this.ManageQuestionModel.question.option_B;
      this.option_C = this.ManageQuestionModel.question.option_C;
      this.option_D = this.ManageQuestionModel.question.option_D;
      this.option_E = this.ManageQuestionModel.question.option_E;
      this.percent_A = this.ManageQuestionModel.question.percent_A;
      this.percent_B = this.ManageQuestionModel.question.percent_B;
      this.percent_C = this.ManageQuestionModel.question.percent_C;
      this.percent_D = this.ManageQuestionModel.question.percent_D;
      this.percent_E = this.ManageQuestionModel.question.percent_E;
      this.status = this.ManageQuestionModel.question.status;
      this.order = this.ManageQuestionModel.question.order;
      if(this.ManageQuestionModel.question.evaluation_list_id==''){
        this.eval_list_id=[];
      }
      else{
        this.eval_list_id=this.ManageQuestionModel.question.evaluation_list_id.split(',');
      }
    }


  }

  ngOnInit() {
    this.loadList();
    this.gettypevote();
    this.getgroup();
    if (this.ManageQuestionModel.question && this.ManageQuestionModel.question == '[]') {
      this.getevaluation();
      if(this.question.evaluation_id !==''){
        this.getExecute();
      }
    }

  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {}

  onSubmit(e) {
    if (this.check == true) {
      this.status = 1;
    }
    else {
      this.status = 0;
    }
    let user  = JSON.parse(localStorage.getItem('user_infor'));
    var params = {
      id: this.question.id,
      evaluation_id: this.evaluation_id,
      eval_list_id: this.eval_list_id,
      user_id: user.id,
      user_name: user.name,
      name: this.name,
      capdonvi: this.capdonvi,
      type_vote: this.typeVote,
      option_A: this.option_A,
      option_B: this.option_B,
      option_C: this.option_C,
      option_D: this.option_D,
      option_E: this.option_E,
      percent_A: this.percent_A,
      percent_B: this.percent_B,
      percent_C: this.percent_C,
      percent_D: this.percent_D,
      percent_E: this.percent_E,
      status: this.status,
      order: this.order
    }
    Library.showloading();
    this.HttpService.postMethods(this.baseUrl + "update", params).subscribe(
      (response: any) => {
        Library.hideloading();
        if (response.data.success) {
            this.bsModalRef.hide();
            Library.notify(response.data.message, 'success');
            // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
            this.ManageQuestionModel._myClass.loadList();
        } else {
            Library.notify(response.data.message, 'error');
        }
      });
  }

  async gettypevote() {
    var params = {
      type_unit: this.capdonvi
    };
    Library.showloading();
    this.HttpService.getMethods("sociological/managequestion/gettypevote", params).subscribe(
      response => {
        Library.hideloading();
        this.type_vote = response.data
      });

  }
  async getgroup() {
    var params = {};
    Library.showloading();
    this.HttpService.getMethods("sociological/managequestion/getgroup", params).subscribe(
      response => {
        Library.hideloading();
        this.group = response.data;
      });

  }
  async getevaluation() {
    var params = {
      group: this.capdonvi
    };
    this.HttpService.getMethods("sociological/managequestion/getevaluation", params).subscribe(
      response => {
        Library.hideloading();
        this.evaluation = response.data;
        this.evaluation_id = this.ManageQuestionModel.question.evaluation_id;
      });
  }
  async getExecute() {
    var params = {
      evaluation_id: this.evaluation_id
    };
    Library.showloading();
    this.HttpService.getMethods("sociological/managequestion/getExecute", params).subscribe(
      response => {
        Library.hideloading();
        this.evaluation_list = response.data;
      });
  }
  goback() {
    this.bsModalRef.hide();
  }
  changegroup(e) {
    this.capdonvi = e.selectedItem.code;
    this.getevaluation();
  }
  changeEvalist(e) {
    this.eval_list_id = e.value;
  }
  changeTypevote(e) {
    this.typeVote = e.selectedItem.code;
  }
  evaluationchange(e) {

    this.evaluation_id = e.selectedItem.id;
    this.getExecute();
  }
  onValueChanged(e) {
    this.check = e.value;
    if (e.value == true) {
      this.status = 1;
    }
    else {
      this.status = 0;
    }
  }
}

