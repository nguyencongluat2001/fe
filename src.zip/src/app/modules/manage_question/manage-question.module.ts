import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule, DxTabPanelModule } from 'devextreme-angular';
import { DxTreeViewModule, DxListModule } from 'devextreme-angular';
import { DxTreeListModule, DxCheckBoxModule,DxSelectBoxModule,DxTagBoxModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ManageQuestionRoutingModule } from './manage-question-routing.module';
import { DxChartModule } from 'devextreme-angular';
import { ManageQuestionModel } from '../manage_question/models/ManageQuestionModel';
import { IndexComponent } from './components/index/index.component';
import { AddComponent } from './components/add/add.component';
import { CopyComponent } from './components/copy/copy.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
import { HttpClientModule } from '@angular/common/http';
import { MaterialModule } from 'src/app/core/load.material.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ManageQuestionRoutingModule,
    DxChartModule,
    DxCheckBoxModule,
    DxSelectBoxModule,
    DxTagBoxModule,
    DxTabPanelModule,
    DxTemplateModule,
    HttpClientModule,
    MaterialModule
  ],
  providers: [ ManageQuestionModel],
  declarations: [IndexComponent,AddComponent, CopyComponent]
})
export class ManageQuestionModule { }

