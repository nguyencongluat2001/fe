import { TestBed, inject } from '@angular/core/testing';

// import { UsersApi } from './users.service';

// describe('UsersApi', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [UsersApi]
//     });
//   });

//   it('should be created', inject([UsersApi], (service: UsersApi) => {
//     expect(service).toBeTruthy();
//   }));
// });
