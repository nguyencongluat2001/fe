import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule, DxDataGridModule, DxButtonModule} from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ReportCompareRoutingModule } from './report-compare-routing.module';
import { ReportCompareModel } from '../report_compare/models/ReportCompareModel';
import { ApiService } from '../report_compare/services/api.service';
import { IndexComponent } from './components/index/index.component'
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ReportCompareRoutingModule,
    DxDataGridModule, DxTemplateModule,DxButtonModule
  ],
  // entryComponents: [

  // ],
  providers: [ApiService, ReportCompareModel],
  declarations: [IndexComponent,]
})
export class ReportCompareModule { }

