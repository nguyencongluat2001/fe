import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Router } from '@angular/router';
import { Excute, ReportCompareModel } from '../../models/ReportCompareModel';
import { ApiService } from '../../services/api.service';
import { Library } from 'src/app/shared/library/main';
import { BsModalService } from 'ngx-bootstrap/modal';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Excutes: Excute[];
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  selectedKhoiDV: string = '';
  arrExcute: any[] = [
    { id: '', name: 'Chọn đợt đánh giá' }
  ];
  excute1: string = '';
  excute2: string = '';
  role: any;
  constructor( 
    public HttpService:HttpService,
    public ExcuteModel: ReportCompareModel,
    private modalService: BsModalService,
    private route: Router,
    public apiService: ApiService,
  ) { 
    this.role=JSON.parse(localStorage.getItem('user_infor'))['role'];
  }

  ngOnInit() {
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */
  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  changkhoidonvi(e) {
    if (this.selectedKhoiDV != '') {
      this.arrExcute = [];
      let params = {
        KhoiDV: this.selectedKhoiDV
      }
      this.HttpService.postMethods('report/compare/getdatasearch', params).subscribe(res => {
        res.data.forEach(element => {
          this.arrExcute.push(element);
        });
      });
    } else {
      this.arrExcute = [
        { id: '', name: 'Chọn đợt đánh giá' }
      ];
    }
  }
  checkduplicate() {
    if (this.excute1 == this.excute2 && this.excute1 != '') {
      Library.notify('Không được chọn cùng một đợt để so sánh', 'error');
      this.excute2 = '';
      return;
    }
  }
  export() {
    let params = {
      excute1: this.excute1,
      excute2: this.excute2,
      KhoiDV: this.selectedKhoiDV,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    }
    if (this.excute1 != '' && this.excute2 != '' && this.selectedKhoiDV != '') {
      this.HttpService.postMethods('report/compare/exportcompare', params).subscribe(res => {
        if (!res.success) {
          Library.notify(res.message, 'error');
        } else {
          window.location.href = res.urlfile;
        }
      });
    } else {
      Library.notify('Bạn phải chọn đầy đủ thông tin', 'error');
      return;
    }
  }
}

