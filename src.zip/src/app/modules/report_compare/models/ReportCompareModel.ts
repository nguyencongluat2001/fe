import { Injectable } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';


export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: number = 0;
    ownercode: string = localStorage.getItem('unit_infor')['code']
}

export class List {
    id: string;
    parrent_id: string;
    name: string;
    max_point: number;
    new_point: number;
    explanation: string
    listfile: string
}

@Injectable()

export class ReportCompareModel {

    _excute: Excute;
    objExcute: any;
    private _list: List;
    private _dataview: any;
    public listDataExcute: any;

    constructor(private apiservice: ApiService, private route: Router) {

    }
    set Excute(value: any) {
        this._excute = value;
    }

    get Excute() {
        return this._excute;
    }
    set setlist(value: any) {
        this._list = value;
    }

    get getlist() {
        return this._list;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }
}
