import { Injectable } from '@angular/core';
import { ManagePointSociologyService } from '../services/vote-citizen.service';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';


export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: number = 0;
    max_point:number;
    ownercode: string = localStorage.getItem('unit_infor')['code']

}
export class ExcuteGroup{
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: number;
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    status: number = 0;
    user_id: string = '';
}
export class List {
    id: string;
    parrent_id: string;
    name: string;
    max_point: number;
    new_point: number;
    explanation: string
    listfile: string
}
export class Question {
    name:string;
    id:string;
    evaluation_id:string;
    evaluation_list_id:string;
    type_vote:string;
    option_A:string;
    option_B:string;
    option_C:string;
    option_D:string;
    percent_A:number =10;
    percent_B:number =40;
    percent_C:number=70;
    percent_D:number=100;
    status:string;
    order=1;
    type_unit:string;
    listoption:any;
    answer:string;

}

export class Unit {
       id:string;
       ownercode:string;
       nameunit:string;
       evaluation_id:string;
       capdonvi:string;
}

@Injectable()

export class ManagePointSociologyModel {

    _excute: ExcuteGroup;
    _excutelist: Excute;
    objExcute: any;
    private _list: List;
    private _dataview: any;
    _unit:Unit;
    constructor(private ManagePointSociologyService: ManagePointSociologyService, private route: Router) {

    }

    async getAll(parram,async: boolean = false): Promise<ExcuteGroup[]> {
        var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
        let response = await this.ManagePointSociologyService.callGet('getall', parram);
        return response;
    }

    set Excute(value: any) {
        this._excute = value;
    }

    get Excute() {
        return this._excute;
    }
    set Unit(value: any) {
        this._unit = value;
    }

    get Unit() {
        return this._unit;
    }
    set setlist(value: any) {
        this._list = value;
    }

    get getlist() {
        return this._list;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }

    async getAllList(params, async: boolean = false): Promise<List[]> {
        let response = await this.ManagePointSociologyService.callGet('getallList', params);
        return response;
    }

    
    export(params) {
        this.ManagePointSociologyService.callPost('export', params).subscribe((response: any) => {
            if (!response.success) {
                Library.notify(response.message, 'error');
            } else {
                window.location.href = response.urlfile;
            }
          
        });
    }
   
   
    async getUnit(params, async: boolean = false): Promise<List[]> {
        let response = await this.ManagePointSociologyService.callGet('getUnit', params);
        return response;
    }
   
    updateSociology(data, myclass) {
        Library.showloading();
      
        this.ManagePointSociologyService.callPost('updateSociology', data).subscribe((response: any) => {
            Library.hideloading();
            if (response.success) {
              
                Library.notify(response.message, 'success');
                myclass.loadList();
                // Kiểm tra nếu là thêm mới thì load lại dữ liệu màn hình danh sách
                // if (!data.id) {
                // let newrouter = "";
                // if (this.route.url == "/system/vote_citizen/list_vote") {
                //     newrouter = "/system/vote_citizen/list_vote_index";
                // } else {
                //     newrouter = "/system/vote_citizen/list_vote";
                // }
                // this.route.navigate([newrouter]);
                // }
              
            } else {
                Library.notify(response.message, 'error');
            }
        });
    }
    async getlistunit(parram,async: boolean = false): Promise<Question[]> { 
        let response = await this.ManagePointSociologyService.callGet('getListunit', parram);
        return response;
    }
    async getresult(parram,async: boolean = false): Promise<Question[]> { 
        let response = await this.ManagePointSociologyService.callGet('getresult', parram);
        return response;
    }
    async chart(parram,async: boolean = false) { 
        let response = await this.ManagePointSociologyService.callGet('getchart', parram);
        return response;
    }
    async exportchart(parram,async: boolean = false) { 
        let response = await this.ManagePointSociologyService.callGet('exportchart', parram);
        return response;
    }




}
