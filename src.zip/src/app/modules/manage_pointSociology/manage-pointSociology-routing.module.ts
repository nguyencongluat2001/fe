import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { ListunitComponent } from './components/listunit/listunit.component';
import { SeeComponent } from './components/see/see.component';
import { ChartsingleComponent } from './components/chartsingle/chartsingle.component';
const routes: Routes = [
  {
    path: ''
    , component: IndexComponent
    , data: {
      title: 'Quản trị điểm XHH'
    }
  },
 
  {
    path: 'listunit', component: ListunitComponent, data: {
      title: 'Danh sách đơn vị'
    }
  },
  {
    path: 'see', component: SeeComponent, data: {
      title: 'Danh sách các tiêu chí XHH'
    }
  },
  {
    path: 'chart', component: ChartsingleComponent, data: {
      title: 'Biểu đồ'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManagePointSociologyRoutingModule { }
