import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule, DevExtremeModule } from 'devextreme-angular';
import { DxTreeViewModule, DxListModule } from 'devextreme-angular';
import { DxTreeListModule, DxCheckBoxModule,DxSelectBoxModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ManagePointSociologyRoutingModule } from './manage-pointSociology-routing.module';
import { DxChartModule } from 'devextreme-angular';
import { ManagePointSociologyModel } from '../manage_pointSociology/models/ManagePointSociologyModel';
import { ManagePointSociologyService } from '../manage_pointSociology/services/vote-citizen.service';
import { IndexComponent } from './components/index/index.component';
import { ListunitComponent } from './components/listunit/listunit.component';
import { SeeComponent } from './components/see/see.component';
import { ChartsingleComponent } from './components/chartsingle/chartsingle.component';
@NgModule({
  imports: [
    CommonModule,
    DevExtremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ManagePointSociologyRoutingModule,
    DxChartModule,
    DxCheckBoxModule,
    DxSelectBoxModule

  ],
  // entryComponents: [
  // ],
  providers: [ ManagePointSociologyModel, ManagePointSociologyService],
  declarations: [IndexComponent,ListunitComponent,SeeComponent,ChartsingleComponent]
})
export class ManagePointSociologyModule { }

