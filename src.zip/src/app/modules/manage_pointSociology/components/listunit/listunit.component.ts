import { Component, OnInit } from '@angular/core';
import { Unit, ManagePointSociologyModel } from '../../models/ManagePointSociologyModel';
import { ManagePointSociologyService } from '../../services/vote-citizen.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-listunit',
  templateUrl: './listunit.component.html',
  styleUrls: ['./listunit.component.scss']
})
export class ListunitComponent implements OnInit {

  Excutes: any;
  bsModalRef: BsModalRef;
  selectedItems: Unit[] = [];
  export_chart: any;
  constructor(
    public ManagePointSociologyModel: ManagePointSociologyModel,
    public ManagePointSociologyService: ManagePointSociologyService,
    private route: Router,
  ) { }

  ngOnInit() {
    this.loadList();
    // console.log(this.ManagePointSociologyModel.Excute);
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      evaluation_id: this.ManagePointSociologyModel.Excute.id
    };
    Library.showloading();
    this.Excutes = await this.ManagePointSociologyModel.getlistunit(params);
    Library.hideloading();
  }

  convertFromdate(data) {
    return Library.formatDate(data.date_update_sociology);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  see() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ManagePointSociologyModel.Unit = this.selectedItems[0];
      let newrouter = '/system/manage_pointSociology/see';
      this.route.navigate([newrouter]);
    }
  }
  updatepoint() {
   var myclass=this; 
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để cập nhật", 'error');
      return;
    } else {
      var selectitem=this.selectedItems[0]
      var result = Library.confirm("Bạn có chắc chắn muốn cập nhật điểm xã hội học?", "Thông báo");
      if (result) {
        result.then(function (dialogResult) {
          if (dialogResult) {
          var params={
            evaluation_id: selectitem.evaluation_id,
            ownercode: selectitem.ownercode,
          };
          myclass.ManagePointSociologyModel.updateSociology(params,myclass);
          }
        });


      }
    }
  }
  goback() {
    let newrouter = "/system/manage_pointSociology";
    this.route.navigate([newrouter]);
  }
  export() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để in", 'error');
      return;
    } else {
      this.ManagePointSociologyModel.Unit = this.selectedItems[0];
      var param = {
        evaluation_id: this.selectedItems[0].evaluation_id,
        ownercode: this.selectedItems[0].ownercode,
        tendonvi: this.selectedItems[0].nameunit
      }
      Library.showloading();
      this.ManagePointSociologyModel.export(param);
      Library.hideloading();
    }
  }
}

