import { Component, OnInit } from '@angular/core';
import { ExcuteGroup, ManagePointSociologyModel } from '../../models/ManagePointSociologyModel';
import { ManagePointSociologyService } from '../../services/vote-citizen.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-see',
  templateUrl: './see.component.html',
  styleUrls: ['./see.component.scss']
})
export class SeeComponent implements OnInit {

  Unit: any;
  bsModalRef: BsModalRef;
  selectedItems: ExcuteGroup[] = [];
  export_chart: any;
  nameunit: string;
  capdonvi: string = '';
  constructor(
    public ManagePointSociologyModel: ManagePointSociologyModel,
    public ManagePointSociologyService: ManagePointSociologyService,
    private route: Router,
  ) {
    this.nameunit = 'Danh sách điểm XHH của ' + this.ManagePointSociologyModel.Unit.nameunit;
    this.capdonvi = this.ManagePointSociologyModel.Unit.capdonvi;
  }

  ngOnInit() {
    this.loadList();
    // console.log(this.ManagePointSociologyModel.Unit);
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      evaluation_id: this.ManagePointSociologyModel.Unit.evaluation_id,
      ownercode: this.ManagePointSociologyModel.Unit.ownercode
    };
    Library.showloading();
    this.Unit = await this.ManagePointSociologyModel.getresult(params);
    Library.hideloading();
  }


  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }

  goback() {
    let newrouter = "/system/manage_pointSociology/listunit";
    this.route.navigate([newrouter]);
  }

}

