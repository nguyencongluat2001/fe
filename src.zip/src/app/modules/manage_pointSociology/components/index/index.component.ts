import { Component, OnInit } from '@angular/core';
import { ExcuteGroup, ManagePointSociologyModel } from '../../models/ManagePointSociologyModel';
import { ManagePointSociologyService } from '../../services/vote-citizen.service';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Excutes: ExcuteGroup[];
  bsModalRef: BsModalRef;
  selectedItems: ExcuteGroup[] = [];
  export_chart: any;
  constructor(
    public ManagePointSociologyModel: ManagePointSociologyModel,
    public ManagePointSociologyService: ManagePointSociologyService,
    private route: Router,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    };
    Library.showloading();
    this.Excutes = await this.ManagePointSociologyModel.getAll(params);
    Library.hideloading();
  }

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  // export() {
  //   if (this.selectedItems.length > 1) {
  //     Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
  //     return;
  //   } else {
  //     this.reportmodel.Excute = this.selectedItems[0];
  //     let params = {
  //       execute_group_id: this.reportmodel.Excute['id']
  //     };
  //     this.reportservice.callPost('export', params).subscribe(res => {
  //       if (!res.success) {
  //         Library.notify(res.message, 'error');
  //       } else {
  //         window.location.href = res.urlfile;
  //       }
  //     });
  //   }

  // }
  showlist(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ManagePointSociologyModel.Excute = this.selectedItems[0];
      let newrouter='/system/manage_pointSociology/listunit';
      this.route.navigate([newrouter]);
    }
  }
  seechart(){
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.ManagePointSociologyModel.Excute = this.selectedItems[0];
      let newrouter='/system/manage_pointSociology/chart';
      this.route.navigate([newrouter]);
    }
  }
 
}

