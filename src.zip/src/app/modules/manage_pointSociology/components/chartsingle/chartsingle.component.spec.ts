import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartsingleComponent } from './chartsingle.component';

describe('ChartsingleComponent', () => {
  let component: ChartsingleComponent;
  let fixture: ComponentFixture<ChartsingleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChartsingleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartsingleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
