import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { ExcuteGroup, ManagePointSociologyModel } from '../../models/ManagePointSociologyModel';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-chartsingle',
  templateUrl: './chartsingle.component.html',
  styleUrls: ['./chartsingle.component.scss']
})
export class ChartsingleComponent implements OnInit {

  Excutes: ExcuteGroup[];
  export:any;
  bsModalRef: BsModalRef;
  selectedItems: ExcuteGroup[] = [];
  rotate:any;
  name;
  constructor(
    public ManagePointSociologyModel: ManagePointSociologyModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,

  ) {
  
  
   }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    var execute_group_id = this.ManagePointSociologyModel.Excute.id;
    var group=this.ManagePointSociologyModel.Excute.group;
    var nameEval = this.ManagePointSociologyModel.Excute.name;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      nameEvaluation:nameEval,
      group:group
    };
    Library.showloading();
    this.Excutes = await this.ManagePointSociologyModel.chart(params);
   this.name="Biểu đồ kết quả điều tra XHH của đợt "+nameEval;
   if(group=="SO_NGANH"){
    this.rotate=true;
   
  }
  if(group=="QUAN_HUYEN") {
    this.rotate=false;
   
  }
   Library.hideloading();
  }
  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;

  }
  async exportchart(){
    var group=this.ManagePointSociologyModel.Excute.group;
   var execute_group_id = this.ManagePointSociologyModel.Excute.id;
   var nameEval = this.ManagePointSociologyModel.Excute.name;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      nameEvaluation:nameEval,
       group:group
    };
    this.export = await this.ManagePointSociologyModel.exportchart(params);
    window.open(this.export);
  }
  goBack() {
    let newrouter = "/system/manage_pointSociology";
    this.route.navigate([newrouter]);
  }
}
