import { Component, OnInit } from '@angular/core';
import { MarkpointModel } from '../../models/MarkpointModel'
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';

@Component({
  selector: 'app-markpointsociology',
  templateUrl: './markpointsociology.component.html',
  styleUrls: ['./markpointsociology.component.scss']
})
export class MarkpointsociologyComponent implements OnInit {
  public list: any;
  poor_votes: number;
  average_votes: number;
  pretty_votes: number;
  good_votes: number;
  sociology_point: number;
  txtname: string = '';
  constructor(
    public bsModalRef: BsModalRef,
    public markpointmodel: MarkpointModel,
    public route: Router,
  ) { }

  ngOnInit() {
    this.list = this.markpointmodel._list;
    this.poor_votes = isNaN(parseInt(this.list['poor_votes'])) ? 0 : parseInt(this.list['poor_votes']);
    this.average_votes = isNaN(parseInt(this.list['average_votes'])) ? 0 : parseInt(this.list['average_votes']);
    this.pretty_votes = isNaN(parseInt(this.list['pretty_votes'])) ? 0 : parseInt(this.list['pretty_votes']);
    this.good_votes = isNaN(parseInt(this.list['good_votes'])) ? 0 : parseInt(this.list['good_votes']);
    this.sociology_point = isNaN(parseFloat(this.list['sociology_point'])) ? 0 : parseFloat(this.list['sociology_point']);
    if (this.list['poor_percent'] == null)
      this.list['poor_percent'] = 0;
    if (this.list['average_percent'] == null)
      this.list['average_percent'] = 40;
    if (this.list['pretty_percent'] == null)
      this.list['pretty_percent'] = 70;
    if (this.list['good_percent'] == null)
      this.list['good_percent'] = 100;
  }
  tinhdiemxahoihoc() {
    if (this.poor_votes == 0 && this.average_votes == 0 && this.pretty_votes == 0 && this.good_votes == 0) {
      Library.notify('Bạn phải nhập số phiếu', 'error'); return false;
    }
    let diemxahoihoc: number, tongsophieu: number;
    diemxahoihoc = this.list['poor_percent'] * this.poor_votes + this.list['average_percent'] * this.average_votes + this.list['pretty_percent'] * this.pretty_votes + this.list['good_percent'] * this.good_votes;
    diemxahoihoc = diemxahoihoc / 100;
    tongsophieu = this.poor_votes + this.average_votes + this.pretty_votes + this.good_votes;
    diemxahoihoc = diemxahoihoc / tongsophieu;
    diemxahoihoc = diemxahoihoc * this.list['max_point'];
    diemxahoihoc = Math.round(diemxahoihoc * 10) / 10;
    this.sociology_point = diemxahoihoc;

    return true;
  }
  updatesociologypoint() {
    let deltapoint = this.sociology_point - this.list['sociology_point'];
    deltapoint = Math.round(deltapoint * 1000) / 1000;
    if (this.sociology_point == 0) {
      Library.notify('Điểm xã hội học không được để trống', 'error'); return false;
    }
    if (this.sociology_point > parseFloat(this.list['max_point'])) {
      Library.notify('Điểm xã hội học không được lớn hơn điểm tối đa', 'error'); return false;
    }
    let data = this.list;
    data['list_parrent_id'] = this.getlistidparent(this.list['parrent_id']);
    data['deltapoint'] = deltapoint;
    this.list['sociology_point'] = this.sociology_point;
    this.list['poor_votes'] = this.poor_votes;
    this.list['average_votes'] = this.average_votes;
    this.list['pretty_votes'] = this.pretty_votes;
    this.list['good_votes'] = this.good_votes;
    let arrIdParent = data['list_parrent_id'].split('!~!');
    let index = this.markpointmodel.listData.findIndex(data => data.id == this.list['id']);
    this.markpointmodel.listData[index]['point_council'] = this.sociology_point;
    this.markpointmodel.listData[index]['sociology_point'] = this.sociology_point;
    for (let j = 0; j < arrIdParent.length - 1; j++) {
      let arrParentsingle = arrIdParent[j].split(',');
      if (this.markpointmodel.listData[arrParentsingle[1]]['point_council'] == null)
        this.markpointmodel.listData[arrParentsingle[1]]['point_council'] = 0;
      if (this.markpointmodel.listData[arrParentsingle[1]]['sociology_point'] == null)
        this.markpointmodel.listData[arrParentsingle[1]]['sociology_point'] = 0;
      this.markpointmodel.listData[arrParentsingle[1]]['point_council'] = parseFloat(this.markpointmodel.listData[arrParentsingle[1]]['point_council']) + deltapoint;
      this.markpointmodel.listData[arrParentsingle[1]]['point_council'] = Math.round(100 * this.markpointmodel.listData[arrParentsingle[1]]['point_council']) / 100
      this.markpointmodel.listData[arrParentsingle[1]]['sociology_point'] = parseFloat(this.markpointmodel.listData[arrParentsingle[1]]['sociology_point']) + deltapoint;
      this.markpointmodel.listData[arrParentsingle[1]]['sociology_point'] = Math.round(100 * this.markpointmodel.listData[arrParentsingle[1]]['sociology_point']) / 100
    }

    this.markpointmodel.updatesociologypoint(data);
    this.bsModalRef.hide();
    return true;

  }
  getlistidparent(parrent_id) {
    let index: number = -1;
    if (parrent_id == 0) {
      return '';
    } else {
      index = this.markpointmodel.listData.findIndex(data => data.id == parrent_id);
      var newparentid: number;
      if (index == -1) {
        newparentid = 0;
      } else {
        newparentid = this.markpointmodel.listData[index]['parrent_id'];
      }
      return parrent_id + ',' + index + '!~!' + <string>this.getlistidparent(newparentid)
    }
  }

}
