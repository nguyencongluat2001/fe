import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { MarkpointModel } from '../../models/MarkpointModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-evaluate',
  templateUrl: './evaluate.component.html',
  styleUrls: ['./evaluate.component.scss']
})
export class EvaluateComponent implements OnInit {

  @Input() data: any;
  arrStardand = [];
  arrInputdata = [];
  name: string;
  check: number = 0;
  listfile = [];
  explanation = [];
  note: string;
  c_note: string;
  recipe: string;
  max_point: any;
  point_self: any;
  typeinput: any;
  loai_trac_nghiem: any;
  point_council: any;
  selectbutton = '';
  is_return: any;
  total:any;
  dataTotalPoint:any;
  text:any;
  constructor(
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    public MarkpointModel: MarkpointModel,
    private route: Router,
  ) {
    this.selectbutton = this.MarkpointModel.objExcute['selectbutton'];
    if (this.MarkpointModel.getEvalist['arrStandard']) {
      this.arrStardand = this.MarkpointModel.getEvalist['arrStandard'];
    }
    if (this.MarkpointModel.getEvalist['arrInputData']) {
      this.arrInputdata = this.MarkpointModel.getEvalist['arrInputData'];
    }
    if (this.MarkpointModel.getEvalist['listfile']) {
      this.listfile = JSON.parse(this.MarkpointModel.getEvalist['listfile']);
    }
    if (this.MarkpointModel.getEvalist['explanation']) {
      this.explanation = JSON.parse(this.MarkpointModel.getEvalist['explanation']);
    }
    this.is_return = this.MarkpointModel.objExcute.is_return;
    this.name = this.MarkpointModel.getEvalist['name'];
    this.note = this.MarkpointModel.getEvalist['note'];
    this.c_note = this.MarkpointModel.getEvalist['c_note'];
    this.check = this.arrInputdata.length;
    this.max_point = this.MarkpointModel._evaluationList.max_point;
    this.loai_trac_nghiem = this.MarkpointModel._evaluationList.loai_trac_nghiem;
    for (let i = 0; i < this.check; i++) {
      let k = this.arrInputdata[i]['code_term'].replace('SH', '');
      let a = eval('this.MarkpointModel._evaluationList.tc_danh_gia_' + k);
      let b = eval('this.MarkpointModel._evaluationList.tc_tham_dinh_' + k);
      this.arrInputdata[i]['tc_danh_gia'] = a;
      this.arrInputdata[i]['value'] = b;
    }
    for (let i = 0; i < this.arrStardand.length; i++) {
      if (MarkpointModel._evaluationList.ket_qua_tn_danh_gia != null) {
        let xxx: string;
        xxx = 'EFY.' + MarkpointModel._evaluationList.ket_qua_tn_danh_gia;
        if (xxx.indexOf(this.arrStardand[i]['code']) >= 0) {
          this.arrStardand[i]['checked'] = true;
        } else {
          this.arrStardand[i]['checked'] = false;
        }
      }
      else {
        this.arrStardand[i]['checked'] = false;
      }
      if (MarkpointModel._evaluationList.ket_qua_tn_tham_dinh != null) {
        let yyy: string;
        yyy = 'EFY.' + MarkpointModel._evaluationList.ket_qua_tn_tham_dinh;
        if (yyy.indexOf(this.arrStardand[i]['code']) >= 0) {
          this.arrStardand[i]['checkTD'] = true;
        } else {
          this.arrStardand[i]['checkTD'] = false;
        }
      }
      else {
        this.arrStardand[i]['checkTD'] = false;
      }


    }

    if (this.MarkpointModel._evaluationList.loai_trac_nghiem == 'CHECKBOX') {
      this.typeinput = 'checkbox';
    } else {
      this.typeinput = 'radio';
    }
    this.recipe = this.MarkpointModel._evaluationList.recipe;
    this.point_self = this.MarkpointModel._evaluationList.point_self;
    this.point_council = this.MarkpointModel._evaluationList.point_council;
  }

  ngOnInit() {
    this.MarkpointModel.dataview = '';
  }
  onupload() {
    var myclass = this;
    // Library.showloading();
    // var data = {
    //   form: $('#chamdiemdanhgia').serialize()
    // };
    // this.MarkpointModel.updateexternalexcute(data, this.bsModalRef);
    let value = $('input[name=tongdiem]').val();
    if (value == '' || value == null) {
      Library.notify('Điểm thẩm định không được để trống', 'warning');
    } else {
      if (value > this.MarkpointModel._evaluationList.max_point) {
        Library.notify('Điểm thẩm định không được lớn hơn điểm tối đa', 'warning');
      } else {
        var data = {
          form: $('#chamdiemdanhgia').serialize()
        };
        Library.showloading();
        this.MarkpointModel.updateexternalexcute(data, this.bsModalRef, myclass);
        // if(this.total != undefined && this.total!= this.point_council) {
        //   let index1 = this.MarkpointModel.listData.findIndex(data => data.name ==  'TONG_DIEM');
        //   this.MarkpointModel.listData[index1]['point_council'] = this.MarkpointModel.listData[index1]['point_council']-this.point_council+this.total;
        // }
      }

    }

  }
  //lấy tổng điểm
  async getTotalPoint(param,index1) {
    this.dataTotalPoint = await this.MarkpointModel.getTotalPoint(param);
    this.MarkpointModel.listData[index1]['point_council'] = this.dataTotalPoint[0].point_council;
  }
  thaydoitieuchuan(obj) {
    let total = 0;
    $('input[name=stardandtd]:checked').each(function () {
      total += parseFloat($(this).attr('point'));
    })
    if (this.loai_trac_nghiem != 'RADIO_AND_NOTHING') {
      $('input[name=tongdiem]').val(total);
    } else {
      this.thay_doi_tong_diem();
    }
    this.total = total;
  }
  thaydoidauvao() {
    // console.log(123);
    let congthuc = this.recipe;
    if (congthuc != '' && congthuc != null) {
      let result, sh1, sh2, sh3;
      sh1 = $('#SH1').val();
      sh2 = $('#SH2').val();
      sh3 = $('#SH3').val();
      if ($('#SH1').val() != '') {
        congthuc = congthuc.replace(/#SH1#/gi, sh1);
      }
      if ($('#SH2').val() != '') {
        congthuc = congthuc.replace(/#SH2#/gi, sh2);
      }
      if ($('#SH3').val() != '') {
        congthuc = congthuc.replace(/#SH3#/gi, sh3);
      }
      if (congthuc.indexOf("#") < 0) {

        if (sh2 == 0) {
          result = 100;
        }
        else {
          result = Math.round(eval(congthuc) * 1000) / 1000;
        }
        $('#ketquadauvao').val(result);
      }
    }

    var tongphantram = $('#ketquadauvao').val();

    for (let i = 0; i < this.arrStardand.length; i++) {
      var c_from_percent = this.arrStardand[i]['c_from_percent'];
      var c_to_percent = this.arrStardand[i]['c_to_percent'];
      var c_condition = this.arrStardand[i]['c_condition'];
      if (c_condition == '<=') {
        if (tongphantram >= c_from_percent && tongphantram <= c_to_percent) {
          $('input[name=stardandtd]').removeAttr("checked");
          $('#' + this.arrStardand[i]['id']).attr('checked', 1);
          break;
        }
      }
      else if (c_condition == '<') {
        if (tongphantram >= c_from_percent && tongphantram < c_to_percent) {
          $('input[name=stardandtd]').removeAttr("checked");
          $('#' + this.arrStardand[i]['id']).attr('checked', 1);
          break;
        }
      }
      else if (c_condition == '=') {

        if (tongphantram == c_to_percent) {
          $('input[name=stardandtd]').removeAttr("checked");
          $('#' + this.arrStardand[i]['id']).attr('checked', 1);
          break;
        }
      }
    }
    this.thaydoitieuchuan(12);

  }
  thay_doi_tong_diem() {
    // console.log(123);
    let congthuc = this.recipe;
    let phan_tram=100;
    if (congthuc != '' && congthuc != null) {
      let result, sh1, sh2, sh3;
      sh1 = $('#SH1').val();
      sh2 = $('#SH2').val();
      sh3 = $('#SH3').val();
      if ($('#SH1').val() != '') {
        congthuc = congthuc.replace(/#SH1#/gi, sh1);
      }
      if ($('#SH2').val() != '') {
        congthuc = congthuc.replace(/#SH2#/gi, sh2);
      }
      if ($('#SH3').val() != '') {
        congthuc = congthuc.replace(/#SH3#/gi, sh3);
      }
      if (congthuc.indexOf("#") < 0) {

        if(sh2==0){
          result=100;
        }
        else{
          result = Math.round(eval(congthuc) * 1000) / 1000;
        }
        $('#ketquadauvao').val(result);
        if (this.loai_trac_nghiem == 'RADIO_AND_NOTHING') {
          let maxpoint;
          let check_full_point;
          $('input[name=stardandtd]:checked').each(function () {
            maxpoint = parseFloat($(this).attr('point'));
            check_full_point=parseFloat($(this).attr('check_full_point'));
            if(parseFloat($(this).attr('c_percent'))){
              phan_tram=parseFloat($(this).attr('c_percent'));
            }

          })
          if (result / 100 > 1) {
            Library.notify('Không được quá điểm tối đa', 'warning')
            $('input[name=tongdiem]').val('');
          } else {
            if (maxpoint === '' || maxpoint === null||maxpoint == undefined) {
              Library.notify('Không được để trống đáp án', 'warning');
              $('input[name=tongdiem]').val('');
            } else if(check_full_point=='1'){
              $('input[name=tongdiem]').val( maxpoint);
            }
            else {
              if(phan_tram==0 || phan_tram==null){
                phan_tram=100;
              }

              $('input[name=tongdiem]').val( Math.round((result / phan_tram * maxpoint) * 1000) / 1000);
            }
          }
        }
      }
    }
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);

  }
  // cancel() {
  //   this.check = false;
  //   this.checkedit = false;
  // }
}
