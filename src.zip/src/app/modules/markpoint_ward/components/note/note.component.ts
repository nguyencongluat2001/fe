import { Component, OnInit, Input } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { MarkpointModel } from '../../models/MarkpointModel';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Library } from 'src/app/shared/library/main';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.scss']
})
export class NoteComponent implements OnInit {

  @Input() data: any;
  note: any;
  baseUrl: string;
  headers: any;
  constructor(
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private MarkpointModel: MarkpointModel,
    private route: Router,
  ) {
    this.baseUrl = environment.API_URL + 'markpointward/';
    let token = localStorage.getItem('token');
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Headers', 'Content-Type, X-XSRF-TOKEN');
    headers.append('Authorization', `Bearer ${token}`);
    this.headers = headers;
    this.route.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
    // this.loadlist();

  }

  ngOnInit() {
    this.note = this.MarkpointModel.getNote.note;
  }

  
  onupload(){
    let id = this.MarkpointModel.getNote['id'];
    var unit_infor = this.MarkpointModel.getNote['ownercode'];
    var param = {
      execute_list_id: id,
      ownercode: unit_infor,
      note:this.note
    };
    let token = localStorage.getItem('token');
    let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    Library.showloading();
    this.http.post(this.baseUrl + 'updateNote', param, { headers: header, }).subscribe(res => {
      if (res['success']) {
        Library.hideloading();
        let index = this.MarkpointModel.listData.findIndex(list => list['id'] == id);
        if (res['note'] != '') {
          this.MarkpointModel.listData[index]['note'] = this.note;
        }

        this.bsModalRef.hide();
      } else {
        Library.notify('Quá trình đính kèm file bị lỗi', 'error');
        Library.hideloading();
      }
    });
  }
}
