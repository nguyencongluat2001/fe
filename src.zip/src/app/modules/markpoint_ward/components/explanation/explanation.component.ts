import { Component, OnInit, Input } from '@angular/core';
// import { AddExplanationComponent } from '../add-explanation/add-explanation.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ListexplanationComponent } from '../listexplanation/listexplanation.component';
import { Excute, MarkpointModel } from '../../models/MarkpointModel';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-explanation',
  templateUrl: './explanation.component.html',
  styleUrls: ['./explanation.component.scss']
})
export class ExplanationComponent implements OnInit {

  @Input() data: any;
  arrfile: any = [];
  show: boolean;
  showexplan: boolean;
  explanation:any=[];
  constructor(
    private modalService: BsModalService,
    private MarkpointModel:MarkpointModel
  ) {
  }

  ngOnInit() {
    this.show = false;
    this.showexplan = false;
    if (this.data.listfile != '' && this.data.listfile != null) {
      this.arrfile = JSON.parse(this.data.listfile);
      if (this.data.listfile != '' && this.data.listfile != null) {
        this.show = true;
      }
    }

    if (this.data.explanation != '' && this.data.explanation != null && this.data.explanation != 'undefined') {
      this.showexplan = true;
      this.explanation = JSON.parse(this.data.explanation);
    }
  }
  // showModal() {
  //   this.excuteModel.setlist = this.data;
  //   this.modalService.show(AddExplanationComponent);
  // }
  showexplandetail(){
    this.MarkpointModel.setlist = this.data;
    this.modalService.show(ListexplanationComponent,{backdrop: 'static', keyboard: false });
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);
    
  }
}
