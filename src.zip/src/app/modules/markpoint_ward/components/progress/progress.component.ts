import { Component, OnInit } from '@angular/core';
import { MarkpointModel } from '../../models/MarkpointModel';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.scss']
})
export class ProgressComponent implements OnInit {
  listdata: any;
  selectedItems: any;
  name: string;
  constructor(private markpointmodel: MarkpointModel, private route: Router, private modalService: BsModalService, ) { }

  ngOnInit() {
    this.name ='Bảng tiến độ công việc của  '+ this.markpointmodel.objExcute['tendonvi'];
    this.loadlist()
  }
  async loadlist() {
    var params = {
      id: this.markpointmodel.objExcute['id'],
    };
    Library.showloading();
    this.listdata = await this.markpointmodel.getprogress(params);
    this.listdata = this.listdata.data;
    Library.hideloading();
   
  }
  goBack() {
    let newrouter = "/system/markpoint_ward/list";
    this.route.navigate([newrouter]);
  }
  
}

