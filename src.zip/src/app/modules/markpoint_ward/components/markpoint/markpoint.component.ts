import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { MarkpointModel, Excute } from '../../models/MarkpointModel';
import { ActivatedRoute, Router } from '@angular/router';
import { NoteComponent } from '../note/note.component';
import { EvaluateComponent } from '../evaluate/evaluate.component';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-markpoint',
  templateUrl: './markpoint.component.html',
  styleUrls: ['./markpoint.component.scss']
})
export class MarkpointComponent implements OnInit {

  name: string = "";
  selectedItems: any;
  deltapoint: number
  listidparent: string;
  onchangetree: any[] = [0];
  islastitem: any;
  selectbutton='';
  listData: any;
  oldpoint_council:any;
  constructor(public markpointmodel: MarkpointModel,
    private route: Router,
    private router: ActivatedRoute,
    private modalService: BsModalService,
  ) {
    this.selectbutton=   this.markpointmodel.objExcute['selectbutton'];
    this.name = this.markpointmodel.objExcute['name'] + ' của ' + this.markpointmodel.objExcute['tendonvi']
  }

  ngOnInit() {
    this.loadList();
  }

  onRowPrepared(e) {
    if (e.rowType == "data") {
      if (e.rowIndex % 2 == 0) {
        $(e.rowElement).addClass("dx-column-lines-color");
      }
    }
  }

  async loadList() {
    var id = this.markpointmodel.objExcute['execute_group_id'];
    let params = {
      excute_id: id,
      ownercode: this.markpointmodel.objExcute['ownercode'],
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      selectbutton:this.selectbutton
    };
    Library.showloading();
    await this.markpointmodel.getAllList(params);
    this.listData = this.markpointmodel.listdataexcute;
    Library.hideloading();
   
  }
  goBack() {
    let newrouter = "/system/markpoint_ward/list";
    this.route.navigate([newrouter]);
  }
  checkValidating(e) {
    var note=e.newData.note;
    if (note===undefined) {
      
      var point_council = e.newData.point_council;
      var max_point = e.oldData.max_point;
      var parrent_id = e.oldData.parrent_id;
      var oldpoint_council = e.oldData.point_council;
      var enquire = e.oldData.enquire;
      this.deltapoint = 0;
      if (oldpoint_council == null || oldpoint_council == '') {
        oldpoint_council = 0;
      }
      this.oldpoint_council= oldpoint_council;
      if (this.checkchild(e.oldData['id']) >= 0 && e.newData['point_council'] != '' && e.newData['point_council'] != null) {
        e.isValid = false;
        Library.notify('Không được chấm lĩnh vực cha', 'error');
      } else {
        if ((point_council > max_point && enquire != 'MINUS') || (point_council < 0 && enquire != 'MINUS') || isNaN(parseFloat(point_council))) {
          e.isValid = false;
          Library.notify('Điểm tự thẩm định phải nhỏ hơn điểm tối đa và lớn hơn 0', 'error');
        } else {
          if (Math.abs(point_council) > Math.abs(max_point) || point_council === null) {
            e.isValid = false;
            Library.notify('Điểm thẩm định không được để trống hoặc lớn hơn điểm tối đa', 'error');
          } else {
            if (parrent_id != '0' && !isNaN(parseFloat(point_council))) {
              let listidparent = this.getlistidparent(parrent_id);
              let arrIdParent = listidparent.split('!~!');
              this.listidparent = listidparent;
              this.deltapoint = point_council - oldpoint_council;
              for (let j = 0; j < arrIdParent.length - 1; j++) {
                let arrParentsingle = arrIdParent[j].split(',');
                if (this.markpointmodel.listData[arrParentsingle[1]]['point_council'] == null)
                  this.markpointmodel.listData[arrParentsingle[1]]['point_council'] = 0;
                this.markpointmodel.listData[arrParentsingle[1]]['point_council'] = Math.round((parseFloat(this.markpointmodel.listData[arrParentsingle[1]]['point_council']) + parseFloat(point_council) - parseFloat(oldpoint_council)) * 100) / 100;
              }
            }
          }
        }
      }
    }
    else{
      this.deltapoint=0;
    }

  }
  checkchild(id) {
    let index = this.markpointmodel.listData.findIndex(data => data.parrent_id == id);
    return index;
  }

  getlistidparent(parrent_id) {
    let index: number = -1;
    if (parrent_id == 0) {
      return '';
    } else {
      index = this.markpointmodel.listData.findIndex(data => data.id == parrent_id);
      var newparentid: number;
      if (index == -1) {
        newparentid = 0;
      } else {
        newparentid = this.markpointmodel.listData[index]['parrent_id'];
      }
      return parrent_id + ',' + index + '!~!' + <string>this.getlistidparent(newparentid)
    }
  }
  updateRow(e) {
    let params = {
      data: e.data,
      id: e.key,
      ownercode: this.markpointmodel.objExcute['ownercode'],
      listidparent: this.listidparent,
      deltapoint: this.deltapoint
    }
    let index = this.markpointmodel.listData.findIndex(data => data.name == 'TONG_DIEM');
    this.markpointmodel.listData[index].point_council = this.markpointmodel.listData[index].point_council + e.data['point_council'] - this.oldpoint_council;
  
    this.markpointmodel.updateresultexpertise(params);
  }
  openlist() {
    this.onchangetree = this.markpointmodel.listData.map(listdatas => listdatas.id);
  }
  closelist() {
    this.onchangetree = [0];
  }
  onEditingStart(e) {
    var item = e.data['islastitem'];
    if (item == 0) {
      e.cancel = true;
    }
    if (e.data.enquire == 'SOCIOLOGY' || e.data.enquire == 'MULTICHOICESCALE' || e.data.enquire == 'MULTICHOICE') {
      e.cancel = true;
    }
    if( e.data['name'] == 'TONG_DIEM' && e.column.dataField == 'note'){
      e.cancel = true;
    }
  }
  onCellPrepared(e) {
  }
  shownotedetail(data){
    this.markpointmodel.setNote = data;
    this.modalService.show(NoteComponent,{backdrop: 'static', keyboard: false });
  }
  onCellClick(e) {
    var enquire = e.data.enquire;
    var dataField = e.column.dataField;
    var islastitem = e.data.islastitem;
    if ((enquire == 'MULTICHOICE' || enquire == 'MULTICHOICESCALE') && dataField == 'point_council' && islastitem == 1) {
      this.markpointmodel.setEvalist = e.data;
      this.modalService.show(EvaluateComponent, { class: 'modal-hg', backdrop: 'static', keyboard: false });
    }
  }
}

