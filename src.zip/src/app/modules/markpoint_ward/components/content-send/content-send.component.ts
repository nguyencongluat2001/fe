import { Component, OnInit, Input } from '@angular/core';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-content-send',
  templateUrl: './content-send.component.html',
  styleUrls: ['./content-send.component.scss']
})
export class ContentSendComponent implements OnInit {
  @Input() data: any;
  arrfile: any = [];
  constructor() { }

  ngOnInit() {
    if (this.data.filedanhgia == '') {
      this.data.filedanhgia = null;
    }
    if (this.data.content_send == 'undefined'||this.data.content_send == null) {
      this.data.content_send = '';
    }
    
    this.arrfile = JSON.parse(this.data.filedanhgia);
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);
    
  }

}
