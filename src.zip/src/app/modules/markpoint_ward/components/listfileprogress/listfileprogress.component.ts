import { Component, OnInit, Input,NgModule } from '@angular/core';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-listfileprogress',
  templateUrl: './listfileprogress.component.html',
  styleUrls: ['./listfileprogress.component.scss']
})
export class ListfileprogressComponent implements OnInit {
  @Input() data: any;
  arrfile: any = [];
  constructor() { }

  ngOnInit() {
    if (this.data.listfile == '') {
      this.data.listfile = null;
    }
    if (this.data.content == 'undefined'||this.data.content== null) {
      this.data.content = '';
    }
    
    this.arrfile = JSON.parse(this.data.listfile);
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);
    
  }

}
