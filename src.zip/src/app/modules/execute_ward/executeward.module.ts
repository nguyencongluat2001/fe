import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule,DxDataGridModule,DxTreeListModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ExcuteRoutingModule } from './execute-routing.module';
import { ExecuteComponent } from './components/execute/excute.component';
import { ExcuteModel } from '../execute_ward/models/ExcuteModel';
import { ApiService } from '../execute_ward/services/api.service';
import { EvaluationService } from '../evaluation/services/evaluation.service';
import { AddExplanationComponent } from './components/add-explanation/add-explanation.component';
import { ExplanationComponent } from './components/explanation/explanation.component';
import { IndexComponent } from './components/index/index.component';
import { SeeComponent } from './components/see/see.component';
import { RowcellComponent} from './components/rowcell/rowcell.component'
import { ResultComponent } from './components/result/result.component';
import { SendmarkpointComponent } from './components/sendmarkpoint/sendmarkpoint.component';
import { ListexplanationComponent } from './components/listexplanation/listexplanation.component';
import { EvictionComponent } from './components/eviction/eviction.component';
import { EvaluateComponent } from './components/evaluate/evaluate.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ExcuteRoutingModule,
    DxDataGridModule,
    DxTreeListModule
  ],
  providers: [ApiService, ExcuteModel, EvaluationService],
  declarations: [SeeComponent,ExecuteComponent, AddExplanationComponent, ExplanationComponent, IndexComponent,RowcellComponent,ResultComponent, SendmarkpointComponent,ListexplanationComponent,EvictionComponent,EvaluateComponent],
  bootstrap: [SeeComponent,ExecuteComponent, AddExplanationComponent, ExplanationComponent, IndexComponent,RowcellComponent,ResultComponent, SendmarkpointComponent,ListexplanationComponent,EvictionComponent,EvaluateComponent],
})
export class ExecuteWardModule { }


