import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-rowcell',
  templateUrl: './rowcell.component.html',
  styleUrls: ['./rowcell.component.scss']
})
export class RowcellComponent implements OnInit {
  @Input() data: any;
  status: string = ''
  constructor() {

  }

  ngOnInit() {
    if (this.data['status'] == 'XEM_CHI_TIET') {
      this.data = this.data['data'];
      this.status = 'XEM_CHI_TIET';
    }
   
  }

}
