import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { Excute, ExcuteModel } from '../../models/ExcuteModel';
import { ApiService } from '../../services/api.service';
import { Library } from 'src/app/shared/library/main';


@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {

  Excutes: Excute[];
  name: string = "";
  bsModalRef: BsModalRef;
  selectedItems: Excute[] = [];
  constructor(
    public ExcuteModel: ExcuteModel,
    private modalService: BsModalService,
    private route: Router,
    private router: ActivatedRoute,
    public apiService: ApiService,
  ) {
  
   }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    this.name = "Kết quả của đợt đánh giá "+this.ExcuteModel._excute.name;
    var execute_group_id = this.ExcuteModel._excute.execute_group_id;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('user_infor'))['department']
    };
    Library.showloading();
    this.Excutes = await this.ExcuteModel.seeresult(params);
    Library.hideloading();
  }
  goBack() {
    let newrouter = "/system/execute_ward";
    this.route.navigate([newrouter]);
  }
  
  
}

