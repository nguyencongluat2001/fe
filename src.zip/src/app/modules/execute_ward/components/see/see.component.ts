import { Component, OnInit } from '@angular/core';
import { ExcuteModel } from '../../models/ExcuteModel';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';

@Component({
  selector: 'app-see',
  templateUrl: './see.component.html',
  styleUrls: ['./see.component.scss']
})
export class SeeComponent implements OnInit {

  name: string = "";
  listData: any;
  selectedItems: any;
  deltapoint: number
  listidparent: string;
  onchangetree: any[] = [0];
  constructor(public ExcuteModel: ExcuteModel,
    private route: Router,
  ) { }

  ngOnInit() {
    this.name = "";
    this.loadList();
  }

  onRowPrepared(e) {
    if (e.rowType == "data") {
      if (e.rowIndex % 2 == 0) {
        $(e.rowElement).addClass("dx-column-lines-color");
      }
    }
  }

  async loadList() {
    var execute_group_id = this.ExcuteModel._excute.execute_group_id;
    let params = {
      excute_id: execute_group_id,
      ownercode: JSON.parse(localStorage.getItem('user_infor'))['department']
    };
    Library.showloading();
    await this.ExcuteModel.getAllList(params);
    this.listData = this.ExcuteModel.listDataExcute;
    Library.hideloading();
   
  }

  goBack() {
    let newrouter = "/system/execute_ward";
    this.route.navigate([newrouter]);
  }

  openlist() {
    this.onchangetree = this.listData.map(listdata => listdata.id);
  }
  closelist() {
    this.onchangetree = [0];
  }
}
