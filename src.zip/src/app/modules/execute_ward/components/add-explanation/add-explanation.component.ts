import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { ExcuteModel } from '../../models/ExcuteModel';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { Library } from 'src/app/shared/library/main';
@Component({
  selector: 'app-add-explanation',
  templateUrl: './add-explanation.component.html',
  styleUrls: ['./add-explanation.component.scss']
})
export class AddExplanationComponent implements OnInit {

  @Input() data: any;

  check = false;
  checkedit = false;
  baseUrl: string;
  headers: any;
  explanation: string;
  explanation_detail: any;
  listfile: string;
  listfile_detail: any;
  value: any[] = [];
  index: number;
  fileselected: File[] = [];
  arrfile: any = [];
  items: any = [];
  id;
  arritem;
  status: any;
  is_return:any;
  constructor(
    private http: HttpClient,
    public bsModalRef: BsModalRef,
    private excuteModel: ExcuteModel,
    private route: Router,
  ) {
    this.baseUrl = environment.API_URL + 'executeward/';
    let token = localStorage.getItem('token');
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Headers', 'Content-Type, X-XSRF-TOKEN');
    headers.append('Authorization', `Bearer ${token}`);
    this.headers = headers;
    this.explanation = this.excuteModel.getlist['explanation'];
    this.listfile = this.excuteModel.getlist['listfile'];
    this.is_return=this.excuteModel.Excute.is_return;
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    // this.arrfile = JSON.parse(this.listfile);
    let id = this.excuteModel.getlist['id'];
    this.index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == id);
    this.route.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }
    this.loadlist();

  }

  ngOnInit() {
    this.excuteModel.dataview = '';
  }
  handleFileInput(event) {
    // if (event.target.files[0].name != '') {
    //   this.fileselected.push(<File>event.target.files[0]);
    // }
    var arrfile = event.target.files;
    for (let i=0; i<arrfile.length;i++) {
      if (event.target.files[i].name != '') {
        this.fileselected.push(<File>event.target.files[i]);
      }
    }
  }
  async loadlist() {
    let id = this.excuteModel.getlist['id'];
    var unit_infor = JSON.parse(localStorage.getItem('user_infor'));
    var execute_group_id = this.excuteModel.getlist['execute_group_id'];
    var param = {
      execute_id: id,
      ownercode: unit_infor['department'],
      execute_group_id:execute_group_id
    };
    Library.showloading();
    this.items = await this.excuteModel.explanation_detail(param);
    Library.hideloading();
  }
  onupload() {
    const fd = new FormData();
    let idlist = this.excuteModel.getlist['id'];
    var unit_infor = JSON.parse(localStorage.getItem('user_infor'));
    for (let i in this.fileselected) {
      fd.append('file' + i, this.fileselected[i], this.fileselected[i].name)
    }
    fd.append('idlistexcute', idlist);
    fd.append('explanation', this.explanation_detail);
    fd.append('ownercode', unit_infor['department']);
    fd.append('explanation_detail_id', this.id);
    fd.append('is_return', this.is_return);
    this.excuteModel.getlist.explanation = this.explanation;
    let token = localStorage.getItem('token');
    let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    Library.showloading();
    this.http.post(this.baseUrl + 'uploadfile', fd, { headers: header, }).subscribe(res => {
      if (res['success']) {
        Library.hideloading();
        let index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == idlist);
        if (res['listfile'] != '') {
          this.excuteModel.listDataExcute[index]['explanation'] = JSON.parse(res['explanation']);
        }

        if (res['listfile'] != '') {
          this.excuteModel.listDataExcute[index]['listfile'] = JSON.parse(res['listfile']);
        }
        this.bsModalRef.hide();
        Library.showloading();
        this.loadlist();
        this.check = false;
        this.checkedit = false;
        this.fileselected = [];
        this.explanation_detail = [];
        this.id = 'undefined';
        Library.hideloading();
      } else {
        Library.notify('Quá trình đính kèm file bị lỗi', 'error');
        Library.hideloading();
      }
    });

  }
  remove(filename) {
    let index = this.fileselected.findIndex(file => file.name == filename);
    this.fileselected.splice(index, 1);
  }
  removeonserver(item,filenameFull, filename) {
    const fd = new FormData();
    let idlist = this.excuteModel.getlist['id'];

    // let filename=item.listfiles['filename']
    fd.append('idlistexcute', idlist);
    fd.append('filenameFull', filenameFull);
    fd.append('explanation_detail_id', item.id);
    fd.append('ownercode', JSON.parse(localStorage.getItem('user_infor'))['department']);
    let index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == idlist);
    let token = localStorage.getItem('token');
    let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    Library.showloading();
    this.http.post(this.baseUrl + 'removefile', fd,{ headers: header, }).subscribe(res => {
      if (res['success']) {
        Library.hideloading();
        let index2 = this.excuteModel.listDataExcute[index]['listfile'].findIndex(file => file['urlFile'] == filename);
        this.excuteModel.listDataExcute[index]['listfile'].splice(index2, 1);
        let index1 = item.listfiles.findIndex(file => file['urlFile'] == filename);
        item.listfiles.splice(index1, 1);
        this.route.routeReuseStrategy.shouldReuseRoute = function () {
          return false;
        }
      } else {
        Library.notify('Xóa file thất bại', 'error');
        Library.hideloading();
      }
    });
  }
  edit(item) {
    if(item.is_return!='1' && this.is_return=='1'){
      Library.notify('Không được sửa bản ghi này', 'error');
      return false;
    }
    this.check = false;
    this.checkedit = true;
    this.explanation_detail = item.explanation;
    this.listfile_detail = item.listfiles;
    this.id = item.id;
    this.arritem = item;
    this.fileselected = [];
    if (this.explanation_detail == 'null') {
      this.explanation_detail = [];
    }
    return true;
  }
  delete(item) {
    if(item.is_return!='1' && this.is_return=='1'){
      Library.notify('Không được xóa bản ghi này', 'error');
      return false;
    }
    let Myclass = this;
    let idlist = this.excuteModel.getlist['id'];
    var unit_infor = JSON.parse(localStorage.getItem('unit_infor'));
    var param = {
      listfile_detail: item.listfiles,
      id: item.id,
      idlist: idlist,
      ownercode: unit_infor['code']
    };
    // var result = Library.confirm("Bạn có chắc chắn muốn xóa đối tượng đã chọn?", "Thông báo");
    // if (result) {
    //   result.done(function (dialogResult) {
    //     if (dialogResult) {
    //       Myclass.excuteModel.delete_explanation(param,Myclass);
    //     }
    //   });
    // }

    let token = localStorage.getItem('token');
    let header = new HttpHeaders().set('Authorization', 'Bearer ' + token);
    Library.showloading();
    this.http.post(this.baseUrl + 'delete_explanation', param,{ headers: header, }).subscribe(res => {
      if (res['success']) {
        Library.hideloading();
        let index = this.excuteModel.listDataExcute.findIndex(list => list['id'] == idlist);
        this.excuteModel.listDataExcute[index]['explanation'] = res['explanation'];
        if (res['listfile'] != '[]') {
          this.excuteModel.listDataExcute[index]['listfile'] = res['listfile'];
        }
        Library.showloading();
        this.loadlist();
        Library.hideloading();
      } else {
        Library.notify('Xóa file thất bại', 'error');
        Library.hideloading();
      }
    });
    return true;
  }
  add() {
    this.check = true;
    this.checkedit = false;
    this.fileselected = [];
    this.explanation_detail = null;
  }
  cancel() {
    this.check = false;
    this.checkedit = false;
  }
  openfile(namefile) {
    let params = {
      namefile: namefile
    }
    var baseurl=environment.API_BASE + 'file/openfile?namefile='+namefile;
     window.open(baseurl);

  }
}
