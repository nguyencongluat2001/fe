import { Injectable } from '@angular/core';
import { ReportService } from '../services/report.service';
import { Router } from '@angular/router';
import { Library } from 'src/app/shared/library/main';
import { HttpService } from 'src/app/core/http.service';

export class Excute {
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: string = '';
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    execute_group_id: string = '';
    status: number = 0;
    max_point:number;
    ownercode: string = localStorage.getItem('unit_infor')['code']

}
export class ExcuteGroup{
    id: string = '';
    name: string = '';
    total_score: string = '';
    reward_points: number;
    minus_point: string = '';
    group: string = '';
    fromdate: string = '';
    todate: string = '';
    order: string = '';
    status: number = 0;
    user_id: string = '';
}
export class List {
    id: string;
    parrent_id: string;
    name: string;
    max_point: number;
    new_point: number;
    explanation: string
    listfile: string
}

@Injectable()

export class ReportModel {

    _excute: ExcuteGroup;
    _excutelist: Excute;
    objExcute: any;
    private _list: List;
    private _dataview: any;

    constructor(private HttpService:HttpService,private ReportService: ReportService, private route: Router) {

    }

    set Excute(value: any) {
        this._excute = value;
    }

    get Excute() {
        return this._excute;
    }
    set ExcuteList(value: any) {
        this._excutelist = value;
    }

    get ExcuteList() {
        return this._excutelist;
    }
    set setlist(value: any) {
        this._list = value;
    }

    get getlist() {
        return this._list;
    }
    get dataview() {
        return this._dataview;
    }
    set dataview(value: any) {
        this._dataview = value;
    }

    updateList(data) {
        // Library.showloading();
        this.HttpService.postMethods('updatelistexcute', data).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            }
        });
    }
    sendexpertise() {
        Library.showloading();
        this.HttpService.postMethods('sendexpertise', this._excute).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            }
        });
    }
    async getfield(params, async: boolean = false): Promise<Excute[]> {
        let response = await this.ReportService.callGet('getfield', params);
        return response;
    }
    async result(params, async: boolean = false): Promise<Excute[]> {
        let response = await this.ReportService.callGet('result', params);
        return response;
    }
    export(params) {
        this.HttpService.postMethods('export', params).subscribe((response: any) => {
            Library.hideloading();
            if (!response.success) {
                Library.notify(response.message, 'error');
            }
        });
    }
    async chart(params, async: boolean = false): Promise<Excute[]> {
        let response = await this.ReportService.callGet('chart', params);
        return response;
    }
    async exportchart(params, async: boolean = false): Promise<Excute[]> {
        let response = await this.ReportService.callGet('exportchart', params);
        return response;
    }







}
