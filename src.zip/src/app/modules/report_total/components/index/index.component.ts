import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Library } from 'src/app/shared/library/main';
import { ExcuteGroup, ReportModel } from '../../models/ReportModel';
import { ReportService } from '../../services/report.service';
import { HttpService } from 'src/app/core/http.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {

  Excutes: ExcuteGroup[];
  bsModalRef: BsModalRef;
  selectedItems: ExcuteGroup[] = [];
  export_chart: any;
  public listData:any;
  constructor(
    private HttpService:HttpService,
    public reportmodel: ReportModel,
    public reportservice: ReportService,
  ) { }

  ngOnInit() {
    this.loadList();
  }

  /**
   * ---------------------- Màn hình danh sách ----------------------------
   */

  // load du lieu man hinh danh sach
  async loadList() {
    let params = {
      user_id: JSON.parse(localStorage.getItem('user_infor'))['id'],
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code'],
      role:JSON.parse(localStorage.getItem('user_infor'))['role']
    };
    Library.showloading();
    this.getAll(params);
    Library.hideloading();
  }
  getAll(parram) {
    this.HttpService.getMethods("report/total/getall", parram).subscribe(
        result => {
            return this.Excutes = result.data;
        },
        (error) => {
          Library.hideloading();
        }
      );
}

  convertFromdate(data) {
    return Library.formatDate(data.fromdate);
  }

  convertTodate(data) {
    return Library.formatDate(data.todate);
  }

  selectExcute(e) {
    this.selectedItems = e.selectedRowsData;
  }
  export() {
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để xem", 'error');
      return;
    } else {
      this.reportmodel.Excute = this.selectedItems[0];
      let params = {
        execute_group_id: this.reportmodel.Excute['execute_group_id'],
        ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
      };
      Library.showloading();
      this.reportservice.callPost('export', params).subscribe(res => {
        if (!res.success) {
          Library.notify(res.message, 'error');
          Library.hideloading();
        } else {
          window.location.href = res.urlfile;
          Library.hideloading();
        }
      });
    }

  }
 
  async exportchart() {
    let Myclass = this;
    let selectedItems = this.selectedItems.map(execute => execute.id);
    let name = this.selectedItems.map(execute => execute.name);
    let group = this.selectedItems.map(execute => execute.group);
    let data = {
      execute_group_id: selectedItems,
      names: name,
      groups: group,
      ownercode: JSON.parse(localStorage.getItem('unit_infor'))['code']
    };
    if (this.selectedItems.length > 1) {
      Library.notify("Chỉ được chọn một đối tượng để export", 'error');
      return;
    } else {
      Library.showloading();
      this.export_chart = await this.reportmodel.exportchart(data);
      window.open(this.export_chart);
      Library.hideloading();
    }

  }
}

