import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DxTooltipModule, DxTemplateModule } from 'devextreme-angular';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule } from '@angular/forms';
import { ReportRoutingModule } from './report-routing.module';
import { DxChartModule } from 'devextreme-angular';
import { ReportModel } from '../report_total/models/ReportModel';
import { ReportService } from '../report_total/services/report.service';
import { IndexComponent } from './components/index/index.component';
import { devextremeModule } from 'src/app/shared/library/devextreme/load.module';
@NgModule({
  imports: [
    CommonModule,
    devextremeModule,
    DxTooltipModule,
    ModalModule.forRoot(),
    FormsModule,
    ReportRoutingModule,
    DxChartModule
  ],
  // entryComponents: [
  // ],
  providers: [ ReportModel, ReportService],
  declarations: [IndexComponent]
})
export class ReportModule { }

